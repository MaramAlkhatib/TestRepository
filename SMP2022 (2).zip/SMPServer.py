

# from crypt import methods
import csv
from itertools import groupby
from opcode import opname
import GetOrderPhotos as GOP
import os, random, math, smtplib, ssl, json,  time, glob
from posixpath import split
from flask import Flask, request,  render_template, redirect, make_response, send_from_directory,abort, send_file
from pandas.core.frame import DataFrame
from pandas.io import excel
import requests
from requests.auth import HTTPBasicAuth
#from pandas.io.sas import sasreader
from werkzeug.utils import secure_filename
from datetime import datetime
from datetime import timedelta
from subprocess import Popen
# from win32process import DETACHED_PROCESS, THREAD_PRIORITY_TIME_CRITICAL
#from win32process import DETACHED_PROCESS, THREAD_PRIORITY_TIME_CRITICALUMD
import pyodbc
import pandas as pd
import numpy as np
from pandas import ExcelWriter
from pandas import ExcelFile
import socket

import HESShipmentManagment as HES_Shipment
import HES_Int as HESInt

#import SimManagement
import GetMeterData as GMD
import HTML_Builder as BH
import UserManagement as UM
import ECBRevision as ECR
from MeterManuData import UploadMeterData as UMD
import globalFunctions as GFs
from threading import Thread
import EMailer as mailIt
import NCR_Management as NCRM
import DocCreator as GenDoc
from werkzeug.utils import secure_filename
from colorama import Fore, Back, Style
import shutil
import MultiFilrEmailer as mailer
import logging
import logging.handlers as handlers
from PlanManagement.PM import PM as PlanManage
import warnings
warnings.filterwarnings('ignore')
import re
import jwt
PlanEndTime = 19

# from termcolor import colored, cprint
DownloadFilesFolder = "D:\\SAI_System\\"

key = b'JNQcis_GHIF_-kQUkCbJV4VsShKpnPvf-4zSrSysT-Q='
SystemToken = "Bearer eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJuYW1laWQiOiJiMTIwZjE2Mi1lN2VjLTQwZDctYjgxOC0wOGQ4ZjM3Yzg1MGMiLCJ1bmlxdWVfbmFtZSI6IntcIklkXCI6XCJiMTIwZjE2Mi1lN2VjLTQwZDctYjgxOC0wOGQ4ZjM3Yzg1MGNcIixcIlVzZXJuYW1lXCI6XCJXRk1TXCIsXCJQYXNzd29yZEhhc2hcIjpcIjJtWWU1R3d6dE44dDJLQmtIL1QwWGljVnFXTE5pTk5BeVFQeFJlVzZNdENyYk1MY2NycXk1RzR1R1pxYW9qSldHV0p6OTZORXpzalNidkpXZC9aQVVBPT1cIixcIlBhc3N3b3JkU2FsdFwiOlwiY1BSSWk5SHc0eGpVamdQdTNSMWE2bTdxNkNIc0JNYzRCb0Q2R1FEVW9kNVQyNEUrWXNhMWQ3ZXk4b1JFZGFnS0p5ZFRUaGpzN2xOOEJXOFpBWTF0bVZGbkNNTjIzSWUvNXZFeHlpcmxFS3F0VWVuUmdibUNOYk9rRkVSWVZVeS9lYy9WK2E5Q2lBZzdFSUVmM2EwcHJ1eHpvQTdpb0JPUjc4Q25UTXROTkRjPVwiLFwiRmlyc3ROYW1lXCI6XCJXRk1TXCIsXCJMYXN0TmFtZVwiOlwiV0ZNU1wiLFwiRW1haWxcIjpcIldGTVNAZS1pbmN1YmUuY29tXCIsXCJTb3VyY2VDb2RlXCI6XCJXRk1TXCIsXCJTb3VyY2VOYW1lXCI6XCJXRk1TXCIsXCJJc0ZvVXNlclwiOmZhbHNlLFwiRnVsbE5hbWVcIjpcIldGTVMgV0ZNU1wifSIsInJvbGUiOiJbXSIsIm5iZiI6MTYyODUxNzkxOSwiZXhwIjoxNjI4NjA0MzE5LCJpYXQiOjE2Mjg1MTc5MTl9.W_n9Yuw3nebslBXLs96DN2SD1cHqjI3Q-E48mc7l7gS_OZd9uJwejLr3YrQwiXrJ98wUniDk5p-lQTVZ9AuO4Q"

from cryptography.fernet import Fernet
import uuid

ClConnectionStr = 'DRIVER={SQL Server};SERVER=10.90.10.173,21532;DATABASE=Clevest;UID=clevest;PWD=!C13ve$T'

myPM = PlanManage(ClConnectionStr)

conn = pyodbc.connect('DRIVER={SQL Server};SERVER=10.90.10.173,21532;DATABASE=HES;UID=Clevest;PWD=!C13ve$T')

app = Flask(__name__, static_folder='templates', instance_path='D:\\SAI_System\\downloads')
app.config['UPLOAD_EXTENSIONS'] = ['.docx','.pdf']
app.config['UPLOAD_PATH'] = "templates/NCRs/"
fernet = Fernet(key)
ActiveSessions = {}
SessionDuration = timedelta(hours=48)

AssignFilesTemplates = {
    "1" : "%_Assign_MEX.csv",
    "3" : "%_Assign_ECB.csv",
    "10" : "%_Assign_BoxRep.csv",
    "5" : "%_Assign_BM.csv",
    "12" : "%_Assign_CMI.csv",
    "11" : "%_Assign_ECBRect.csv",
    "8" : "%_Assign_OMO.csv",
    "13" : "%_Assign_SOM.csv"
}
dict_HostExchange={
    "1" : {
            "Name" : "MEX"
            ,"FilePath" : "//10.90.10.59/prd/AllHostExchange/SingleUpdateFolder"
            ,"FileNameTemplate" : "%_Assign_MEX.csv"
          }
    ,"3" : {
            "Name" : "ECB"
            ,"FilePath" : "//10.90.10.59/prd/AllHostExchange/SingleUpdateFolder"
            ,"FileNameTemplate" : "%_Assign_ECB.csv"
          }
    ,"5" : {
            "Name" : "Smart to Smart"
            ,"FilePath" : "//10.90.10.59/prd/AllHostExchange/SingleUpdateFolder"
            ,"FileNameTemplate" : "%_Assign_BM.csv"
          }
    ,"10" : {
            "Name" : "Box Replacement"
            ,"FilePath" : "//10.90.10.59/prd/AllHostExchange/SingleUpdateFolder"
            ,"FileNameTemplate" : "%_Assign_BoxRep.csv"
          }
    ,"12" : {
            "Name" : "Comm Module Inst"
            ,"FilePath" : "//10.90.10.59/prd/AllHostExchange/SingleUpdateFolder"
            ,"FileNameTemplate" : "%_Assign_CMI.csv"
          }
    ,"11" : {
            "Name" : "ECB Rectification"
            ,"FilePath" : "//10.90.10.59/prd/AllHostExchange/SingleUpdateFolder"
            ,"FileNameTemplate" : "%_Assign_ECBRect.csv"
          }
    ,"8" : {
            "Name" : "O&M Troubleshooting V1"
            ,"FilePath" : "//10.90.10.59/prd/AllHostExchange/SingleUpdateFolder"
            ,"FileNameTemplate" : "%_Assign_OMO.csv"
          }
    ,"13" : {
            "Name" : "Smart O&M Troubleshooting V1"
            ,"FilePath" : "//10.90.10.59/prd/AllHostExchange/SingleUpdateFolder"
            ,"FileNameTemplate" : "%_Assign_SOM.csv"
          }
}

#"11" : "%_Assign_ECBRect.csv",
#"8" : "%_Assign_OMO.csv"

SECMD =pd.DataFrame()

AlFanarMeters = pd.read_sql("select DeviceID as Serials from alf_meters WHERE Owner = 'ALF'  ",conn)

AppDebugMode = False

statusList={
        "Created":"success",
        "InProgress":"warning",
        "Pending":"info",
        "Rectified":"primary",
        "Closed":"secondary"
        }

Log_Format = "%(asctime)s %(levelname)s - %(funcName)s - %(message)s"
logging.basicConfig(filename = "log/logfile6.log" if AppDebugMode == False else "log/logfile_test.log" ,
filemode = "a",
format = Log_Format,
level = logging.DEBUG)
# For debugh
# console  = logging.StreamHandler()
# console.setLevel(logging.INFO)
# logging.getLogger().addHandler(console)

#log_formatter = logging.Formatter('%(asctime)s %(levelname)s - %(funcName)s - %(message)s')
#logFile = 'log/logfile.log'
#logger = logging.getLogger('my_app')
#logger.setLevel(logging.DEBUG)
#logHandler = handlers.RotatingFileHandler(logFile, maxBytes=10*1024*1024, backupCount=10)
#logHandler.setLevel(logging.DEBUG)
#logHandler.setFormatter(log_formatter)
#logger.addHandler(logHandler)
#console  = logging.StreamHandler()
#console.setLevel(logging.DEBUG)
#logging.getLogger().addHandler(console)




def IsinByPassList(Pnum):
    # print("ByPass Premise: "+Pnum)
    logging.info("ByPass Premise: "+Pnum)

    SQL=""" select  DISTINCT Premise
                from
                SAI_NCR_MeterByPass
                where
                ValidTo > format(getdate(),'yyyy-MM-dd') and Premise = """+Pnum+ """
            """
    ByPass= pd.read_sql(SQL, conn)
  
    
    if len(ByPass)>0:
        
        return True
    return False





def IsAlFanarMeter(SN):
    if len(AlFanarMeters[AlFanarMeters["Serials"]==SN])>0:
        return True
    return False

def LoadActiveSession():
    AcSessions = pd.read_sql("Select SessionId,Token, UserID from [HES].[dbo].[SAI_UserSessions] where [Status]='A'", conn)
    global ActiveSessions
    print(str(len(AcSessions)) + " --> Session will be loaded.")
    for i, row in AcSessions.iterrows():
        #xxx = jwt.decode(row.Token,key,algorithms=['HS256'])
        #print(type(xxx))
        ActiveSessions[row.SessionId] = jwt.decode(row.Token,key,algorithms=['HS256'])
        print(row.SessionId + " ---> " + str(row.UserID) + " ---> LOADED")

LoadActiveSession()

def ReloadSECData():
    # DCU Data
    df = pd.read_sql("""
                        SELECT  
                            wo.HostOrderNumber as Premise,
                            FORMAT(wom.FH_OfficeCode,'0000') as Office,
                            wom.FH_RouteReadSequence as 'Route Read Seq',
                            wom.FH_ServiceClass as 'Service Class',
                            wom.FH_SubscriptionNumber as 'Subscription No',
                            wom.FH_ContractAccount as 'Account No',
                            STR(wo.Latitude, 25, 5) as Latitude,
                            STR(JSON_VALUE(OrderData, '$.Order.DCU_CapturedLatitude') , 25, 5) as Longitude,
                            JSON_VALUE(OrderData, '$.Order.MEX_MRUNumber') as MRU,
                            JSON_VALUE(OrderData, '$.Order.DCU_NewSerialNumber') as 'DCUSerialNumber',
                            JSON_VALUE(OrderData, '$.Order.MEX_ExistingMeterNumber') as 'MeterList',
                            JSON_VALUE(OrderData, '$.Order.DCU_SignalStrength') as 'SignalStrength',
                            JSON_VALUE(OrderData, '$.Order.TMUCTSerialNumber') as 'fg. Ser. No',
                            JSON_VALUE(OrderData, '$.Order.TransformerID') as 'TransformerID',
                            JSON_VALUE(OrderData, '$.Order.TransformerRating') as 'TransformerRating',
                            REPLACE(REPLACE(JSON_VALUE(OrderData, '$.Order.PowerConnected'), 'Y', 'Yes'),'N','No') as 'PowerConnected',
                            JSON_VALUE(OrderData, '$.Order.PowerConnectionDate') as 'PowerConnectionDate',
                            JSON_VALUE(OrderData, '$.Order.PowerStatusUpdatedBy') as 'PowerStatusUpdatedBy',
                            REPLACE(REPLACE(JSON_VALUE(OrderData, '$.Order.CTavailable'), 'Y', 'Yes'),'N','No') as 'CTavailable',
                            REPLACE(REPLACE(JSON_VALUE(OrderData, '$.Order.CTConnected'), 'Y', 'Yes'),'N','No') as 'CTConnected',
                            JSON_VALUE(OrderData, '$.Order.CTRatio') as 'CTRatio'
                        FROM
                            Clevest.dbo.WorkOrder as wo
                            inner join Clevest.dbo.WorkOrderMapping as wom on wo.HostOrderNumber = wom.HostOrderNumber
                        WHERE
                            wo.OrderTypeId = 4 
                            and wo.OrderStatusId in (100)
                            and wom.OrderStatusId in (100)
                        """,conn)
    df["Meter Type"]= "DCU"
    df["Conn. Type"]= "4G"

    # SEC Data
    global SECMD 
    SECfiles = glob.glob( "//10.90.10.70/sceco/MSTR/CMD/*.txt")
    li=[]
    i=0
    for filename in SECfiles:
            dfx = pd.read_csv(filename,delimiter=';',header=None, dtype=str,encoding = "utf-8",quoting=csv.QUOTE_NONE)
            i+=1
            li.append(dfx)
            print ('\r |' + ('#' * i) + ('-' * (len(SECfiles) - i)) + '| File loaded -- > ' + filename , end='')
            if AppDebugMode:
                break
                # pass
    # print ('\r |' + ('#' * i) + ('-' * (len(SECfiles) - i)) + '| All files loaded')
    logging.info('\r |' + ('#' * i) + ('-' * (len(SECfiles) - i)) + '| All files loaded')
    SECMD =  pd.concat(li, axis=0, ignore_index=True)
    cols=['Premise','MRU','Office','fg. Ser. No','Meter Type','Equip. No','Cycle','Last Bill Key','Route Read Seq','MR Note','Date of MR Note','Critical Need','Service Class','Premise Address','City','District','Subscription No','Account No','BPName','BP Type','Latitude','Longitude','Mult. Factor','No. of Dials','Breaker Cap.','Voltage','Phase','Tariff Type','Prev Read Date T','Prev. Read T','Prev Read Date T1','Prev. Read T1','Prev. Read Date T2','Prev. Read T2','Prev Read Date T3','Prev. Read T3','Prev. Read Date T4','Prev. Read T4','Prev. Read Date T5','Prev. Read  T5','Prev. Read Date T6','Prev. Read  T6','Prev. Read Date T7','Prev. Read  T7','Avg. Consp. per day (kWh)','Accl. Premise No','Main Premise No','Conn. Type', 'F1','F2']
    SECMD.columns=cols
    SECMD = pd.concat([SECMD, df], ignore_index=True)
    SECMD = SECMD.fillna('')
    SECMD['fg. Ser. No']= SECMD['fg. Ser. No'].str.upper()
    GMD.SECMDHere = SECMD

ReloadSECData()

def TestAndExtendSession(SID):
    global ActiveSessions
    global SessionDuration
    
    if SID in ActiveSessions:
        CSession = ActiveSessions[SID]
        TT = datetime.strptime(CSession["ExpriationDate"], '%Y-%m-%d %H:%M:%S')
        if TT > datetime.today():
            EDate = TT + SessionDuration
            ActiveSessions[SID]["ExpriationDate"] = EDate.strftime("%Y-%m-%d %H:%M:%S")
            return True
        else:
            return False
    else:
        return False
    

def CheckUserAuth(SID, AuthCode):
    UAuths = ActiveSessions[SID]["Auths"]
    #print(UAuths)
    return True if AuthCode in UAuths else False

BM2BM_Reasons = {}

def RefreshSM2SMReasons():  
    global BM2BM_Reasons
    conn2 = pyodbc.connect('DRIVER={SQL Server};SERVER=10.90.10.173,21532;DATABASE=Clevest;UID=clevest;PWD=!C13ve$T')
    SQL = "SELECT [id],[Reason],[SubReason] FROM [HES].[dbo].[SAI_BM_Reasons] order by [Reason],[SubReason]"
    subReasons = pd.read_sql(SQL, conn2)
    conn2.close()
    bm2bm = {}
    for i, row in subReasons.iterrows():
        if row["Reason"] in bm2bm.keys():
            pass
        else:
            bm2bm[row["Reason"]] = []
        bm2bm[row["Reason"]].append([row["SubReason"],row["id"]])
    BM2BM_Reasons = bm2bm

RefreshSM2SMReasons()



def USerLogIn(UName, UPass, UIP=""):
    global key
    global SessionDuration
    global ActiveSessions
    SQL="Select * from HES.dbo.SAI_UserAccount where UserName='" + UName + "'"
    #conn = pyodbc.connect('DRIVER={SQL Server};SERVER=10.90.10.173,21532;DATABASE=HES;UID=Clevest;PWD=!C13ve$T')
    UData = pd.read_sql(SQL, conn)
    if len(UData)>0:
        dbPass = UData.iloc[0].Password
        encPass = dbPass.encode()
        DBPure = fernet.decrypt(encPass).decode()
        UData = UData.fillna("")
        if DBPure==UPass:
            APPs = pd.read_sql("Select Apps.AppName, Apps.AppRout, Apps.AppDisc, Apps.AppIcon from HES.dbo.SAI_UserAppAssociation UAA inner join HES.dbo.SAI_Applications APPs on APPs.id = UAA.ApplicationId where UAA.Userid='" + str(UData.iloc[0].id) + "'  order by Apps.AppName",conn)
            Areas = pd.read_sql("Select Area from HES.dbo.SAI_UserAreaAssociation where UserId='" + str(UData.iloc[0].id) + "' order by Area",conn)
            Auths = pd.read_sql("select AuthCode from HES.dbo.SAI_Auths where id in (select authid from hes.dbo.SAI_UserAuths where userid = " + str(UData.iloc[0].id) + ")",conn)
            EAreas = pd.read_sql("Select Area from HES.dbo.SAI_UserEditAreasAssociation where UserId='" + str(UData.iloc[0].id) + "' order by Area",conn)
            EDate = datetime.today() + SessionDuration
            CSID = str(uuid.uuid1())
            # print('User Name:-->"'+ UName +'"     SessionId:'+ CSID)
            logging.info('User Name:-->"'+ UName +'"     SessionId:'+ CSID)

            UApps = []
            for index, row in APPs.iterrows():
                UApps.append({"AppName":row.AppName, "AppRout": row.AppRout, "AppDisc": row.AppDisc, "AppIcon":row.AppIcon})
            UAreas=[]
            for index , row in Areas.iterrows():
                UAreas.append(str(row.Area))
            UEAreas=[]
            for index , row in EAreas.iterrows():
                UEAreas.append(str(row.Area))
            UAuths = []
            for index , row in Auths.iterrows():
                UAuths.append(row.AuthCode)    
            UserSessionData = {
                                "UserName":UName,
                                "UserFName":UData.iloc[0].FirstName + ' ' + UData.iloc[0].LastName,
                                "UserId":str(UData.iloc[0].id),
                                "Mail" : UData.iloc[0].Mail,
                                "Apps":UApps,
                                "Areas":UAreas,
                                "EAreas" : UEAreas,
                                "Auths":UAuths,
                                "ExpriationDate":EDate.strftime("%Y-%m-%d %H:%M:%S"),
                                "ForcePassChange" : str(UData.iloc[0].ForcePassChange),
                                "LastConnection" : datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                "StartDate" : datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                                "SessionID" : CSID
                               }
            ActiveSessions[CSID] = UserSessionData
            LoginToken = jwt.encode(UserSessionData, key)
            cr = conn.cursor()
            cr.execute("Insert into [HES].[dbo].[SAI_UserSessions] ([SessionId],[UserId],[Status],[Token],[IP]) Values ('"+ CSID +"','"+ UserSessionData["UserId"] +"','A','"+ LoginToken +"','"+ UIP +"')")
            conn.commit()
            return True, CSID
        else:
            return False, ""
        
    else:
        return False, ""
    

def CheckAppInSession(SID, SRCRoute):
    global ActiveSessions
    if SID in ActiveSessions:
        for App in ActiveSessions[SID]["Apps"]:
            if App["AppRout"] == SRCRoute:
                return True
    return False

def CheckAreasInAreas(SID ,Area, Target = 'V'):
    try:
        if Area in ActiveSessions[SID]["Areas" if Target== 'E' else "EAreas"]:
            return True
        else:
            return False
    except:
        return False



def RemoveUserActiveSessions(UName):
    UserASessions=[]
    for KK in ActiveSessions.keys():
        if ActiveSessions[KK]["UserName"] == UName:
            UserASessions.append(KK)
    for LL in UserASessions:
        del ActiveSessions[LL]
    return len(LL)

def RemoveUserActiveSessionsByID(Uid):
    UserASessions=[]
    for KK in ActiveSessions.keys():
        if ActiveSessions[KK]["UserId"] == Uid:
            UserASessions.append(KK)
    for LL in UserASessions:
        del ActiveSessions[LL]
        cr=conn.cursor()
        cr.execute("update [HES].[dbo].[SAI_UserSessions] set [Status]='X' where SessionId='"+ LL +"'")
        conn.commit()
    return len(UserASessions)


def RemoveSession(SessionID):
    try:
        del ActiveSessions[SessionID]
        cr=conn.cursor()
        cr.execute("update [HES].[dbo].[SAI_UserSessions] set [Status]='X' where SessionId='"+ SessionID +"'")
        conn.commit()
    except:
        pass
    return True

def PasswordChange(UName,OldPass, NewPass):
    encNPass = fernet.encrypt(NewPass.encode()).decode()
    global key
    global SessionDuration
    global ActiveSessions
    SQL="Select * from HES.dbo.SAI_UserAccount where UserName='" + UName + "'"
    #conn = pyodbc.connect('DRIVER={SQL Server};SERVER=10.90.10.173,21532;DATABASE=HES;UID=Clevest;PWD=!C13ve$T')
    UData = pd.read_sql(SQL, conn)
    if len(UData)>0:
        dbPass = UData.iloc[0].Password
        encPass = dbPass.encode()
        DBPure = fernet.decrypt(encPass).decode()
        if DBPure == OldPass:
            uSQL = "update [HES].[dbo].[SAI_UserAccount] set [ForcePassChange]=0, [Password] = '"+ encNPass +"' where id=" + str(UData.iloc[0]["id"])
            k=0
            while k >= 0 and k < 10:
                k += 1
                try:
                    cr = conn.cursor()
                    cr.execute(uSQL)
                    conn.commit()
                    k = -1
                except:
                    time.sleep(.5)
            if k== -1:
                RemoveUserActiveSessions(UName)
                return {"Status" : True}
            else:
                return {"Status" : False, "Reason":"DB Connection error..."}
        else:
            return {"Status":False, "Reason":"Old Password not match."}
    else:
        return {"Status":False, "Reason":"Wrong Username"}

def ForcePassChange(UName, NewPass):
    encNPass = fernet.encrypt(NewPass.encode()).decode()
    global key
    global SessionDuration
    global ActiveSessions
    SQL="Select * from HES.dbo.SAI_UserAccount where UserName='" + UName + "'"
    #conn = pyodbc.connect('DRIVER={SQL Server};SERVER=10.90.10.173,21532;DATABASE=HES;UID=Clevest;PWD=!C13ve$T')
    UData = pd.read_sql(SQL, conn)
    if len(UData)>0:
        dbPass = UData.iloc[0].Password
        encPass = dbPass.encode()
        uSQL = "update [HES].[dbo].[SAI_UserAccount] set [ForcePassChange]=0, [Password] = '"+ encNPass +"' where id=" + str(UData.iloc[0]["id"])
        k=0
        while k >= 0 and k < 10:
            k += 1
            try:
                cr = conn.cursor()
                cr.execute(uSQL)
                conn.commit()
                k = -1
            except:
                time.sleep(.5)
        if k== -1:

            return {"Status" : True}
        else:
            return {"Status" : False, "Reason":"DB Connection error..."}
    else:
        return {"Status":False, "Reason":"Wrong Username"}


@app.route('/Notfound500')
def error500():
    abort(500)

# @app.route('/Notfound404')
# def error404():
#     abort(404)

@app.errorhandler(404)
def page_not_found(error):
    return render_template("404.html")

@app.errorhandler(500)
def server_issue(error):
    ErrorTime = datetime.now().strftime("%d-%m-%Y %H:%M:%S")
    msgbody = """
                <br>
                <p>Issue proccessing the following URL: """+request.url+"""</p>
                <p>"""+ErrorTime+"""  </p>
                <br>"""
    # mailer.SendEmail(['Ehab.Maher@alfanar.com'],[],['Maram.alkhatib@alfanar.com'],"Server Error handling action",msgbody,[])
    # logging.critical("Server Error processing " + request.full_path ) #+ " By user: "+ UId
    return render_template("500.html")



 
@app.route('/', methods=["GET"])    
def home():
    SID = request.cookies.get('SID')
    listSample = '''<li><a href="#ROUTE#"><div class="icon"><i class='bx #FileImage#'></i></div>#File#</a></li>'''
    DWNLDList = pd.read_sql("select * from SAI_FilesDownloads where Enabled='y'",conn)
    downloads = ""
    for index, row in DWNLDList.iterrows():
        downloads += listSample.replace("#ROUTE#",'/downloads/' + row.LinkCode).replace("#FileImage#",row.FileImages).replace("#File#",row.FileName)
        # print (downloads)
    if TestAndExtendSession(SID):

        return render_template('AllApplication.html', DownloadList = downloads)
    else:
        resp = make_response(render_template('AllApplication.html', DownloadList = downloads))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp
 
#Start
@app.route('/Login', methods=["GET","POST"])
def LogIN():
    global ActiveSessions
    SID = request.cookies.get('SID')
    if request.method=="GET":
        #print(request.method)
        if TestAndExtendSession(SID):
            resp = make_response(redirect("./", code=302))
            resp.set_cookie("LoggedIn","True")
            resp.set_cookie("SID",SID)
            resp.set_cookie("UserName", ActiveSessions[SID]["UserFName"])
            return resp
            
        else:
            return render_template('Login.html')
    else:
        uname=request.form.get('UserName')
        upass=request.form.get('Password')
        AfterTo = request.form.get('PNext')
        ip = request.remote_addr
        Logged, SID = USerLogIn(uname, upass, ip)
        if Logged:
            resp = make_response(redirect("./" + AfterTo, code=302))
            resp.set_cookie("LoggedIn","True")
            resp.set_cookie("SID",SID)
            resp.set_cookie("UserName", ActiveSessions[SID]["UserFName"])
            return resp
        else:
            hostname = socket.gethostname()
            ip_address = socket.gethostbyname(hostname)
            logging.warning("Failed Login by " + str(ip_address) +" with Username: " + str(uname) + " Password: "+ str(upass))
            resp = make_response(render_template("GeneralMessage.html", MsgTitle="Login", MSGBody="Wrong Username/Password.", msgcolor = "red", BackTo="/Login"))
            resp.set_cookie("LoggedIn","False")
            resp.set_cookie("SID","")
            resp.set_cookie("ExpireDate", "")
            return resp
        
@app.route('/logout', methods=["GET"])
def LogOut():
    SID = request.cookies.get('SID')
    global ActiveSessions
    
    try:
        del ActiveSessions[SID]
        cr = conn.cursor()
        cr.execute("Update [HES].[dbo].[SAI_UserSessions] set [Status]='X' where [SessionId] = '"+ SID +"'")
        conn.commit()
    except:
        pass
    resp = make_response(redirect("./", code=302))
    resp.set_cookie("LoggedIn","False")
    resp.set_cookie("SID","")
    resp.set_cookie("ExpireDate", "")
    return resp

#Return Applications for the current user session.        
@app.route('/getapps', methods=["GET"])
def getapps():
    global ActiveSessions
    SID = request.cookies.get('SID')
    if SID in ActiveSessions:
        if TestAndExtendSession(SID):
            sss = json.dumps({"data":ActiveSessions[SID]["Apps"]})
            return json.dumps({"data":ActiveSessions[SID]["Apps"]})
        else:
            return json.dumps("{}")
    else:
        return json.dumps("{}")

@app.route('/bm', methods=["GET"])
def PrmiseData2():
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckUserAuth(SID, "MSISD"):
            return render_template('SearchMeter.html')
        else:
            return render_template("GeneralMessage.html", MsgTitle="Meter Search Application", MSGBody="Sorry, you don't have authority for this action.", msgcolor = "red", BackTo="../")
    else:
        resp = make_response(render_template("Login.html", NextPage = "bm"))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp    

        
@app.route('/sm', methods=["GET"])
def PrmiseData():
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckUserAuth(SID, "MSISD"):
            return render_template('SearchMeter.html')
        else:
            return render_template("GeneralMessage.html", MsgTitle="Meter Search Application", MSGBody="Sorry, you don't have authority for this action.", msgcolor = "red", BackTo="../")
    else:
        resp = make_response(render_template("Login.html", NextPage = "sm"))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/sm/showdata', methods=["POST"])
def ShowOrderData():
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        SearchKey = request.form.get('searchmethod')
        SearchData = request.form.get('SCriteria')
        SearchSRC = request.form.get('searchsource')
        if SearchSRC == "SEC":
            SData = GMD.GetMeterData(SearchKey, SearchData)
        else:
            SData = GMD.GetMeterDataCL(SearchKey, SearchData)
        # logging.debug(str(SData)+ str(ActiveSessions[SID]["UserFName"]))

        if "data" in SData:
            if SData['data']['Office'] in ActiveSessions[SID]["Areas"]:
                mtype = SData['data']['MeterType']
                if mtype  == "DCU":
                    accountNum = "0"
                else:
                    accountNum =  SData['data']['AccountNumber'] 

                TTT='http://maps.google.com/maps?daddr='+ SData['data']['Latitude']+','+  SData['data']['Longitude'] +'&amp;ll='
                OpenBMHTMLStr = '''<form action="../bm/req" method="POST">
                                        <input class="w3-input w3-border" type="text" placeholder="" hidden name="PNum" id="PNum" style="font-weight: bold; text-align: center;" value="'''+ SData['data']['Premise'] +'''" readonly> </input>
                                    <div style="text-align: center;">
                                    <button type="Submit" class="btn btn-primary"  style="width: 50%"><i class='bx bxs-car-mechanic bx-tada' ></i><span> </span>Replace Meter</button>  
                                    </div>
                                    </form>'''
                ByPassMeterHTMLStr = '''<form action="../bypass/meter" method="POST">
                                      <input class="w3-input w3-border" type="text" placeholder="" required name="MNum2" hidden id="MNum2" style="font-weight: bold; text-align: center;" value="'''+ SData['data']['MeterSN'] +'''"> </input>
                                      <input class="w3-input w3-border" type="text" placeholder="" hidden name="PNum" id="PNum" style="font-weight: bold; text-align: center;" value="'''+ SData['data']['Premise'] +'''" readonly> </input>
                                    <div style="text-align: center;">
                                    <button type="Submit" class="btn btn-primary" style="width: 50%"><i class='bx bx-check-square' ></i><span> </span> Bypass Meter</button>  
                                    </div>
                                    </form>'''
                SiteVisitHTMLStr = '''<form action="../sitevisit/new" method="POST">
                                      <input class="w3-input w3-border" type="text" placeholder="" required name="MNum2" hidden id="MNum2" style="font-weight: bold; text-align: center;" value="'''+ SData['data']['MeterSN'] +'''"> </input>
                                      <input class="w3-input w3-border" type="text" placeholder="" required name="SS2" hidden id="SS2" style="font-weight: bold; text-align: center;" value="'''+ SData['data']['SubScriptionNum'] +'''"> </input>
                                      <input class="w3-input w3-border" type="text" placeholder="" required name="office2" hidden id="office2" style="font-weight: bold; text-align: center;" value="'''+ SData['data']['Office'] +'''"> </input>
                                      <input class="w3-input w3-border" type="text" placeholder="" required name="long2" hidden id="long2" style="font-weight: bold; text-align: center;" value="'''+ SData['data']['Longitude'] +'''"> </input>
                                      <input class="w3-input w3-border" type="text" placeholder="" required name="latt2" hidden id="latt2" style="font-weight: bold; text-align: center;" value="'''+ SData['data']['Latitude'] +'''"> </input>
                                      <input class="w3-input w3-border" type="text" placeholder="" required name="premise2" hidden id="premise2" style="font-weight: bold; text-align: center;" value="'''+ SData['data']['Premise'] +'''"> </input>
                                      <input class="w3-input w3-border" type="text" placeholder="" required name="mtype" hidden id="mtype" style="font-weight: bold; text-align: center;" value="'''+ mtype +'''"> </input>
                                      <input class="w3-input w3-border" type="text" placeholder="" required name="acc2" hidden id="acc2" style="font-weight: bold; text-align: center;" value="'''+ accountNum  +'''"> </input>
                                    <div style="text-align: center;">
                                    <button type="Submit" class="btn btn-primary" style="width: 50%"><i class='bx bxs-plane-alt' ></i><span> </span> Open Site Visit</button>  
                                    </div>
                                    </form>'''
                #print(CheckUserAuth(SID,'SVCR'))
                if mtype == "DCU":
                    return render_template("DCUInformationData.html",\
                                        UserName = ActiveSessions[SID]["UserFName"],\
                                        PremiseNumber=SData['data']['Premise'],\
                                        SubscriptionNumber = SData['data']['SubScriptionNum'],\
                                        AccountNumber=SData['data']['AccountNumber'], \
                                        MeterNumber = SData['data']['MeterSN'],\
                                        OfficeNumber=SData['data']['Office'],\
                                        Location=SData['data']['Latitude'] + ', ' + SData['data']['Longitude'] ,\
                                        MeterType=SData['data']['MeterType'], \
                                        MeterList=SData['data']['MeterList'],\
                                        # SignalStrength=SData['data']['SignalStrength'], \
                                        TMUNumber= SData['data']['DCUSerialNumber'], \
                                        BreakerCapacity =SData['data']['BreakerCapacity'], \
                                        MRU= SData['data']['MRU'],\
                                        EquNum= SData['data']['EquipNum'],\
                                        RSeq= SData['data']['RoutSeq'],\
                                        TransformerID= SData['data']['TransformerID'],\
                                        TransformerRating= SData['data']['TransformerRating'],\
                                        PowerConnected= SData['data']['PowerConnected'],\
                                        PowerConnectionDate= SData['data']['PowerConnectionDate'],\
                                        PowerStatusUpdatedBy= SData['data']['PowerStatusUpdatedBy'],\
                                        CTavailable= SData['data']['CTavailable'],\
                                        CTConnected= SData['data']['CTConnected'],\
                                        CTRatio= SData['data']['CTRatio'],\
                                        # = SData['data'][' '],\
                                        DriveTo = TTT, OpenBM = OpenBMHTMLStr if CheckUserAuth(SID,'BMCO') else '', \
                                        MeterByPass = ByPassMeterHTMLStr if CheckUserAuth(SID,'BPMSD') else '',\
                                        SiteVisitRequest = SiteVisitHTMLStr if CheckUserAuth(SID,'SVCR') else '',\
                                        ALFMeter = "<span> </span><i class='bx bx-message-rounded-check bx-tada' style='color:#33ff00; float: right; font-size: x-large; font-weight: bold;'  ></i>" if IsAlFanarMeter(SData['data']['MeterSN']) else "<span> </span><i class='bx bxs-message-x bx-tada' style='color:red; float: right; font-size: x-large; font-weight: bold;'  ></i>"
                                        ) 

                return render_template("InformationData.html",\
                                        UserName = ActiveSessions[SID]["UserFName"],\
                                        PremiseNumber=SData['data']['Premise'],\
                                        SubscriptionNumber = SData['data']['SubScriptionNum'],\
                                        AccountNumber=SData['data']['AccountNumber'], \
                                        MeterNumber = SData['data']['MeterSN'],\
                                        OfficeNumber=SData['data']['Office'],\
                                        Location=SData['data']['Latitude'] + ', ' + SData['data']['Longitude'] ,\
                                        Technology=SData['data']['Technology'],\
                                        MeterType=SData['data']['MeterType'], \
                                        TarifType= SData['data']['TarifType'], \
                                        PreReading= SData['data']['PreReading'], \
                                        PreReadingDate=SData['data']['PreReadDate'], \
                                        BreakerCapacity =SData['data']['BreakerCapacity'], \
                                        MRU= SData['data']['MRU'],\
                                        EquNum= SData['data']['EquipNum'],\
                                        RSeq= SData['data']['RoutSeq'],\
                                        LBDate= SData['data']['LastBill'],\
                                        BRNumber= SData['data']['BreakerSN'],\
                                        CMNumber= SData['data']['CommModule'],\
                                        DriveTo = TTT, OpenBM = OpenBMHTMLStr if CheckUserAuth(SID,'BMCO') else '', \
                                        MeterByPass = ByPassMeterHTMLStr if CheckUserAuth(SID,'BPMSD') else '',\
                                        SiteVisitRequest = SiteVisitHTMLStr if CheckUserAuth(SID,'SVCR') else '',\
                                        ALFMeter = "<span> </span><i class='bx bx-message-rounded-check bx-tada' style='color:#33ff00; float: right; font-size: x-large; font-weight: bold;'  ></i>" if IsAlFanarMeter(SData['data']['MeterSN']) else "<span> </span><i class='bx bxs-message-x bx-tada' style='color:red; float: right; font-size: x-large; font-weight: bold;'  ></i>"
                                        )
            else:
                #return render_template("MessagePage.html",BColor = "Red", SystemMessage="This meter is out of your coverage areas.", ActionLink="sm", ActionMethod= "GET" )
                return render_template("GeneralMessage.html",msgcolor = "Red", MSGBody="This meter is out of your coverage areas.", MsgTitle="Meter Search Application", BackTo= "/sm" )
        else:
            #return render_template("PageNOTFound.html")
            return render_template("GeneralMessage.html",msgcolor = "Red", MSGBody="Meter Not found using your search criteria.", MsgTitle="Meter Search Application", BackTo= "/sm" )
            
            
        return SearchKey + '--->' + SearchData
    else:
        resp = make_response(render_template("Login.html", NextPage = "sm"))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/sm2sm/open', methods=['POST'])
def CreateSmartToSmartOrder():
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, "/sm2sm"):
            pass
            return "OK"
        else:
            return render_template("MessagePage.html",BColor = "Red", SystemMessage="You don't have authority to open Smart-to-Smart meter replacement.", ActionLink="../", ActionMethod= "GET" )
    else:
        resp = make_response(render_template("Login.html", NextPage = "/sm2sm"))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp


@app.route('/bypass/meter' , methods=["POST"])
def DoByPass():
   
    now = datetime.now()
    MNum = request.form.get('MNum2')
    Premise = request.form.get('PNum')
    SID = request.cookies.get('SID')
    UID = ActiveSessions[SID]["UserId"]
   
    ValidTo = now + timedelta(hours=24)
    formatdate = ValidTo.strftime("%Y-%m-%d %H:%M:%S")
    logging.debug(str(UID)+str(MNum)+str(Premise)+str(ValidTo)+str(formatdate))

 
    InsertStr = """ Insert into [HES].[dbo].[SAI_NCR_MeterByPass]
                    ([Premise],[MeterNumber],[InsertDate], [InsertedBy],[ValidTo])
                    values
                    ('"""+ Premise +"""','"""+ MNum +"""',getDate(), '"""+ str(UID) +"""','"""+ formatdate+"""')                
                """
    # print(InsertStr)
    try:
        cursor = conn.cursor()
        cursor.execute(InsertStr)
        conn.commit()
    # URL = 'http://t-mwfm.alfanar.com:8090/bypass/add'
    # payload = {
    #             'MNum': MNum
    #           }
    # r = requests.post(URL, data=payload)
    # if r.status_code == 200:
    #     if r.text == "OK":
        return render_template("GeneralMessage.html", MsgTitle="Smart to Smart Application", MSGBody="Your meter ("+ MNum +") has been added to bypass list.", msgcolor = "skyblue", BackTo="../sm")
    except:
        return render_template("GeneralMessage.html", MsgTitle="Smart to Smart Application", MSGBody="Your meter ("+ MNum +") not add to bypass list, error has been occured.", msgcolor = "red", BackTo="../sm")
 
SIMLinks = {
            'SCIR':{'TXT':'''<a href='/hhu/sims/SCIR'><button type="button" class="btn btn-primary"><div class="icon"><i class='bx bxs-plane-take-off'></i></div>Request SIMs</button></a><BR>'''},
            'SCR':{'TXT':'''<a href='/hhu/sims/SCR'><button type="button" class="btn btn-primary"><div class="icon"><i class='bx bxs-plane-land'></i></div>Return SIMs</button></a><BR>'''},
            'SCIA':{'TXT':'''<a href='/hhu/sims/SCIA'><button type="button" class="btn btn-primary"><div class="icon"><i class='bx bx-check-square'></i></div>Apprve Requests</button></a><BR>'''},
            'SCIE':{'TXT':'''<a href='/hhu/sims/SCIE'><button type="button" class="btn btn-primary"><div class="icon"><i class='bx bx-transfer-alt'></i></div>Execute request</button></a><BR>'''},
            'SCAR':{'TXT':'''<a href='/hhu/sims/SCAR'><button type="button" class="btn btn-primary"><div class="icon"><i class='bx bx-message-alt-dots'></i></div>Request SIM Activation</button></a><BR>'''},
            'SCDCA':{'TXT':'''<a href='/hhu/sims/SCDCA'><button type="button" class="btn btn-primary"><div class="icon"><i class='bx bx-mobile-alt'></i></div>Approve device change</button></a><BR>'''},
            'SCRDC':{'TXT':'''<a href='/hhu/sims/SCRDC'><button type="button" class="btn btn-primary"><div class="icon"><i class='bx bx-mobile-vibration'></i></div>Request device change</button></a><BR>'''},
            'SCV':{'TXT':'''<a href='/hhu/sims/SCV'><button type="button" class="btn btn-primary"><div class="icon"><i class='bx bx-search-alt'></i></div>View SIM card</button></a><BR>'''},
            'SCDA':{'TXT':'''<a href='/hhu/sims/SCDA'><button type="button" class="btn btn-primary"><div class="icon"><i class='bx bx-wifi'></i></div>Activate SIM</button></a><BR>'''},
            'SCDD':{'TXT':'''<a href='/hhu/sims/SCDD'><button type="button" class="btn btn-primary"><div class="icon"><i class='bx bx-wifi-off'></i></div>Deactivate SIM</button></a><BR>'''}
           }

@app.route('/hhu/sims', methods=["GET"])
def SimManagementSystem():
    SIMsButtons = ''
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, "/hhu/sims"):
            for X in SIMLinks:
                if CheckUserAuth(SID,X):
                    SIMsButtons = SIMsButtons + SIMLinks[X]['TXT']
            return render_template("SIMManagerMain.html", Btns = SIMsButtons)
        return render_template("GeneralMessage.html",msgcolor = "Red", MSGBody="You don't have authority to open SIM card management application.", MsgTitle="SIM Card Application", BackTo= "/hhu/sims" )
    else:
        resp = make_response(render_template("Login.html", NextPage = "/hhu/sims"))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hhu/sims/SCIR', methods=["GET"])
def IssuanceRequest():
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, "/hhu/sims"):
            if CheckUserAuth(SID,'SCIR'):
                return render_template("SIMManagerIssuanceRequest.html")
            else:
                #return render_template("MessagePage.html",BColor = "Red", SystemMessage="You don't have authority to request SIM issuance.", ActionLink="../", ActionMethod= "GET" )
                return render_template("GeneralMessage.html",msgcolor = "Red", MSGBody="You don't have authority to request SIM issuance.", MsgTitle="SIM Card Application", BackTo= "/hhu/sims" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MSGBody="You don't have authority to open SIM card management application.", MsgTitle="SIM Card Application", BackTo= "/hhu/sims" )
    else:    
        resp = make_response(render_template("Login.html", NextPage = "/hhu/sims/SCIR"))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hhu/sims/sendrequest', methods=["POST"])
def IssuanceRequestApply():
    appTxt = "/hhu/sims"
    ThisAuth = 'SCIR'
    ThisRoute = '/hhu/sims/sendrequest'
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                RequestForID = request.form.get('IssueForId')
                RequestForName = request.form.get('IssueForName')
                RequestQty = int(request.form.get('RequestQty'))
                UID = ActiveSessions[SID]["UserId"]
                cursor = conn.cursor()
                SQLIns = "insert into SAI_HHU_SIMs_Requests (RequestBy, RequestDate, ActionType, RequestedQty, RequestForID, RequestForName) values ('"+ str(UID) +"', getdate(), 'issuance', '"+ str(RequestQty) +"', '"+ str(RequestForID) +"','"+ RequestForName +"')"
                cursor.execute(SQLIns)
                conn.commit()
                return render_template("GeneralMessage.html",msgcolor = "SkyBlue", MsgTitle = "SIM Card Issuance Request", MSGBody="Request has been submitted sucessfully, you'll recieve mail after approval.", BackTo="/hhu/sims/SCIR" )
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = "SIM Card Issuance Request", MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
                
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = "SIM Card Issuance Request", MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hhu/sims/SCIA', methods=["GET"])
def ApproveRequests():
    appTxt = "/hhu/sims"
    ThisAuth = 'SCIA'
    ThisRoute = '/hhu/sims/SCIA'
    MTitle = "SIM Card Issuance Approval"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                
                return render_template("SRCSUBForm.html", MyBody=BH.GetHTML_ApproveRequests(conn), PageTitlePy="SIM Card Request Approval") 
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hhu/sims/approverequest', methods=["POST"])
def ApproveRequest():
    appTxt = "/hhu/sims"
    ThisAuth = 'SCIA'
    ThisRoute = '/hhu/sims/SCIA'
    MTitle = "SIM Card Issuance Approval"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                RequestID =  request.form.get('ReqId')
                RequestQty =  request.form.get('ReqQty')
                ActionType =  request.form.get('Action')
                CUID = ActiveSessions[SID]["UserId"]
                if ActionType == 'Approve':
                    SQLStr = "update SAI_HHU_SIMs_Requests set ApprovalStatus=1, ApprovedBy = "+ CUID +", ApproveDate=getdate() , ApprovedQty= "+ RequestQty +" where id =" + RequestID
                else:
                    SQLStr = "update SAI_HHU_SIMs_Requests set ApprovalStatus=0, ApprovedBy = "+ CUID +", ApproveDate=getdate() , ApprovedQty= 0 where id =" + RequestID
                cursor = conn.cursor()
                cursor.execute(SQLStr)
                conn.commit()
                #Send Mail for recieving
                return render_template("SRCSUBForm.html", MyBody=BH.GetHTML_ApproveRequests(conn), PageTitlePy="SIM Card Request Approval")
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp    
#C:\System\SIA\ActiveInv\downloads

@app.route('/downloads/<path:filename>', methods=['GET'])
def downloadfile(filename):
    files = pd.read_sql("select * from SAI_FilesDownloads where [LinkCode]='"+ filename +"'", conn)
    if len(files) > 0 :
        # print(os.path.join(app.instance_path, ''))
        logging.debug(os.path.join(app.instance_path))

        return send_from_directory(os.path.join(app.instance_path, ''),files.iloc[0].ServerFileName, as_attachment=True)
    else:
        return render_template("GeneralMessage.html", MsgTitle="Downloading File Failed", msgcolor="red", MSGBody="Wrong link, or you don't have authority to download this file.", BackTo='/' )


#----------------------------------------------------------------------------------------------------
#-------------------------------------------------Burnt Meter--------------------------------
#----------------------------------------------------------------------------------------------------
@app.route('/bm/openbm', methods=["POST"])
def RequestBMOrderCreation():
    appTxt = "/bm"
    ThisAuth = 'SCIA'
    ThisRoute = '/bm/openbm'
    MTitle = "Smart To Smart Meter Replacement"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                Premise = request.form.get('PNum')
                return render_template("SRCSUBForm.html", MyBody=BH.GetHTML_OpenBM(Premise), PageTitlePy=MTitle) 
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp



#----------------------------------------------------------------------------------------------------
#-------------------------------------------------USER Administration--------------------------------
#----------------------------------------------------------------------------------------------------
@app.route("/admin/users/new", methods=["GET"])
def CreateNewUserForm():
    appTxt = "/admin"
    ThisAuth = 'ACNU'
    ThisRoute = '/admin/users/new'
    MTitle = "User Creation"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                return render_template("SRCSUBForm.html", MyBody = BH.GetUserCreationForm(), PageTitlePy="System Administration")
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route("/admin/users/create" , methods=["POST"])
def CreateNewUser():
    appTxt = "/admin"
    ThisAuth = 'ACNU'
    ThisRoute = '/admin/users/create'
    MTitle = "User Creation"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                NUName = request.form.get('TXTUName')
                NUFName = request.form.get('TXTUFName')
                NULName = request.form.get('TXTULName')
                NUMail = request.form.get('TXTUMail')
                NUMobile = request.form.get('TXTUMobile')
                NUPass = request.form.get('PassCriteria')
                DBUNames = pd.read_sql("Select UserName from HES.dbo.SAI_UserAccount where UserName='"+ NUName +"'", conn)
                if len(DBUNames)==0:
                    if NUPass == "Def":
                        Npassword = "12345678"
                    else:
                        Npassword = "%(#)06d" % {"#" : int(random.random() * 1000000)}
                    encPass = fernet.encrypt(Npassword.encode()).decode()
                    SQLIns = """
                                insert into HES.dbo.[SAI_UserAccount] 
                                    ([UserName],[FirstName],[LastName],[Mail],[MobileNum],[Password],[EnableFlag],[CreatedBy],[CreationDate]) 
                                values 
                                    ('"""+ NUName +"""','"""+ NUFName +"""','"""+ NULName +"""','"""+ NUMail +"""','"""+ NUMobile +"""','"""+ encPass +"""',1,'"""+ ActiveSessions[SID]["UserId"] +"""',getdate())
                            """
                    cursor = conn.cursor()
                    cursor.execute(SQLIns)
                    conn.commit()
                    if NUPass == "Aut":
                        UM.CreateNeSendNewUserMailwUser(NUName,NUFName,NULName,Npassword ,NUMail)
                    


                else:
                    return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="Username ("+ NUName +") already exits.", BackTo="/admin/users/new" )
                
                return render_template("SRCSUBForm.html", MyBody = BH.GetUserCreationForm(), PageTitlePy="System Administration")
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo=appTxt )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route("/admin/users/sysop/<uid>/<actionName>/<parS>" , methods=["POST"])
def systemPassReset(uid, actionName, parS):
    if request.headers["Authorization"] == SystemToken:
        if actionName == "PasswordReset":
            reqD = json.loads(parS)
            if "NewPassword" in reqD.keys():
                NewPassword = reqD["NewPassword"]
            else:
                NewPassword = "%(#)06d" % {"#" : int(random.random() * 1000000)}
            
            


    else:
        return make_response("Token Error", 401)

@app.route("/accman" , methods=["GET"])
def UserAccounP():
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if request.method=="GET":
            return render_template("UserAccount.html", UserName=ActiveSessions[SID]["UserFName"])
        return redirect("/")
    else:    
        resp = make_response(render_template("Login.html", NextPage = "/accman"))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp


@app.route("/user/changepass" , methods=["POST","GET"])
def ChangePass():
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if request.method=="GET":
            return render_template("ChangePass.html")
        userData = ActiveSessions[SID]
        UName = userData["UserName"]
        oPass = request.form.get("oldpass")
        nPass1 = request.form.get("psw")
        nPass2 = request.form.get("rpsw")
        if nPass1 == nPass2:
            CHGPass = PasswordChange(UName,oPass,nPass1)
            if CHGPass["Status"]:
                return render_template("GeneralMessage.html",msgcolor = "Lime", MsgTitle = "Password Change", MSGBody="Password has been changed, you'll need to re-login", BackTo="/" )
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = "Password Change", MSGBody="Error happened, try again or contact administrator. ("+ CHGPass["Reason"] +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = "Password Change", MSGBody="New password don't match re-enter.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = "/user/changepass"))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp


@app.route("/admin/user/passchange/<uid>",  methods=["POST","GET"])
def adminUserPassChange(uid):

    temp_conn = pyodbc.connect('DRIVER={SQL Server};SERVER=10.90.10.173,21532;DATABASE=HES;UID=Clevest;PWD=!C13ve$T')
    UData = pd.read_sql("Select * from HES.dbo.SAI_UserAccount where UserName='"+uid+"'", conn)
    NUName = UData.iloc[0].UserName
    NUFName = UData.iloc[0].FirstName
    NULName = UData.iloc[0].LastName
    NUMail = UData.iloc[0].Mail
    Npassword = "%(#)06d" % {"#" : int(random.random() * 1000000)}
    encNPass = fernet.encrypt(Npassword.encode()).decode()
    print(NUName,NUFName,NULName,NUMail)
    uSQL = "update [HES].[dbo].[SAI_UserAccount] set [ForcePassChange]=0, [Password] = '"+ encNPass +"' where id=" + str(UData.iloc[0]["id"])
    # cr = conn.cursor()
    # cr.execute(uSQL)
    # conn.commit()
    # cr.close()
    # conn.close()
    # UM.UserDataModifiedMail(NUName,NUFName,NULName,Npassword ,NUMail) 
    return "Password changed for user " + NUFName + " " + NULName + "("+NUName+")" + " to" + Npassword


#--------------------------------------------------------------------------------
#------------------------------Site Visit----------------------------------------
@app.route('/sitevisit', methods=["GET"])
def SiteVisitApp():
    appTxt = "/sitevisit"
    ThisAuth = 'SVSS'
    ThisRoute = '/sitevisit'
    MTitle = "Site Visit Creation"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                return redirect("/sm")
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

#--------------------------------------------------------------------------------
@app.route('/sitevisit/new', methods=['POST'])
def GoToMySites():
    appTxt = "/sitevisit"
    ThisAuth = 'SVCR'
    ThisRoute = '/sitevisit/new'
    MTitle = "Site Visit Creation"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                UserName = ActiveSessions[SID]["UserFName"]
                PremiseNumber = request.form.get("premise2")
                SubscriptionNumber = request.form.get("SS2")
                AccountNumber = request.form.get("acc2")
                MeterNumber = request.form.get("MNum2")
                Longitude = request.form.get("long2")
                Lattitude= request.form.get("latt2")
                Office = request.form.get("office2")
                return render_template("SiteVisit.html", UserName=UserName, PremiseNumber=PremiseNumber, SubscriptionNumber=SubscriptionNumber, AccountNumber=AccountNumber, MeterNumber=MeterNumber, Longitude=Longitude, Lattitude=Lattitude, Office=Office )
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp


@app.route('/sitevisit/create', methods=['POST'])
def CreateVisitOrder():
    appTxt = "/sitevisit"
    ThisAuth = 'SVCR'
    ThisRoute = '/sitevisit/create'
    MTitle = "Site Visit Creation"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                Office = request.form.get("Office")
                if CheckAreasInAreas(SID,Office, "E"):
                    UserName = "Creating Visit Order"
                    UName = ActiveSessions[SID]["UserName"]
                    PremiseNumber = request.form.get("PNum")
                    SubscriptionNumber = request.form.get("SSNum")
                    AccountNumber = request.form.get("AccNum")
                    MeterNumber = request.form.get("MNum")
                    Longitude = request.form.get("Long")
                    Lattitude= request.form.get("Latt")
                    BG = GFs.GetBusinessGroup(Office, "OM")
                    complainEn = request.form.get("reasonEn")
                    complainAr = request.form.get("reasonAr")
                    requestedBy = request.form.get("requester")
                    logging.info('Site visit created for order: '+PremiseNumber+' '+complainEn+' '+UName)

                    payload = {
	                            "Premise" : PremiseNumber + '_' + datetime.today().strftime("%Y%m%d"),
	                            "BG" : BG,
	                            "Complaint" : complainEn,
	                            "Office" : Office,
	                            "ComplaintAR" : complainAr,
	                            "Subscription" : SubscriptionNumber,
	                            "accountnumber" : AccountNumber,
	                            "Long" : Longitude,
	                            "Latt" : Lattitude,
	                            "MeterNumber" : MeterNumber,
                                "ReportedBy" : requestedBy,
                                "IssueDate" : datetime.today().strftime("%Y-%m-%d %H:%M"),
                                "CreatedBy" : UName
                              }

                    return render_template("GeneralMessage.html",msgcolor = "lime", MsgTitle = MTitle, MSGBody="Your order has been Created, check in clevest in few seconds.", BackTo="/" ) if GFs.SendToClevest('SVCreate',payload) else render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="Error Happened contact you administrator.", BackTo="/" )
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have access to create site visit in this office.("+ Office +")", BackTo="/" )
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp



@app.route('/sitevisit/createBulk', methods=['POST'])
def CreateVisitOrderBulk():
    # CSV --> JSON [Pnum,reasonEn,requester]
    data = request.json 
    MTitle = "Site Visit Creation"
    # print(data)
    for i in data:
        try:
            MyMeter = SECMD[SECMD["Premise"]== i["Pnum"]]
            Office = MyMeter.iloc[0]["Office"]
            PremiseNumber =  MyMeter.iloc[0]["Premise"]
            SubscriptionNumber =  MyMeter.iloc[0]["Subscription No"]
            AccountNumber =  MyMeter.iloc[0]["Account No"]
            MeterNumber = MyMeter.iloc[0]["fg. Ser. No"]
            Longitude =  MyMeter.iloc[0]["Longitude"]
            Lattitude=  MyMeter.iloc[0]["Latitude"]
            # print(Office)
            BG = GFs.GetBusinessGroup(str(Office), "OM")
            complainEn = i["reasonEn"]
            requestedBy = i["requester"]
            payload = {
                        "Premise" : str(PremiseNumber) + '_' + datetime.today().strftime("%Y%m%d"),
                        "BG" : BG,
                        "Office" : Office,
                        "Subscription" : SubscriptionNumber,
                        "accountnumber" : AccountNumber,
                        "Long" : Longitude,
                        "Latt" : Lattitude,
                        "MeterNumber" : MeterNumber,
                        "ReportedBy" : requestedBy,
                        "Complaint" : complainEn,
                        "IssueDate" : datetime.today().strftime("%Y-%m-%d %H:%M")
                        }
            print(payload)
            GFs.SendToClevest('SVCreate',payload)
        except:
            print("~~~~~~~~~~~~~~~~~~~~~~~")
            print("A FAIL")
            print(i)
            print(MyMeter)
            print("~~~~~~~~~~~~~~~~~~~~~~~")
    print(str("Done"))
    # return "Done"
    return render_template("GeneralMessage.html",msgcolor = "lime", MsgTitle = MTitle, MSGBody="Your order has been Created, check in clevest in few seconds.", BackTo="/" )

#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#ECB

@app.route('/ecb', methods=['GET'])
def ECBRev():
    appTxt = "/ecb"
    ThisAuth = 'RECO'
    ThisRoute = '/ecb'
    MTitle = "ECB Order Revision"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                Uid = ActiveSessions[SID]["UserId"]
                SQL="""select tt.* , (tt.TotalOrders-tt.ClosedOrders) as PendingOrders
                        from (
                                select
                                (select count(premise) from [HES].[dbo].[ECB_ReviseData])  as TotalOrders ,(
                                Select count(premise)  from [HES].[dbo].[ECB_ReviseData] where [InspectionDate] is not null) as ClosedOrders,
                                (Select count(premise) from [HES].[dbo].[ECB_ReviseData] where [InspectionDate] is not null and [UserId]=UUUID) as MyClose) tt
                    """.replace("UUUID", str(Uid))
                TOrdersSummary = json.loads( pd.read_sql(SQL, conn).to_json(orient="index"))["0"]

                return render_template("ECBTemplates/ECBRev.html", TotalOrders= TOrdersSummary["TotalOrders"], TotalClosed=TOrdersSummary["ClosedOrders"], TotalPending=TOrdersSummary["PendingOrders"], MyClosed= TOrdersSummary["MyClose"])
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp




 
    

@app.route('/ecb/getorder', methods=['GET','POST'])
def ECBRevOrder():
    appTxt = "/ecb"
    ThisAuth = 'RECO'
    ThisRoute = '/ecb/getorder'
    MTitle = "ECB Order Revision"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                Uid = ActiveSessions[SID]["UserId"]
                UserOrder = ECR.GetOrderForUser(Uid)
                Photos = []
                for  mphoto in UserOrder["Photos"]["photos"]:
                    Photos.append(mphoto[1:])
                RESP = {
                    "id": UserOrder["id"],
                    "Premise": UserOrder["Premise"],
                    "HON": UserOrder["HON"],
                    "UserId": UserOrder["UserId"],
                    "PickDate": UserOrder["PickDate"],
                    "WNO": UserOrder["WNO"],
                    "SN": UserOrder["SN"],
                    "FinalCompletionDate": UserOrder["FinalCompletionDate"],
                    "Office": UserOrder["Office"],
                    "CON": UserOrder["CON"],
                    "Qustions": ECR.Questions,
                    "Photos": Photos

                }
                #print (RESP)
                json_data = RESP
                images = json_data["Photos"]
                CON=json_data['CON']
                FinalCompletionDate=json_data['FinalCompletionDate']
                HON = json_data['HON']
                Office  = json_data['Office']
                PickDate = json_data['PickDate']
                SN = json_data['SN']
                WNO = json_data['WNO']
                Premise=json_data['Premise']
                UserId= json_data['UserId']
                id=json_data['id']
                ques = json_data['Qustions']
                #return json.dumps(RESP)
                return render_template("pickorder.html", **locals())
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/ecb/updaterecord', methods=['POST'])
def UpdateECBData():
    appTxt = "/ecb"
    ThisAuth = 'RECO'
    ThisRoute = '/ecb'
    MTitle = "ECB Order Update after revision"
    SID = request.cookies.get('SID')
    
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                Uid = ActiveSessions[SID]["UserId"]
                oId = request.form.get("id")
                HON = request.form.get("MyHON")
                QestionsAns ={}
                NumberOfNOK = 0
                for i in range(20):
                    try:
                        if request.form.get("Q" + ('0' if i<10 else '')+str(i)) :
                            QestionsAns['INSP0' + ('0' if i<10 else '') + str(i)] = request.form.get("Q" + ('0' if i<10 else '')+str(i))
                            if request.form.get("Q" + ('0' if i<10 else '')+str(i)) == 'n':
                                NumberOfNOK += 1
                    except:
                        print(('0' if i<10 else ''))
                        logging.warning(('0' if i<10 else ''))

                sqlSP = ""
                for pp in QestionsAns.keys():
                    sqlSP += "," + pp + "='"+ QestionsAns[pp] +"' "
                SQLUpdate = "update [HES].[dbo].[ECB_ReviseData] set [InspectionDate]= GETDATE() "+ sqlSP +" where id = '"+ oId +"'"
                #cr = conn.cursor()
                #cr.execute(SQLUpdate)
                #conn.commit()
                ECR.updatetheorder(SQLUpdate)
                #if NumberOfNOK > 0 :
                #    ECR.UnAssignECB(HON)
                return redirect("/ecb")
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#-------------------------Smart To Smart Replacement-----------------------------
#--------------------------------------------------------------------------------


@app.route('/bm/req', methods=['POST','GET'])
def BMRequest():
    appTxt = "/bm"
    ThisAuth = 'BMCO'
    ThisRoute = '/bm/req'
    MTitle = "Site Equipment Replacement"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                MyMeter = SECMD[SECMD["Premise"]== request.form.get("PNum")]
                bypassMeterType = IsinByPassList(MyMeter.iloc[0]["Premise"])
                if len(MyMeter) > 0 :
                    if IsAlFanarMeter(MyMeter.iloc[0]["fg. Ser. No"]) or IsinByPassList(MyMeter.iloc[0]["Premise"]):
                        Office = MyMeter.iloc[0]["Office"]
                        #print(ActiveSessions[SID])
                        if Office in ActiveSessions[SID]["EAreas"]:
                            PremiseNumber= MyMeter.iloc[0]["Premise"]
                            MeterNumber=MyMeter.iloc[0]["fg. Ser. No"]
                            SubscriptionNumber=MyMeter.iloc[0]['Subscription No']
                            AccountNumber=MyMeter.iloc[0]['Account No']
                            BreakerCapacity=MyMeter.iloc[0]["Breaker Cap."]
                            #cols=['Premise','MRU','Office','fg. Ser. No','Meter Type','Equip. No','Cycle','Last Bill Key','Route Read Seq','MR Note','Date of MR Note','Critical Need','Service Class','Premise Address','City','District','Subscription No','Account No','BPName','BP Type','Latitude','Longitude','Mult. Factor','No. of Dials','Breaker Cap.','Voltage','Phase','Tariff Type','Prev Read Date T','Prev. Read T','Prev Read Date T1','Prev. Read T1','Prev. Read Date T2','Prev. Read T2','Prev Read Date T3','Prev. Read T3','Prev. Read Date T4','Prev. Read T4','Prev. Read Date T5','Prev. Read  T5','Prev. Read Date T6','Prev. Read  T6','Prev. Read Date T7','Prev. Read  T7','Avg. Consp. per day (kWh)','Accl. Premise No','Main Premise No','Conn. Type', 'F1','F2']
                            subreason = BM2BM_Reasons
                            if MyMeter.iloc[0]["Meter Type"] == "DCU":
                                DCUReq = "Y"
                                MeterList=MyMeter.iloc[0]["MeterList"]
                                DCUSerialNumber=MyMeter.iloc[0]["DCUSerialNumber"]
                                TransformerID=MyMeter.iloc[0]["TransformerID"]
                                TransformerRating=MyMeter.iloc[0]["TransformerRating"]
                                PowerConnected=MyMeter.iloc[0]["PowerConnected"]
                                PowerConnectionDate=MyMeter.iloc[0]["PowerConnectionDate"]
                                PowerStatusUpdatedBy=MyMeter.iloc[0]["PowerStatusUpdatedBy"]
                                CTavailable=MyMeter.iloc[0]["CTavailable"]
                                CTConnected=MyMeter.iloc[0]["CTConnected"]
                                CTRatio=MyMeter.iloc[0]["CTRatio"]
                            
                            return render_template('Replacement.html', **locals())
                        else:
                            return  render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You're trying to open order in out of your offices, Premise ("+ request.form.get("PNum") +") in Office ("+ Office +")", BackTo="/" )                            
                    else:
                        return  render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="This meter is not related to Al Fanar.", BackTo="/" )
                        
                else:
                    return  render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="Wrong Entered Premise, Or premise not found.", BackTo="/" )
                 
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#-------------------------Smart To Smart Replacement-----------------------------
#--------------------------------------------------------------------------------
omBGs = {
         '11' : 'OM_Riyadh',
         '14' : 'OM_Riyadh Outer',
         '13' : 'OM_AlKharj',
         '15' : 'OM_Hail',
         '12' : 'OM_Qassim',
         '16' : 'OM_Dawadimi',
         '31' : 'OM_Dammam',
         '33' : 'OM_North_Area',
         '35' : 'OM_Northern_Border',
         '32' : 'OM_Hassa',
         '34' : 'OM_Aljouf'
        }

OrdersForOpen= {}

def OpenClevestOrders():
    clConn = pyodbc.connect(ClConnectionStr)
    cr = clConn.cursor()
    global OrdersForOpen
    ClevestTargetLink = 'http://mwfm.alfanar.com/MWFM/api/MethodInvocations/SMR_Create?api-version=1'
    Auths = {"UserName" : "sap_api", "Password":"123456"}
    headers = {'Content-Type': 'application/json'}
    auth = HTTPBasicAuth(Auths["UserName"], Auths["Password"])
    while True:

        while len(OrdersForOpen.keys()) > 0:
            inProcess = {}
            myK = ""
            for k in OrdersForOpen.keys():
                inProcess = OrdersForOpen[k]
                myK = k
                pass
            print(inProcess["PNum"])
            SQLStr = "select HostOrderNumber from WorkOrderMapping where HostOrderNumber like '"+ inProcess["PNum"] +"%' and OrderStatusId not in (100, 80) and ordertypeid in (1,5)"
            runningOrders = pd.read_sql(SQLStr, clConn)
            if len(runningOrders) > 0 :
                try:
                    mailIt.SendEmail([inProcess["Mail"]],[],"Replacement Order Creation -"+ inProcess["PNum"] +"-","Other replacement order in progress,\nYour request has been rejected.",[])
                except:
                    pass
                OrdersForOpen.pop(myK, None)
            else:
                MyMeter = SECMD[SECMD["Premise"]== inProcess["PNum"]]
                if MyMeter.iloc[0]["Meter Type"] == "DCU":
                    print("MeterType test")
                    if len(inProcess["PNum"]) == 20:
                        try:
                            SQL_NewSer = """select max(convert(int,substring(hostordernumber,23,10))) + 1 as NewSer
                                        from WorkOrderMapping
                                        where HostOrderNumber like '"""+ inProcess["PNum"] +"""-R%'"""
                        except Exception as e:
                            # print("Issue with DCU Premise number " + inProcess["PNum"] + " CODE D1" )
                            logging.error("Issue with DCU Premise number " + inProcess["PNum"] + " CODE D1")
                    elif len(inProcess["PNum"]) == 15:
                        try:
                            SQL_NewSer = """select max(convert(int,substring(hostordernumber,18,10))) + 1 as NewSer
                                    from WorkOrderMapping
                                    where HostOrderNumber like '"""+ inProcess["PNum"] +"""-R%'"""
                        except Exception as e:
                            # print("Issue with DCU Premise number " + inProcess["PNum"] + " CODE D2" )
                            logging.error("Issue with DCU Premise number" + inProcess["PNum"] + " CODE D2")
                    else:
                        # print("Issue with DCU Premise number" + inProcess["PNum"] + " CODE D3")
                        logging.error("Issue with DCU Premise number" + inProcess["PNum"] + " CODE D3")
                else:
                    
                    try:
                        SQL_NewSer = """select max(convert(int,substring(hostordernumber,13,10))) + 1 as NewSer
                                    from WorkOrderMapping
                                    where HostOrderNumber like '"""+ inProcess["PNum"] +"""-R%'"""
                    except Exception as e:
                        # print("Issue with Premise number " + inProcess["PNum"] + " CODE P1" )
                        logging.error("Issue with Premise number " + inProcess["PNum"]+ " CODE P1")
                NewHON =(inProcess["PNum"] + '-R{0:07d}').format(pd.read_sql(SQL_NewSer, clConn).fillna(1).iloc[0].NewSer)
                print(NewHON)

                logging.info("Opening Clevest Order HON: "+NewHON)
                # print("Opening Clevest Order HON: "+NewHON)
                #cols=['Premise','MRU','Office','fg. Ser. No','Meter Type','Equip. No','Cycle','Last Bill Key','Route Read Seq','MR Note','Date of MR Note','Critical Need',
                # 'Service Class','Premise Address','City','District','Subscription No','Account No','BPName','BP Type','Latitude','Longitude','Mult. Factor','No. of Dials',
                # 'Breaker Cap.','Voltage','Phase','Tariff Type','Prev Read Date T','Prev. Read T','Prev Read Date T1','Prev. Read T1','Prev. Read Date T2','Prev. Read T2',
                # 'Prev Read Date T3','Prev. Read T3','Prev. Read Date T4','Prev. Read T4','Prev. Read Date T5','Prev. Read  T5','Prev. Read Date T6','Prev. Read  T6',
                # 'Prev. Read Date T7','Prev. Read  T7','Avg. Consp. per day (kWh)','Accl. Premise No','Main Premise No','Conn. Type', 'F1','F2']
                BG = omBGs[inProcess["MeterData"].iloc[0]["Office"][:2]]
                #mD = inProcess["MeterData"]
                clMsg = {
                        'BG':BG,
                        'HON':NewHON,
                        'RouteNumber':inProcess["MeterData"].iloc[0]["MRU"],
                        'Office':inProcess["MeterData"].iloc[0]["Office"],
                        'MeterNumber':inProcess["MeterData"].iloc[0]["fg. Ser. No"],
                        'MeterType':inProcess["MeterData"].iloc[0]["Meter Type"],
                        'EquipmentNumber':inProcess["MeterData"].iloc[0]["Equip. No"],
                        'LastReadMonth':inProcess["MeterData"].iloc[0]["Last Bill Key"],
                        'RouteReadSeq':inProcess["MeterData"].iloc[0]["Route Read Seq"],
                        'ServiceClass':inProcess["MeterData"].iloc[0]["Service Class"],
                        'Subscription':inProcess["MeterData"].iloc[0]["Subscription No"],
                        'District':inProcess["MeterData"].iloc[0]["District"],
                        'AccountNumber':inProcess["MeterData"].iloc[0]["Account No"],
                        'CustomerName':inProcess["MeterData"].iloc[0]["BPName"],
                        'Latt':inProcess["MeterData"].iloc[0]["Latitude"],
                        'Long':inProcess["MeterData"].iloc[0]["Longitude"],
                        'Multiplier':inProcess["MeterData"].iloc[0]["Mult. Factor"],
                        'Dials':inProcess["MeterData"].iloc[0]["No. of Dials"],
                        'Breaker':inProcess["MeterData"].iloc[0]["Breaker Cap."],
                        'TarifType':inProcess["MeterData"].iloc[0]["Tariff Type"],
                        'PreRDGDate':inProcess["MeterData"].iloc[0]["Prev Read Date T"],
                        'PreRDG':inProcess["MeterData"].iloc[0]["Prev. Read T"],
                        'AvgConsumption':inProcess["MeterData"].iloc[0]["Avg. Consp. per day (kWh)"],
                        'PremiseAcc':inProcess["MeterData"].iloc[0]["Accl. Premise No"],
                        'PremiseMain':inProcess["MeterData"].iloc[0]["Main Premise No"],
                        'CustomerState':inProcess["MeterData"].iloc[0]["Conn. Type"],
                        'TransformerID':'',
                        'WorkSubType':'RW',
                        'NCR':NewHON,
                        'Premise':inProcess["PNum"],
                        'RepMeter':inProcess["Meter"],
                        'RepComm':inProcess["CM"],
                        'RepECB':inProcess["ECB"],
                        'RepDCU':inProcess["DCU"],
                        'RaisedBy':inProcess["UName"],
                        'Reason' : inProcess["Reason"],
                        'SubReason' : inProcess["SubReason"],
                        'UId' : inProcess["UId"]
                        ,'DCUSerialNumber' : inProcess["MeterData"].iloc[0]["DCUSerialNumber"] if inProcess["DCU"] == 'Y' else ""
                        ,'TransformerID' : inProcess["MeterData"].iloc[0]["TransformerID"] if inProcess["DCU"] == 'Y' else ""
                        ,'TransformerRating' : inProcess["MeterData"].iloc[0]["TransformerRating"] if inProcess["DCU"] == 'Y' else ""
                        ,'PowerConnected' : inProcess["MeterData"].iloc[0]["PowerConnected"] if inProcess["DCU"] == 'Y' else ""
                        ,'PowerConnectionDate' : inProcess["MeterData"].iloc[0]["PowerConnectionDate"] if inProcess["DCU"] == 'Y' else ""
                        ,'PowerStatusUpdatedBy' : inProcess["MeterData"].iloc[0]["PowerStatusUpdatedBy"] if inProcess["DCU"] == 'Y' else ""
                        ,'CTavailable' : inProcess["MeterData"].iloc[0]["CTavailable"] if inProcess["DCU"] == 'Y' else ""
                        ,'CTConnected' : inProcess["MeterData"].iloc[0]["CTConnected"] if inProcess["DCU"] == 'Y' else ""
                        ,'CTRatio' : inProcess["MeterData"].iloc[0]["CTRatio"] if inProcess["DCU"] == 'Y' else ""
                        # ,'SignalStrength' : inProcess["SignalStrength"],
                        # 'MeterList' : inProcess["MeterList"]
                        }

                print(Fore.BLUE + "Order Information: " +Style.RESET_ALL)
                print(clMsg)
                logging.debug(OrdersForOpen)

                resp = requests.post(ClevestTargetLink, data=json.dumps(clMsg),headers=headers,auth=auth)
                if resp.status_code == 200:
                # resp = 200
                # if resp == 200:
                    print(Fore.GREEN + "Clevest Order" +NewHON+" Created" +Style.RESET_ALL)
                    logging.info("Clevest Order "+NewHON+" Created")
                    
                    try:
                        NCRM.CreateMainNCR(clMsg)
                        print(Fore.GREEN + "NCR Order "+NewHON+" Created" +Style.RESET_ALL)
                    except:
                        print(Fore.RED + "Issue in NCR "+NewHON+" Creation" +Style.RESET_ALL)
                        logging.error("Issue in NCR "+NewHON+" Creation")


                    print(clMsg)
                    # logging.debug(clMsg)
                    logging.info("NCR Order "+NewHON+" Created")

                    # print("AFTER NCR Creation DONE")

                    try:
                        mailIt.SendEmail([inProcess["Mail"]],[],"Replacement Order Creation -"+ inProcess["PNum"] +"-","Dear " + inProcess["FName"] + ",\n    Order has been sent to Clevest, check in few seconds, new HostOrderNumber is ("+ NewHON +").\n\nContact administrator for more information.",[])

                    except:
                        print(Fore.RED + "Mail NOK" +Style.RESET_ALL)
                        logging.error("Mail NOK" + str(inProcess["Mail"]))
                else:
                    try:
                        mailIt.SendEmail([inProcess["Mail"]],[],"Replacement Order Creation -"+ inProcess["PNum"] +"-","Error happened in Clevest, contact admin for more information.",[])
                        logging.error("FIR Clevest Order Creation Fail" + str(inProcess["Mail"]))
                    except:
                        print(Fore.RED + "Mail NOK CODE1" +Style.RESET_ALL)
                        logging.error("Mail NOK CODE1 " + str(inProcess["Mail"]))

                OrdersForOpen.pop(myK, None)
        while len(OrdersForOpen.keys()) == 0:
            time.sleep(15)

t1 = Thread(target=OpenClevestOrders, args=())
t1.daemon = True
t1.start()



@app.route('/bm/create', methods=['POST','GET'])
def BMCreate():
    appTxt = "/bm"
    ThisAuth = 'BMCO'
    ThisRoute = '/bm/create'
    MTitle = "Site Equipment Replacement"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                if request.form.get("reasons") == None or request.form.get("subreason")==None:
                    return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You must select reason / subreason.", BackTo="/" )
                if request.form.get("Meter") == None and request.form.get("DCU") == None and request.form.get("ECB")  == None and request.form.get("CM") == None :
                    return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You must select at least one device to be replaced.", BackTo="/" )
                PNum = request.form.get("PNum")
                Meter = '' if request.form.get("Meter") == None else request.form.get("Meter")
                DCU = '' if request.form.get("DCU")== None else request.form.get("DCU")
                ECB ='' if  request.form.get("ECB")== None else request.form.get("ECB")
                CM ='' if  request.form.get("CM")== None else request.form.get("CM")
                Reason = request.form.get("reasons")
                SubReason= request.form.get("subreason")
                MyMeter = SECMD[SECMD["Premise"]== request.form.get("PNum")]
                MyRec = {
                    "PNum":PNum,
                    "Meter" : Meter,
                    "DCU" : DCU,
                    "ECB"  : ECB,
                    "CM" : CM,
                    "MeterData" : MyMeter,
                    "Reason" : Reason,
                    "SubReason" : SubReason,
                    "UName" : ActiveSessions[SID]["UserName"],
                    "UId" : ActiveSessions[SID]["UserId"],
                    "Mail" : ActiveSessions[SID]["Mail"],
                    "FName" : ActiveSessions[SID]["UserFName"]
                }
                TransActionID = str(uuid.uuid1())
                global OrdersForOpen
                OrdersForOpen[TransActionID] = MyRec
                if t1.is_alive:
                    logging.info("T1 Alive")
                else:
                    logging.warning("T1 Stopped" + str(ActiveSessions[SID]["UserId"]))
                    print(Fore.YELLOW + "T1 Stopped" +Style.RESET_ALL)

                return render_template("GeneralMessage.html",msgcolor = "lime", MsgTitle = MTitle, MSGBody="Your request has been recieved for premise# ("+ PNum +"), you'll recieve e-mail with the result.", BackTo="/sm" )

            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp


@app.route('/bm/multiCreate')
def MultiCreateBM():
    appTxt = "/bm"
    ThisAuth = 'CMSS'
    ThisRoute = '/bm/multiCreate'
    MTitle = "Site Multi Equipment Replacement"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                subreason = BM2BM_Reasons
                return render_template('MultiCreate.html',**locals())
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp


@app.route('/bm/multiCreate/Upload', methods=['POST'])
def MultiCreateBMUploader():
    appTxt = "/bm"
    ThisAuth = 'CMSS'
    ThisRoute = '/bm/multiCreate/Upload'
    MTitle = "Site Multi Equipment Replacement"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                if request.form.get("reasons") == None or request.form.get("subreason")==None:
                    return render_template("GeneralMessage.html",msgcolor = "Red",  MSGBody="You must select reason / subreason.", BackTo="/" )
                DCU = ''
                CM = ''
                ECB = ''
                Meter = '' if request.form.get("Meter") == None else request.form.get("Meter")
                Reason = request.form.get("reasons")
                SubReason= request.form.get("subreason")
                UName = request.form.get("onbehalf")
                file = request.files["file"]                    
                if file:
                    df = pd.read_csv(file,dtype=str)
                    df.columns = ['Premise']
                    SearchKey ='PRE'

       

                    for i,r in df.iterrows():

                        SearchData = str(r.Premise)
                        # print(SearchData)
                        # logging.debug(SearchData)

                        SData = SECMD[SECMD["Premise"]==r.Premise]
                        logging.info("CSV Premise "+r.Premise)

                        # print(SData)
                        # logging.debug(SData)

                        MyRec = {
                                "PNum":SearchData,
                                "Meter" : Meter,
                                "MeterData" : SData,
                                "ECB"  : ECB,
                                "CM" : CM,
                                "DCU" :DCU,
                                "Reason" : Reason,
                                "SubReason" : SubReason,
                                "UName" : UName,
                                "UId" : UName,
                                "Mail" : ActiveSessions[SID]["Mail"],
                                "FName" : ActiveSessions[SID]["UserFName"]
                                }
                        TransActionID = str(uuid.uuid1())
                        OrdersForOpen[TransActionID] = MyRec

                        print(MyRec)
                        # logging.debug(MyRec)

                    return render_template("GeneralMessage.html",msgcolor = "lime", MSGBody="Your request has been recieved , you'll recieve e-mail with the result.", BackTo="/" )
            else:
                    return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp
#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#----------------------------------TEST------------------------------------------
#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------

@app.route('/test', methods=['GET'])
def AA():
    return render_template("test2.html")

@app.route('/goo', methods=["POST"])
def goo():
    print(request.form.get('Action'))
    return request.form.get('Action') + "-->" + request.form.get('Req11') + "-->" + request.form.get('ReqId')


@app.route('/um')
def uploadedss():
    #f=open('C:\\System\\SIA\\ActiveInv\\MeterManuData\\numberofmeters.txt')
    #xxx = f.read()
    #f.close()
    return UMD.StartProcess()


#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#------------------------------At Site SIM Linkage-------------------------------
#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
@app.route('/Site', methods = ['GET'])
def SiteWorkData():
    return redirect('/Site/SIMLinkage')

def checkIMGPath(rPath):
    if not os.path.exists(rPath):
        try:
            os.makedirs(rPath)
            return 1
        except:
            return 0
    return 2
    

@app.route('/Site/SIMLinkage', methods = ['GET','POST'])
def SIMLinkageMain():
    appTxt = "/Site"
    ThisAuth ='SAMS'
    ThisRoute = '/Site/SIMLinkage'
    MTitle = "Site SIM Linkage"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                if request.method=="POST":
                    TrID = str(uuid.uuid1())
                    ICCiD = request.form.get('iccidNo')
                    DevID = request.form.get('meterNo').upper()
                    tPath = datetime.now().strftime('%Y/%m/%d/%H/')
                    Uid = str(ActiveSessions[SID]["UserId"])
                    with pyodbc.connect(ClConnectionStr) as connx:
                        SIMData = pd.read_sql("Select ICCID, IMSI, DeviceId from HES.dbo.SEC_LinkSIM where ICCID='" + ICCiD + "'" ,connx)
                        if len(SIMData) > 0 :
                            checkIMGPath('templates/SIMReUse/' + tPath + TrID)
                            InsQry = "insert into [HES].[dbo].[SAI_SIMReuse] ([TransactionKey],[ICCID],[DeviceID],[UID],[Path]) values "
                            InsQry += "('" + TrID + "','"+ ICCiD +"','"+ DevID +"','"+ Uid +"','"+ tPath +"')"
                            cr = connx.cursor()
                            cr.execute(InsQry)
                            cr.execute("update HES.dbo.SEC_LinkSIM set DeviceId = '"+ DevID +"', DevType='EP2PMeter', GateWay=null, GatWayType=null, OldMeter=DeviceId,Cmnt=null, Updatedate=getdate(), Updatedby='"+ Uid +"' where ICCID='" + ICCiD + "'")
                            connx.commit()
                            cr.close()
                            mFile = request.files['meterPhoto']
                            sFile = request.files['simPhoto']
                            mFile.save('templates/SIMReUse/' + tPath + TrID + "/Meter_" + mFile.filename)
                            sFile.save('templates/SIMReUse/' + tPath + TrID + "/SIM_" + sFile.filename)
                            return render_template('SiteSIMLinkage.html', STS="Link updated")
                        else:
                            render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="Wrong SIM card or ICCID, please check again or change the SIM", BackTo="/Site/SIMLinkage" )
                    

                else:
                    return render_template('SiteSIMLinkage.html')
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )

    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp


@app.route('/SIMSiteLinkage/UploadSIMLink', methods = ['POST'])
def AddSIM():
    appTxt = "/SIMSiteLinkage"
    # ThisAuth ='AAAA'
    ThisRoute = '/SIMSiteLinkage/UploadSIMLink'
    MTitle = "Site SIM Linkage"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        # if CheckAppInSession(SID, appTxt):
            # if CheckUserAuth(SID, ThisAuth):

                # TODO: Upload to DB
                pass

            # else:
            #     return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        # else:
        #     return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

# --------------- som ticket creation ----------------


@app.route('/som', methods=['GET'])
def SOMRequest():
    # Add transetion to this template
    # does not ask for login ...why? FE?
    # Add note regarding spaces in text
    
    appTxt = "/som"
    ThisAuth = 'STSC'
    ThisRoute = '/som'
    MTitle = "SOM Ticket Creation"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):

                df = pd.read_csv("templates/assets/docs/Alarms.csv")
                print(df)
                samplecolumns= "Meter Serial Number, CM Serial Number"
                samplecolumns = samplecolumns.split(",")
                return render_template("SOM_Upload.html", alarms = df, sampleFile = ["Meter Serial Number", "CM Serial Number"])

            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )    
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

def FuncAddCounter(Offset, df):
    print(Offset,)
    ii = Offset
    #Xi = list(range(ii+1, len(df)+1 ))
    Xi = []
    dd = 0
    for tg in range(len(df)):
        dd+=1
        Xi.append(ii + dd)
        
    df["TicketNumber"] = Xi
    return df , (ii+dd)


@app.route('/som/ticket_request', methods=['POST'])
def SOMRequestCreation():
    # TODO:
    # Remove / Add DCU ticket creation
    # Move file to SingleFileUpload
    # Validate user creating orders within their area 
    requestType = request.form.get('reqType')
    if requestType == 'S':
        MultiMeterNo = pd.DataFrame()
        alarmSelected = request.form.get('singleAlarm')
        MultiMeterNo["Meters"]=[request.form.get('MeterNo')]
        if alarmSelected == "4":
            splitInput = request.form.get('MeterNo').split(',')
            MultiMeterNo["Meters"] = splitInput[0]
            MultiMeterNo["CMNum"] = splitInput[1] if len(splitInput) > 1 else ""
            MultiMeterNo["CMNum"] = splitInput[1] 
            print("\n~~~~~~~~~~~~~~~~~~~~~~")
            print(splitInput)
            print(len(splitInput))
            print(splitInput[0])
            print(splitInput[1])
            print("~~~~~~~~~~~~~~~~~~~~~~")
        print(MultiMeterNo)

        fileName = "MeterList.csv"

    else:
        fileName = request.files['ufile'].filename
        splitInput = fileName.split('.')
        if splitInput[1] != "csv":
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = "Invalid File Format", MSGBody="file not in the required format. Must be CSV format", BackTo="/som" )
        MultiMeterNo= pd.read_csv(request.files['ufile'])
        alarmSelected = request.form.get('multiAlarm')
    
    if alarmSelected == None:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = "Select Alarm", MSGBody="Select alarm type before proceeding", BackTo="/som" )
    
    if len(MultiMeterNo) > 0:
        if (len(list(MultiMeterNo.columns)) > 2)  :
                print("file not in the required format....")
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = "Invalid File Format", MSGBody="file not in the required format....", BackTo="/som" )
        else:
            if (len(list(MultiMeterNo.columns)) == 1):
                MultiMeterNo["CMNum"] = ''
            MultiMeterNo.columns=["Meters","CMNum"]
    else:
        return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = "No Meters in File", MSGBody="There was no Meter entered", BackTo="/som" )


    df = pd.read_csv("templates/assets/docs/Alarms.csv")
    df["id"] =df["id"].astype('str')
    
    reqAlarm = df[df["id"] == alarmSelected]
    Al, ALAgg , DevType = reqAlarm.iloc[0]["Alarm"], reqAlarm.iloc[0]["Key"], reqAlarm.iloc[0]["DevType"]
    
    if DevType == "Meter":
        global SECMD
        df_Main=pd.DataFrame()
        df_Main = SECMD[SECMD["fg. Ser. No"].isin(MultiMeterNo["Meters"])]
        df_Main = pd.merge(df_Main,MultiMeterNo, how='inner', left_on='fg. Ser. No', right_on='Meters' )
        df_Main = df_Main[['Premise','fg. Ser. No','Office','MRU','Equip. No','Cycle','Subscription No','Account No','Latitude','Longitude','Breaker Cap.','Avg. Consp. per day (kWh)','CMNum']]
        df_Main["Latitude"] = df_Main["Latitude"].str[:10]
        df_Main["Longitude"] = df_Main["Longitude"].str[:10]
        df_Main['MeterReadDateTime']=""
        df_Main = df_Main[:]
        df_Main = df_Main.reset_index()
        print("Orders ---> " + str(len(df_Main)))
        LastTicketNumber = pd.read_csv("templates/assets/docs/LastTicketNum.csv").iloc[0]["Num"]
        df_Main , LastTicketNumber = FuncAddCounter(LastTicketNumber, df_Main) 
        df_Main["HostOrderNumber"] = df_Main["Premise"] + "_" + ALAgg
        df_Main["severity"] = 1
        df_Main["Work_type"] = "Meter"
        df_Main["Work_sub_type"] = "Not Connected"
        df_Main["Incident_description"] = Al
        df_Main["Classification"] = "NC"
        df_Main["Device_type"] = "Meter"
        df_Main["SM_count"] = Al
        df_Main["Issue_type"] = "Meter"
        df_Main["MessageID"] = ""
        df_Main['IncCreationTime'] = datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
        df_Main["SRC"] = "ALF"
        df_Main["MeterType"]=df_Main["fg. Ser. No"].str[:3]
        df_Main = df_Main.reset_index()
        temp_conn = pyodbc.connect("DRIVER={ODBC Driver 17 for SQL Server};SERVER=HO-MWFMDB.alfanar.com,1433;DATABASE=clevest;UID=DataAnalysisReadOnly;PWD=D2#@J5u2Y3;")
        ClevestData = pd.read_sql("""select SUBSTRING(HostOrderNumber,1,10) as HON, format(count(hostordernumber)+1,'0') as cnt
        from Clevest.dbo.WorkOrderMapping
        where OrderTypeId=13 
        group by SUBSTRING(HostOrderNumber,1,10) """,conn)
        temp_conn.close()
        df_Main=pd.merge(df_Main, ClevestData, left_on='Premise', right_on='HON', how='left')
        df_Main = df_Main.fillna(0)
        df_Main["HostOrderNumber"] = df_Main["HostOrderNumber"] + "_" + df_Main["cnt"].astype(str)
        df_Main["NewTicketNumber"] = ""
      
        MultiMeterNo[~MultiMeterNo["Meters"].isin(df_Main["fg. Ser. No"])].to_csv("templates/assets/docs/"+fileName.replace(".csv","_Missing.csv"))
        BGs = pd.read_csv(r"templates/assets/docs/BGs.csv", dtype=str)
        df_Main["Areakey"] = df_Main["Office"].str[:2]
        df_Main = pd.merge(df_Main, BGs, left_on='Areakey' , right_on="ACode", how='left')

        for i, row in df_Main.iterrows():
            if (alarmSelected == "4") and not row["CMNum"]:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = "No Meters in File", MSGBody="NCCM alarms must contain the cross-ponding communication module number for each meter.", BackTo="/som" )  
            xcc = "ALF{:05d}".format(row["TicketNumber"])
            df_Main.loc[df_Main["HostOrderNumber"]==row["HostOrderNumber"],"NewTicketNumber"] = xcc
            ExpFileName = ALAgg + "_" + datetime.now().strftime('%Y%m%dT%H%M%S') + "_SOMNO.csv"
            df_Main[['HostOrderNumber','severity', 'fg. Ser. No', 'Latitude', 'Longitude','Avg. Consp. per day (kWh)','Cycle','Work_type', 'Work_sub_type', 'Incident_description', 'Breaker Cap.' , 'Account No' ,  'Equip. No', 'MRU', 'Premise', 'Office', "MeterType", 'Classification', 'Device_type', 'BGiD',  'SM_count', 'Issue_type', 'IncCreationTime', 'MeterReadDateTime', 'MessageID', 'NewTicketNumber' , 'Subscription No','SRC','CMNum' ]].to_csv("templates/assets/docs/"+ExpFileName, index=False)
            # df_Main[['HostOrderNumber','severity', 'fg. Ser. No', 'Latitude', 'Longitude','Avg. Consp. per day (kWh)','Cycle','Work_type', 'Work_sub_type', 'Incident_description', 'Breaker Cap.' , 'Account No' ,  'Equip. No', 'MRU', 'Premise', 'Office', "MeterType", 'Classification', 'Device_type', 'BGiD',  'SM_count', 'Issue_type', 'IncCreationTime', 'MeterReadDateTime', 'MessageID', 'NewTicketNumber' , 'Subscription No','SRC','CMNum' ]].to_csv("Y:/AllHostExchange/SingleUpdateFolder/"+ExpFileName, index=False)
            with open("templates/assets/docs/LastTicketNum.csv", 'w') as f:
                f.write("Num\n")
                f.write(str(LastTicketNumber))
            print("Process finished. ----> " + ExpFileName)
        SID = request.cookies.get('SID')
        MessingMetersList=MultiMeterNo[~MultiMeterNo["Meters"].isin(df_Main["fg. Ser. No"])]
        if len(MessingMetersList) > 0:
            SID = request.cookies.get('SID')
            FName = ActiveSessions[SID]["UserFName"]
            UEmail = ActiveSessions[SID]["Mail"]
            msgbody = """
                        <h3> Dear """+FName+"""</h3>
                        <h4> Attached is list of meters not present in SAP</h4>
                        <h4>Kindly recheck the data  :\n</h4>  
                        <br>
                        """+MessingMetersList.to_html()+"""
                        <br>
                        <p><b><i>This is an automatically generated email – please do not reply to it. If you have any queries regarding your request please contact admin for support<br> Thank You.</i><b/></p>"""
            # path = "D:/SAI_System/templates/assets/docs/"+ fileName.replace(".csv","_Missing.csv" )
            mailer.SendEmail([UEmail],[],[],"SOM Orders Creation" , msgbody ,[])
    else:
        print("DCU")
    return render_template("GeneralMessage.html",msgcolor = "lime", MsgTitle = "SOM Tickets Created", MSGBody="SOM Tickets order has been submited, check in clevest in few seconds.", BackTo="/som" )



# --------------- HES_SIMLink ----------------



@app.route('/hes/simLinkConn', methods=["GET"])
def simLinkConn():
    appTxt = "/hes"
    ThisAuth = 'MSISD'
    ThisRoute = '/hes/simLinkConn'
    MTitle = "HES - SIM Link Application"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
 


                return render_template('HES_SIMLink.html')
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp
# --------------- DCU Dismantle ----------------

@app.route('/hes/dcudismantle', methods=["GET"])
def dcudismantle():
    appTxt = "/hes"
    ThisAuth = 'MSISD'
    ThisRoute = '/hes/dcudismantle'
    MTitle = "HES - DCU Dismantle"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
 


                return render_template('HES_DCUdismantle.html')
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp



@app.route('/hes/dcudismantle/found', methods=["GET"])
def dcuDismSearchResult():
    appTxt = "/hes"
    ThisAuth = 'MSISD'
    ThisRoute = '/hes/dcudismantle/found'
    MTitle = "HES - DCU Dismantle"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
 


                return render_template('HES_DCUdismTable.html')
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp



@app.route('/hes/dcudismantle/found/requestform/<deviceNum>', methods=["GET"])
def dcuDismRequestForm(deviceNum):
    appTxt = "/hes"
    ThisAuth = 'MSISD'
    ThisRoute = '/hes/dcudismantle/found/requestform'
    MTitle = "HES - DCU Dismantle"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
 


                return render_template('HES_DCUdismReqForm.html')
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp


# --------------- Actions Main Page ----------------

df_HES_Main_Funcs = pd.DataFrame()
df_HES_Funcs = pd.DataFrame()
def reload_HES_Functions():
    xdConn = pyodbc.connect(ClConnectionStr)
    global df_HES_Funcs
    df_HES_Funcs = pd.read_sql('SELECT id,[FuncVerb],[FuncNoun],[FuncVerbTXT],[FuncNounTXT],[FuncDisc],[FuncCSVSample],[FuncDeviceID],[FunctionName],FuncDisc FROM [HES].[dbo].[SAI_HESIntFuncs] order by FuncVerb, FuncNoun',xdConn)
    xdConn.close()
    return True

reload_HES_Functions()

@app.route('/hes', methods=["GET"])
def LoadHESServices():
    appTxt = "/hes"
    ThisAuth = 'MSISD'
    ThisRoute = '/hes'
    MTitle = "HES - Advanced Operation"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            return render_template('HES_MainPage.html', HSF = CheckUserAuth(SID,'DSHF') , HIA = CheckUserAuth(SID,'HIRS'), FIA=CheckUserAuth(SID,'RHFN'), UUMH=CheckUserAuth(SID,'UUMH'), FWTR=CheckUserAuth(SID,'FWUT'))
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

#----------------------------------------------------------------
#----------------------------------------------------------------
#----------------------- HES FW TRACKER -------------------------
#----------------------------------------------------------------
#----------------------------------------------------------------
@app.route('/hes/fwtracker', methods=["GET","POST"])
def FWTracker_Main():
    appTxt = "/hes"
    ThisAuth = 'FWUT'
    ThisRoute = '/hes/fwtracker'
    MTitle = "HES - Firmware Upgrade tracker"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                
                return render_template('HES_MainPage.html', HSF = CheckUserAuth(SID,'DSHF') , HIA = CheckUserAuth(SID,'HIRS'), FIA=CheckUserAuth(SID,'RHFN'), UUMH=CheckUserAuth(SID,'UUMH'), FWTR=CheckUserAuth(SID,'FWUT'))
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp


@app.route('/hes/updateuploaded', methods=["GET","POST"])
def UpdateUploadedToHES():
    appTxt = "/hes"
    ThisAuth = 'UUMH'
    ThisRoute = '/hes/updateuploaded'
    MTitle = "HES - Update Uploaded SEC"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if request.method == 'GET':
                return render_template('HES_UpdateUploaded.html')
            else:
                fname =request.files['ufile'].filename 
                #print(fname)
                dFile =request.files['ufile']
                df_file = pd.read_csv(dFile,dtype=str, header=None)[[0]]
                df_file.columns = ["SN"]
                connX = pyodbc.connect(HESInt.ConnectionSTR)
                SQLStr = "update hes.dbo.ALF_Meters set HESUploaded = 'Y' where DeviceID in (%METERS%)"
                Serials = ""
                C = 0
                cr = connX.cursor()
                for i, row in df_file.iterrows():
                    if Serials == "":
                        Serials = "'" + row.SN + "'"
                        C+=1
                    else:
                        Serials += ",'" + row.SN + "'"
                        C+=1
                    if C >= 10000 :
                        cr.execute(SQLStr.replace('%METERS%',Serials))
                        connX.commit()
                        Serials = ""
                        C=0
                if C > 0 :
                    cr.execute(SQLStr.replace('%METERS%',Serials))
                    connX.commit()
                    Serials = ""
                    C=0
                connX.close()
                return render_template('HES_UpdateUploaded.html', MSG="Your File (" + fname + ") of (" + str(len(df_file)) + ") meters has been updated.")

                    
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hes/reloadintfuncs', methods=["GET"])
def CallReloadHESFunctions():
    appTxt = "/hes"
    ThisAuth = 'RHFN'
    ThisRoute = '/hes/reloadintfuncs'
    MTitle = "HES - Refresh Function Data"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                reload_HES_Functions()
                return render_template('HES_MainPage.html', HSF = CheckUserAuth(SID,'DSHF') , HIA = CheckUserAuth(SID,'HIRS'), FIA=CheckUserAuth(SID,'RHFN'))
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp 

@app.route('/hes/newrequest', methods=["GET","POST"])
def devicesManagment():
    appTxt = "/hes"
    ThisAuth = 'HIRS'
    ThisRoute = '/hes/newrequest'
    MTitle = "HES - DCU Dismantle"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                if request.method == "GET":
                    fFuncs = '''<option value="XXX" selected >Choose...</option>'''
                    sIfs = ""
                    for f, grp in df_HES_Funcs.groupby(['FuncVerb','FuncVerbTXT']):
                        if fFuncs == "":
                            fFuncs = '''<option value="'''+ f[0] +'''" >'''+ f[1] +'''</option>'''
                        else:
                            fFuncs += '''<option value="'''+ f[0] +'''" >'''+ f[1] +'''</option>'''
                        sFuncs = ""
                        for sf, row in grp.iterrows():
                            if sFuncs == "":
                                sFuncs = '''<option value="'''+ row.FuncNoun +'''" >'''+ row.FuncNounTXT +'''</option>'''
                            else:
                                sFuncs += '''<option value="'''+ row.FuncNoun +'''" >'''+ row.FuncNounTXT +'''</option>'''
                        if sIfs == "" :
                            sIfs = '''\n else if (SelectedFuncS === "'''+ f[0] +'''"){document.getElementById("SubFunction_id").innerHTML =\''''+ sFuncs +'''\';}'''
                        else:
                            sIfs += '''\n else if (SelectedFuncS === "'''+ f[0] +'''"){document.getElementById("SubFunction_id").innerHTML =\''''+ sFuncs +'''\';}'''
                    return render_template('HES_devicesServices.html', MFuncs=fFuncs, SFuncs = sIfs)    
                else:
                    tFunc = request.form.get('FuncVerb')
                    tSubFunc = request.form.get('FuncNoun')
                    ReqLine = df_HES_Funcs[(df_HES_Funcs["FuncVerb"] == tFunc) & (df_HES_Funcs["FuncNoun"]== tSubFunc)]
                    if len(ReqLine)>0:
                        tFuncTXT = ReqLine.iloc[0]["FuncVerbTXT"]
                        tSubFuncTXT = ReqLine.iloc[0]["FuncNounTXT"]
                        FileTXT = ReqLine.iloc[0]["FuncCSVSample"]
                        funcDisc = ReqLine.iloc[0]["FuncDisc"]
                        FileTXTArr = FileTXT.split(',')
                        funcID = ReqLine.iloc[0]["id"]
                        return render_template('HES_devicesRequest.html', tFunc=tFuncTXT, tSubFunc=tSubFuncTXT, FileTXTData=FileTXT, tFields = FileTXTArr, funcID=funcID, funcDisc=funcDisc)    
                    else:
                        return redirect('/hes/newrequest')    
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hes/requests/<reqnum>/status/from/<ostatus>', methods=['POST'])
def hespauserequest(reqnum,ostatus):
    appTxt = "/hes"
    ThisAuth = 'HESR'
    ThisRoute = '/hes/requests'
    MTitle = "HES change request status"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                nstatus = request.form.get("ReqAction")
                ApprovedFromTo = ['1000-1150' , '1100-1150' , '1150-1100' , '1100-1900' , '1900-1100' , '1000-1900']
                Uid = str(ActiveSessions[SID]["UserId"])
                if (ostatus + "-" + nstatus) in ApprovedFromTo:
                    oSQLStr = "update [HES].[dbo].[SAI_HESIntRequests] set [RequestStatus] = " + nstatus + " where id="+ reqnum +" and [RequestStatus]= " + ostatus + " and [Requestor]=" + Uid
                    print(oSQLStr)
                    affectedRows = -1
                    conns = pyodbc.connect(ClConnectionStr)
                    try:
                        cr = conns.cursor()
                        cr.execute(oSQLStr)
                        affectedRows = cr.rowcount
                        conns.commit()
                    except:
                        pass
                    conns.close()
                    if affectedRows < 0 :
                        return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = 'Changing HES Request Status', MSGBody="Error happened......", BackTo="/hes/requests" )
                    elif affectedRows > 0 :
                        return redirect('/hes/requests')
                    else:
                        return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = 'Changing HES Request Status', MSGBody="Changing the status failed, it may changed before this action.", BackTo="/hes/requests" )
                else:
                    return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = 'Changing HES Request Status', MSGBody="Changing the status failed, you can't change to new status from currect status.", BackTo="/hes/requests" )
                
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hes/requests/<reqnum>', methods=['GET','POST'])
def viewRequest(reqnum):
    appTxt = "/hes"
    ThisAuth = 'HIRS'
    ThisRoute = '/hes/requests'
    MTitle = "HES change request status"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                Uid = str(ActiveSessions[SID]["UserId"])
                Conditions = ""
                tCond=[2000, 2100, 2150, 2200, 2300, 2350, 2900]
                if request.method=="POST":
                    reqFilter = request.form.get("filterType")
                    if reqFilter=='all':
                        Conditions = "" 
                        tCond=[2000, 2100, 2150, 2200, 2300, 2350, 2900]
                    elif reqFilter=='comp':
                        Conditions = " and LineStatus=2200 " 
                        tCond=[2200]
                    elif reqFilter=='fail':
                        Conditions = " and LineStatus=2350 " 
                        tCond=[2350]
                    elif reqFilter=='inpro':
                        Conditions = " and LineStatus <=2150 "
                        tCond=[2000, 2100, 2150] 
                    elif reqFilter=='cancel':
                        Conditions = " and LineStatus=2900 " 
                        tCond=[2900]
                    elif reqFilter=='skip':
                        Conditions = " and LineStatus=2300 " 
                        tCond=[2300]
                SQLStrR = """select 
                                ROW_NUMBER() over (order by deviceid) as Ser,
                             	RequestId, 
                             	LineStatus,
                             	DeviceID, 
                             	HIS.badge as DevBadge, 
                             	HIS.StatusCode as DevStatusCode,
                             	HIS.StatusDisc as DevStatus,
                             	HIS2.badge as ReqBadge, 
                             	HIS2.StatusCode as ReqStatusCode,
                             	HIS2.StatusDisc as ReqStatus,
                             	RLine.id as LineID,
                             	HIS2.badge as ReqBadge,
                             	concat(FuncVerbTXT , ' (' , FuncNounTXT,')') as Func,
                             	iif(InP.InProgCNT is null ,0,InP.InProgCNT) as InProg , iif(Comp.CNT is null, 0 ,Comp.CNT) as CompCNT
                                ,cast(iif(Comp.CNT is null, 0 ,Comp.CNT) / iif((iif(Comp.CNT is null, 0 ,Comp.CNT) + iif(InP.InProgCNT is null ,0,InP.InProgCNT))=0,1,(iif(Comp.CNT is null, 0 ,Comp.CNT) + iif(InP.InProgCNT is null ,0,InP.InProgCNT))) * 100 as int) as totalProg
                             from 
                             	[HES].[dbo].[SAI_HESIntReqLines] RLine
                             	inner join [HES].[dbo].[SAI_HESIntStatuses] HIS on HIS.StatusCode = RLine.LineStatus
                             	inner join [HES].[dbo].SAI_HESIntRequests HRQ on HRQ.id = RequestId
                             	inner join [HES].[dbo].[SAI_HESIntStatuses] as HIS2 on HIS2.StatusCode = HRQ.RequestStatus
                             	inner join [HES].[dbo].SAI_HESIntFuncs Funs on funs.id = HRQ.FuncID
                             	left join (select LineID, count(id) as InProgCNT from hes.dbo.SAI_HESIntReqLinStages where [Status] <=3260 group by LineID) as InP on InP.LineID = RLine.id
                             	left join (select LineID, count(id) as CNT from hes.dbo.SAI_HESIntReqLinStages where [Status] >3260 group by LineID) as Comp on Comp.LineID = RLine.id
                             where
                             	RLine.RequestId = """+ reqnum + """ order by DeviceID"""
                conns = pyodbc.connect(ClConnectionStr)
                RDevicesData =pd.read_sql(SQLStrR, conns)
                conns.close()
                tall = len(RDevicesData)
                tComp = len(RDevicesData[RDevicesData["LineStatus"]==2200])
                tFail = len(RDevicesData[RDevicesData["LineStatus"]==2350])
                tInpro = len(RDevicesData[RDevicesData["LineStatus"]<=2150])
                tCancel = len(RDevicesData[RDevicesData["LineStatus"]==2900])
                tSkip = len(RDevicesData[RDevicesData["LineStatus"]==2300])
                return render_template("HESRequesDevices.html", df = RDevicesData[RDevicesData["LineStatus"].isin(tCond)][:1500], LineID=reqnum, totDevices=tall, totCompleted=tComp, totFailed=tFail, totInpro=tInpro, totcancel=tCancel, totskip=tSkip)
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/hes/requests" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/hes/requests" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp    

@app.route('/hes/requests/<ReqNum>/<LineID>/status/from/<fstatus>', methods=['POST'])
def CheangeRequestLine(ReqNum, LineID, fstatus):
    appTxt = "/hes"
    ThisAuth = 'HIRS'
    ThisRoute = "/hes/requests/" + ReqNum
    MTitle = "HES change request device status"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                nstatus = request.form.get("ReqAction")
                ApprovedFromTo = ['2300-2150' , '2350-2150' , '2100-2300' , '2100-2900' , '2350-2150' ]
                Uid = str(ActiveSessions[SID]["UserId"])
                if (fstatus + "-" + nstatus) in ApprovedFromTo:
                    oSQLStr = "Update [HES].[dbo].[SAI_HESIntReqLines] set LineStatus = "+ nstatus +" where id = "+ LineID +" and LineStatus="+ fstatus +" and RequestId in (select id from [HES].[dbo].SAI_HESIntRequests where id ="+ ReqNum +" and Requestor="+ Uid +" and RequestStatus in (1000, 1100))"
                    #print(oSQLStr)
                    affectedRows = -1
                    conns = pyodbc.connect(ClConnectionStr)
                    try:
                        cr = conns.cursor()
                        cr.execute(oSQLStr)
                        affectedRows = cr.rowcount
                        conns.commit()
                    except:
                        pass
                    conns.close()
                    if affectedRows < 0 :
                        return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = 'Changing HES Request Status', MSGBody="Error happened......", BackTo="/hes/requests/" + ReqNum )
                    elif affectedRows > 0 :
                        return redirect("/hes/requests/" + ReqNum)
                    else:
                        return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = 'Changing HES Request Status', MSGBody="Changing the status failed, it may changed before this action.", BackTo="/hes/requests/" + ReqNum )
                else:
                    return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = 'Changing HES Request Status', MSGBody="Changing the status failed, you can't change to new status from currect status.", BackTo="/hes/requests/" + ReqNum )
                
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hes/requests/<ReqID>/<DevID>/<StageId>/status/from/<sStatus>', methods=["POST"])
def ChangeStageStatus(ReqID,DevID,StageId,sStatus):
    appTxt = "/hes"
    ThisAuth = 'HIRS'
    ThisRoute = '/hes/requests/' + ReqID + '/' + DevID
    MTitle = "HES change stage status"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                Uid = str(ActiveSessions[SID]["UserId"])
                ReqAction = request.form.get("ReqAction")
                SQLs = []
                cnnx= pyodbc.connect(ClConnectionStr)
                cr = cnnx.cursor()
                if ReqAction == '3900':
                    #Cancel
                    cr.execute("update hes.dbo.SAI_HESIntReqLinStages set [Status] = 3900 where [Status]="+ sStatus +" and id= " + StageId)
                    if cr.rowcount>0 :
                        cr.execute("update hes.dbo.SAI_HESIntReqLines set LineStatus=2900 where id=" + DevID)
                    cnnx.commit()
                elif ReqAction == '3400':
                    #Skip
                    SQL = "update hes.dbo.SAI_HESIntReqLinStages set [Status] = 3400 where [Status]="+ sStatus +" and id= " + StageId
                    cr.execute("update hes.dbo.SAI_HESIntReqLinStages set [Status] = 3400 where [Status]="+ sStatus +" and IsLast='Y' and id= " + StageId)
                    if cr.rowcount>0 :
                        cr.execute("update hes.dbo.SAI_HESIntReqLines set LineStatus=2200 where id=" + DevID)
                    else:
                        cr.execute("update hes.dbo.SAI_HESIntReqLinStages set [Status] = 3400 where [Status]="+ sStatus +" and id= " + StageId)
                        if cr.rowcount > 0 :
                            cr.execute("update hes.dbo.SAI_HESIntReqLines set LineStatus=2150 where id=" + DevID)

                    cnnx.commit()
                elif ReqAction == '3100':
                    #Retry
                    cr.execute("update hes.dbo.SAI_HESIntReqLinStages set [Status] = 3100 where [Status]="+ sStatus +" and id= " + StageId)
                    if cr.rowcount > 0:
                        cr.execute("update hes.dbo.SAI_HESIntReqLines set LineStatus=2150 where id=" + DevID)
                    cnnx.commit()
                cnnx.close()

                
                
                return redirect('/hes/requests/'+ ReqID +'/'+ DevID)
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/hes/requests" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/hes/requests" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hes/requests/<ReqNum>/<LineID>', methods=['GET'])
def ShowRequestLineStages(ReqNum,LineID):
    appTxt = "/hes"
    ThisAuth = 'HIRS'
    ThisRoute = '/hes/requests'
    MTitle = "HES change request status"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                Uid = str(ActiveSessions[SID]["UserId"])
                SQLStrR = """
                            Select
                            	ROW_NUMBER() over (order by RStages.id) as Ser,
                            	RStages.id, RStages.[Status], RStages.[TypeVerb], RStages.[TypeNoun], RStages.Retries, RStages.IsLast, format(RStages.SentToHESDateTime, 'dd-MMM-yy HH:mm:ss') as SentToHES
                            	,PStages.id as PiD, HFStages.StageDisc, format(RStages.LastRetryDateTime, 'dd-MMM-yy HH:mm:ss') as LastRetryDate
                                ,HIS3.StatusDisc, HIS3.badge, RLine.DeviceID, RLine.id as LIID ,RLine.RequestId, RLine.LineStatus, HRQ.RequestStatus
                                ,RStages.HESReponse
                            from
                            	[HES].[dbo].[SAI_HESIntReqLinStages] RStages
                            	inner join [HES].[dbo].[SAI_HESIntReqLines] RLine on RStages.LineID = RLine.id
                            	inner join [HES].[dbo].[SAI_HESIntStatuses] HIS on HIS.StatusCode = RLine.LineStatus
                            	inner join [HES].[dbo].SAI_HESIntRequests HRQ on HRQ.id = RequestId
                            	inner join [HES].[dbo].[SAI_HESIntStatuses] as HIS2 on HIS2.StatusCode = HRQ.RequestStatus
                            	inner join [HES].[dbo].[SAI_HESIntStatuses] as HIS3 on HIS3.StatusCode = RStages.[Status]
                            	inner join [HES].[dbo].SAI_HESIntFuncs Funs on funs.id = HRQ.FuncID
                            	inner join [HES].[dbo].SAI_HESIntFuncStages HFStages on HFStages.id = RStages.StageID
                            	left join [HES].[dbo].[SAI_HESIntReqLinStages] as PStages on PStages.ColID = RStages.ParentColID
                            where 
                                RStages.LineID = """ + LineID
                conns = pyodbc.connect(ClConnectionStr)
                RDevicesData =pd.read_sql(SQLStrR, conns)
                conns.close()
                DeviceID = ''
                LID = ""
                if len(RDevicesData) > 0:
                    DeviceID = RDevicesData.iloc[0]["DeviceID"]
                    LID = RDevicesData.iloc[0]["RequestId"]
                    RDevicesData['Result'] = RDevicesData['HESReponse'].str.extract('(result.+)', expand=True)
                    RDevicesData['Code'] = RDevicesData['HESReponse'].str.extract('(code.+)', expand=True)
                    RDevicesData['CodeReason'] = RDevicesData['HESReponse'].str.extract('(details.+)', expand=True)

                    for r in (("result", ""), ('"', ""), (': ', ""), ('code', ""), ('details', ""), (',', "")):
                        RDevicesData['Result'] = RDevicesData['Result'].str.replace(*r)
                        RDevicesData['Code'] = RDevicesData['Code'].str.replace(*r)
                        RDevicesData['CodeReason'] = RDevicesData['CodeReason'].str.replace(*r)
                    RDevicesData['CodeReason'] = RDevicesData['CodeReason'].replace({np.nan:None})
                return render_template("HESRequesDeviceStages.html", df = RDevicesData , DevID=DeviceID, LineID=LID, RequestId=ReqNum)
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/hes/requests" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/hes/requests" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hes/createrequest', methods=['POST'])
def createhesrequest():
    appTxt = "/hes"
    ThisAuth = 'HIRS'
    ThisRoute = '/hes/requests'
    MTitle = "HES - Request Managment"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                print("Starting Request")
                Uid = str(ActiveSessions[SID]["UserId"])
                ReqType = request.form.get('reqType')
                funcID = request.form.get('funcID')
                funcLine = df_HES_Funcs[df_HES_Funcs['id']==int(funcID)]
                funcTXT = funcLine.iloc[0]["FuncCSVSample"]
                fVerb = funcLine.iloc[0]["FuncVerb"]
                fNoun = funcLine.iloc[0]["FuncNoun"]
                if ReqType == 'S':
                    print("Single Requset")

                    fTXT = funcTXT + '\n'
                    dDict = []
                    cols=[]
                    
                    for f in funcTXT.split(','):
                        dDict.append(request.form.get(f))
                        cols.append(f)
                    print(dDict)
                    xDict = []
                    xDict.append(dDict)
                    df_file = pd.DataFrame(xDict, columns=cols)
                else:
                    dFile =request.files['ufile']
                    df_file = pd.read_csv(dFile,dtype=str) 
                print(df_file) 
                print(type(df_file))
                print(df_file.keys())
                print("Will start actual function")
                print(HESInt.CreateRequest(df_file,fVerb,fNoun,Uid))
                                    


                return redirect('/hes/requests')
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hes/requests', methods=["POST","GET"])
def ViewHESRewquests():
    appTxt = "/hes"
    ThisAuth = 'HIRS'
    ThisRoute = '/hes/requests'
    MTitle = "HES - Request Managment"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                Uid = str(ActiveSessions[SID]["UserId"]) 
                conditions = ""
                if request.method=="POST":
                    pass
                SQLStr = """Select top(1000)
                                    HIR.id,
                                    [RequestStatus], 
                                    StatusDisc, 
                                    HIF.FuncVerbTXT , 
                                    hif.FuncNounTXT,
                                    tbl1.CNT as Total_Devices , tbl2.CNT as Completed,
                                    format([InsertDate],'dd-MMM-yyyy HH:mm:ss') as ReqDate, 
                                    format(LastUpdateDate,'dd-MMM-yyyy HH:mm:ss') as LastUpdate,
		                            Badge,
                                    iif(cast((tbl2.CNT / tbl1.CNT)*100 as int) is null,0,cast((tbl2.CNT*100 / tbl1.CNT) as int)) as Prog
                                FROM 
                                    [HES].[dbo].[SAI_HESIntRequests]  HIR
                                    inner join [HES].[dbo].[SAI_HESIntStatuses] HS on HS.StatusCode= [RequestStatus]
                                    inner join [HES].[dbo].[SAI_HESIntFuncs] HIF on HIF.id = HIR.FuncID
                                    left join (select RequestId, count(id) as CNT from [HES].[dbo].[SAI_HESIntReqLines] group by RequestId) as tbl1 on tbl1.RequestId=HIR.id
                                    left join (select RequestId, count(id) as CNT from [HES].[dbo].[SAI_HESIntReqLines] where [LineStatus] >=2200 group by RequestId) as tbl2 on tbl2.RequestId=HIR.id
                                where 
                                    [Requestor] = """ + Uid + " " + conditions + """  
                                Order by 
                                    [InsertDate] DESC
                            """
                reqConn = pyodbc.connect(ClConnectionStr)
                df_requests = pd.read_sql(SQLStr, reqConn)
                reqConn.close()
                return render_template('HESRequestTable.html', df = df_requests)
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp



@app.route('/hes/allrequests/<accessnum>', methods=["POST","GET"])
def ViewAllHESRewquests(accessnum):
    appTxt = "/hes"
    ThisAuth = 'HIRS'
    ThisRoute = '/hes/allrequests/'+str(accessnum)
    MTitle = "HES - Request Managment"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                if accessnum == '55957':
                    Uid = str(ActiveSessions[SID]["UserId"]) 
                    conditions = ""
                    if request.method=="POST":
                        pass
                    SQLStr = """Select top(1000)
                                        HIR.id,
                                        [RequestStatus], 
                                        StatusDisc, 
                                        HIF.FuncVerbTXT , 
                                        hif.FuncNounTXT,
                                        tbl1.CNT as Total_Devices , tbl2.CNT as Completed,
                                        format([InsertDate],'dd-MMM-yyyy HH:mm:ss') as ReqDate, 
                                        format(LastUpdateDate,'dd-MMM-yyyy HH:mm:ss') as LastUpdate,
                                        Badge,
                                        iif(cast((tbl2.CNT / tbl1.CNT)*100 as int) is null,0,cast((tbl2.CNT*100 / tbl1.CNT) as int)) as Prog
                                    FROM 
                                        [HES].[dbo].[SAI_HESIntRequests]  HIR
                                        inner join [HES].[dbo].[SAI_HESIntStatuses] HS on HS.StatusCode= [RequestStatus]
                                        inner join [HES].[dbo].[SAI_HESIntFuncs] HIF on HIF.id = HIR.FuncID
                                        left join (select RequestId, count(id) as CNT from [HES].[dbo].[SAI_HESIntReqLines] group by RequestId) as tbl1 on tbl1.RequestId=HIR.id
                                        left join (select RequestId, count(id) as CNT from [HES].[dbo].[SAI_HESIntReqLines] where [LineStatus] >=2200 group by RequestId) as tbl2 on tbl2.RequestId=HIR.id
                                    
                                    Order by 
                                        [InsertDate] DESC
                                """
                    reqConn = pyodbc.connect(ClConnectionStr)
                    df_requests = pd.read_sql(SQLStr, reqConn)
                    reqConn.close()
                    return render_template('HESRequestTable.html', df = df_requests)
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

    
# --------------- HES Reuest Table ----------------


@app.route('/hes/requesttable', methods=["GET"])
def  hesrequest():
    appTxt = "/hes"
    ThisAuth = 'MSISD'
    ThisRoute = '/hes/requesttabl'
    MTitle = "HES - Request Managment"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
 


                return render_template('HESRequestTable.html')
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp





#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------
#---------------------------   Shipment Files   ---------------------------------
#--------------------------------------------------------------------------------
#--------------------------------------------------------------------------------

@app.route('/hes/files', methods = ['GET'])
def HESFiles():
    appTxt = "/hes"
    ThisAuth = 'HESR'
    ThisRoute = '/hes/files'
    MTitle = "HES Shipment Files Downloader"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                return render_template('MeterData.html')
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hes/download', methods = ['POST'])
def HESFilesdownload():
    appTxt = "/hes"
    ThisAuth = 'HESR'
    ThisRoute = '/hes/download'
    MTitle = "HES Shipment Files Downloader"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                FileType = request.form.get('action')
                Meters = request.form.get('reasonEn')
                MetersList = Meters.split(',')
                Ret = UMD.GenerateShimpentFiles(MetersList,FileType)
                #df = pd.DataFrame(columns=['DEVICE_ID','MANUFACTURER_SERIAL_NUMBER','DEVICE_TYPE','DEVICE_SUBTYPE','DEVICE_MODEL_NUMBER','DEVICE_MANUFACTURER_ABBREVIATION','DEVICE_COMMUNICATION_MOUDLE_MANUFACTURING_YEAR','DEVICE_CALIBRATION_YEAR','DEVICE_PROTOCOL','DEVICE_PROTOCOL_VERSION','DEVICE_MAC_ADDRESS','DEVICE_FIRMWARE_VERSION','DEVICE_CONFIGURATION_VERSION','DEVICE_DISPLAY_REGISTER_DIGIT','DEVICE_COMMUNICATION_TECHNOLOGY','DEVICE_COMMUNICATION_MODULE_MODEL','DEVICE_COMMUNICATION_MODULE_SERIAL_NUMBER','DEVICE_COMMUNICATION_MODULE_MANUFACTURING_YEAR','DEVICE_COMMUNICATION_MODULE_FIRMWARE_VERSION','DEVICE_COMMUNICATION_MODULE_IMEI_NUMBER','DLMS_TCP_PORT','DLMS_COMMUNICATION_PROFILE','DLMS_CLIENT_ID','DLMS_MASTER_KEY','DLMS_AUTHENTICATION_KEY','DLMS_GUC','DLMS_SECURITY_SECRET','DLMS_SECURITY_POLICY','DLMS_AUTHENTICATION_MECHANISM','DLMS_SECURITY_SUITE','COMPANION','COMPANION_VERSION','DEVICE_UTILITYID','UTILITY','INTERNAL_CT_NOMINATOR','INTERNAL_CT_DENOMINATOR','DISCOVER_ID'])
                #df_Comp = pd.DataFrame(Ret["Companion"])
                df_Data = pd.DataFrame(Ret["Data"])
                #for m in Ret["Companion"]:
                #    df.append(m)
                resp = make_response(df_Data.to_csv(index=False, sep=";"))
                resp.headers["Content-Disposition"] = "attachment; filename="+ FileType +".csv"
                resp.headers["Content-Type"] = "text/csv"
                return resp
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp
    
@app.route('/shipmentfiles', methods=["GET"])
def shipmentfiles():
    appTxt = "/hes"
    ThisAuth = 'DSHF'
    ThisRoute = '/shipmentfiles'
    MTitle = "HES - Shipment File Generation"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):

                with pyodbc.connect(ClConnectionStr) as xConn:
                    df_rr = pd.read_sql("Select top(10) id, format(InserDateTime,'dd-MMM-yyyy HH:mm:ss') as rDate, format(ProcessDataTime,'dd-MMM-yyyy HH:mm:ss') as pDate , RequestStatus, iif( GeneratedFiles is null, '', GeneratedFiles) as tFile from [HES].[dbo].[SAI_HES_RequestFiles] where Requestor = "+ str(ActiveSessions[SID]["UserId"]) +" order by id DESC", xConn)
                
                return render_template('HES_ShipFiles.html', df_reqs=df_rr)
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hes/gshipment', methods=["POST"])
def GenShipFiles():
    appTxt = "/hes"
    ThisAuth = 'DSHF'
    ThisRoute = '/hes/gshipment'
    MTitle = "HES - Shipment File Generation"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                tRequest = '' if  request.form.get("companion")== None else request.form.get("companion")
                tRequest += '' if  request.form.get("simdata")== None else request.form.get("simdata")
                tRequest += '' if  request.form.get("simlink")== None else request.form.get("simlink")
                if tRequest == '':
                    return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You must select at least one task (Companion, SIM Data, SIM Link)", BackTo=ThisRoute )
                try:
                    fname =request.files['ufile'].filename 
                    #print(fname)
                    dFile =request.files['ufile']
                    df_file = pd.read_csv(dFile,dtype=str, header=None)
                except:
                    return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="Error happened, can't open uloaded file, file must be csv format, single column and without header", BackTo=ThisRoute )
                if len(df_file) > 0:
                    if len(df_file.columns) == 1:
                        df_file.columns = ['MeterSN']
                        df_file = df_file.drop_duplicates(keep='first')
                        ReqID = HES_Shipment.InsertNewRequest(df_file,ActiveSessions[SID]["UserId"],tRequest,2000)
                        return render_template("GeneralMessage.html",msgcolor = "Lime", MsgTitle = MTitle, MSGBody="Your request has been recieved, your request number is: " + str(ReqID), BackTo='/shipmentfiles' )
                    else:
                        return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="Uploaded file contains more than one column, file must be csv format, single column and without header", BackTo=ThisRoute )
                else:
                    return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="Uploaded file contains no data.", BackTo=ThisRoute )

            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/hes/shipment/download/<rid>', methods=['GET'])
def shipdownload(rid):
    SID = request.cookies.get('SID')
    with pyodbc.connect(ClConnectionStr) as xConn:
        df_rr = pd.read_sql("Select Requestor, [GeneratedFiles] from [HES].[dbo].[SAI_HES_RequestFiles] where id = " + rid , xConn)
    UID = str(ActiveSessions[SID]["UserId"])
    if len(df_rr) > 0:
        xUID = str(df_rr.iloc[0].Requestor)
        if UID == xUID:
            fFile = str(df_rr.iloc[0].GeneratedFiles)
            return send_from_directory("D:\\SAI_System\\templates\\HES\\Shipments",fFile, as_attachment=True)
        else:
            return send_from_directory("D:\\SAI_System\\templates\\HES\\Shipments","UnAuthorized.txt", as_attachment=True)

#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
#----------------------------- NCR Management --------------------------------------
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
@app.route('/ncr',methods=["GET"])
def NCRsTable():
    appTxt = "/ncr"
    ThisAuth = 'VNCR'
    ThisRoute = '/ncr'
    MTitle = "NCR Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                # {"BG": "OM_Riyadh", "HON": "4002348246-R0000004", "RouteNumber": "R1041511", "Office": "1110", "MeterNumber": "KFM2020861227822", "MeterType": "SMD", "EquipmentNumber": "000000000024500364", "LastReadMonth": "2021/10", "RouteReadSeq": "000059", "ServiceClass": "1101", "Subscription": "1141511059", "District": "", "AccountNumber": "010023945291", "CustomerName": " \u0639\u0628\u062f\u0627\u0644\u0631\u062d\u0645\u0646 \u0633\u0644\u064a\u0645\u0627\u0646 \u0639\u0628\u062f\u0627\u0644\u0631\u062d\u0645\u0646 \u0633\u0644\u064a\u0645\u0627\u0646.", "Latt": "24.693900000000", "Long": "46.651400000000", "Multiplier": "1.00000", "Dials": "08", "Breaker": "50.0000000", "TarifType": "1", "PreRDGDate": "20211115", "PreRDG": "22898.0000", "AvgConsumption": "20.3009", "PremiseAcc": "", "PremiseMain": "", "CustomerState": "P", "TransformerID": "", "WorkSubType": "RW", "NCR": "4002348246-R0000004", "Premise": "4002348246", "RepMeter": "Y", "RepComm": "", "RepECB": "", "RepDCU": "", "RaisedBy": "53319", "Reason": "Burnt", "SubReason": "Partially", "UId": "19"}
                userid=ActiveSessions[SID]["UserId"]


                allNCR = pd.read_sql( """SELECT 
                                            NCRNumber,
                                            ST.Status as Status,
                                            JSON_VALUE(NCRFullData, '$.Office') as Office,
                                            Reason,
                                            SubReason,
                                            format(CreationDateTime , 'yyyy-MM-dd HH:mm:ss') as CreationDateTime,
                                            Resposability,
                                            format(RectificationDate , 'yyyy-MM-dd HH:mm:ss') as RectificationDate, 
                                            Concat(CrUA.FirstName, ' ', CrUA.LastName) as Created_By,
                                            LastComment,
                                            (SELECT
                                                COUNT(*)
                                             FROM
                                                     HES.dbo.SAI_NCRs
                                             WHERE
                                                     MainNCRNumber=NCR.NCRNumber
                                                 ) as 'SubNum'
                                            FROM
                                                (
                                                SELECT *, ROW_NUMBER() OVER (PARTITION BY NCRNumber Order by id  DESC) AS rnum
                                                FROM   HES.dbo.SAI_NCRs 
                                                ) as NCR                                 
                                                inner join SAI_UserAccount as CrUA on CrUA.id = NCR.CreatedBy
                                                LEFT JOIN HES.dbo.SAI_BM_Reasons as RES on RES.id=NCR.NCRReasonID   
                                                LEFT JOIN HES.dbo.SAI_NCR_Statuses as ST ON ST.id = NCR.Status  
                                            WHERE 
                                                MainNCRNumber IS NULL
                                                and NCR.rnum = 1
                                                """+ ((""" """) if CheckUserAuth(SID, 'VANC') else ( """and NCR.CreatedBy ='"""  + userid+"""'""" )) + """ 
                                                and
                                                ( RectificationDate > dateadd(day,datediff(day,30,GETDATE()),0)
                                                or  NCR.Status not in (6))
                                                Order by CreationDateTime DESC                                        
                                            """, conn)
                # allNCR = allNCR.sort_values(by=['NCRNumber'])
                # allNCR = allNCR.drop_duplicates(subset=['NCRNumber','CreationDateTime','RectificationDate'], keep='last')
                allNCR.set_index("NCRNumber", drop=True, inplace=True)

                try:
                    NCR= allNCR[['Office',"Status","Reason","SubReason","CreationDateTime","Created_By","Resposability","RectificationDate","LastComment","SubNum"]].to_dict(orient="index")
                except:
                    allNCR=pd.read_sql("""SELECT a.*
                                            FROM HES.dbo.SAI_NCRs a
                                            JOIN (SELECT NCRNumber,   COUNT(*) as no
                                            FROM HES.dbo.SAI_NCRs
                                            GROUP BY NCRNumber
                                            HAVING count(*) > 1 ) b
                                            ON a.NCRNumber = b.NCRNumber""", conn)
                    msgbody=   """<table>
                                <thead>
                                <th>ID</th>
                                <th>NCR Number</th>
                                <th>Status</th>
                                <th>Created By</th>
                                <th>Creation Date</th>
                                <th>RectificationDate</th>
                                </thead>
                                <tbody>
                                """
                    for k,v in allNCR.iterrows():
                        msgbody+="""<tr>
                                        <td>"""+str(v['id'])+"""</td>
                                        <td>"""+str(v['NCRNumber'])+"""</td>
                                        <td>"""+str(v['Status'])+"""</td>
                                        <td>"""+str(v['CreatedBy'])+"""</td>
                                        <td>"""+str(v['CreationDateTime'])+"""</td>
                                        <td>"""+str(v['RectificationDate'])+"""</td>
                                    </tr>"""
                    msgbody += """</tbody>
                                  </table>"""

                    print(Fore.RED +"Duplacted Order: " +Style.RESET_ALL)
                    logging.error("Duplacted Order: " + str(v['CreatedBy']))
                    mailIt.SendEmail(['maram.alkhatib@alfanar.com','hela.alkudisi@alfanar.com'],[],"Dups Detected",msgbody,[])
                RefreshSM2SMReasons()

                subreason = BM2BM_Reasons

                return render_template("TableAllNCR.html" , Status = statusList, Reason = subreason,NCR=NCR)
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/ncr/viewncr/<ncrnum>',methods=["GET"])
def getncr(ncrnum):
    appTxt = "/ncr"
    ThisAuth = 'VNCR'
    ThisRoute = '/ncr'
    MTitle = "NCR Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                allNCR = """SELECT NCRNumber,MainNCRNumber,ST.Status as Status,Reason,SubReason,NCRFullData ,LEFT(CreationDateTime , 12) as 'Creation Date',uid.FirstName as FName,uid.LastName as LName,NCR.CreatedBy,Premise,Resposability,OESerial as 'Old Device Number',OERating as 'Old Device Rating',NESerial as 'New Device Number',NERating as 'New Device Rating',
                LEFT(RectificationDate , 12) as 'Rectification Date' ,RectifiedBy,Invest as 'Investigation Comment', NCRType
                FROM HES.dbo.SAI_NCRs as NCR
                LEFT JOIN HES.dbo.SAI_BM_Reasons as RES on RES.id=NCR.NCRReasonID
                LEFT JOIN HES.dbo.SAI_UserAccount as uid ON uid.id=NCR.CreatedBy
                LEFT JOIN HES.dbo.SAI_NCR_Statuses as ST ON ST.id = NCR.Status  WHERE MainNCRNumber = '""" + ncrnum + """' or NCRNumber = '""" + ncrnum + """'         
                """
                NCRData = pd.read_sql(allNCR, conn)
                NCRData.set_index("NCRNumber", drop=True, inplace=True)
                NCRData["Reasons"]=NCRData["Reason"]+" , "+NCRData["SubReason"]
                NCRData["Created By"]=NCRData["FName"]+" "+NCRData["LName"]
                
                NCRData["Office"]=NCRData["NCRFullData"].str.split(':').str[4].str.split().str[0]
                NCRData["Office"]=NCRData["Office"].replace({',':"",'"':""},regex=True)
                NCRData["Office"].fillna(method='ffill',inplace=True)
                # print(NCRData["Office"])
                NCR= NCRData[["MainNCRNumber","Status","Reasons","Creation Date","Office","Created By","Premise","Resposability","Old Device Number","Old Device Rating" ,"New Device Number" ,"New Device Rating","Rectification Date","RectifiedBy","Investigation Comment"]].to_dict(orient="index")
                # logging.debug(NCR)
                # print(NCR)


                Comm = pd.read_sql( """SELECT Comment,NCRNumber,CommentBy,LEFT(date , 12)as 'date',uid.FirstName as FName,uid.LastName as LName FROM HES.dbo.SAI_NCRComments as comm
                LEFT JOIN HES.dbo.SAI_UserAccount as uid ON uid.id=comm.CommentBy
                WHERE NCRNumber = '""" + ncrnum + """' order by date """, conn)
                Comm["CommentBy"]=Comm["FName"]+" "+Comm["LName"]  
                Comm=Comm.astype(str)
                json_list = json.loads(json.dumps(list(Comm.T.to_dict().values())))
                # print(json_list)
                # logging.debug(json_list)

                RefreshSM2SMReasons()
                subreason = BM2BM_Reasons
                try:    
                    file = os.listdir( app.config['UPLOAD_PATH']+ncrnum)      
                except:
                    file = ""      
               
                return render_template("ViewNCR.html",NCRs=NCR ,NCRNum=ncrnum,Comment=json_list,Reason = subreason,file=file)
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/ncr/approvencr/<ncrnum>',methods=["POST","GET"])
def appncr(ncrnum):
    appTxt = "/ncr"
    ThisAuth = 'ANCR'
    ThisRoute = '/ncr/approvencr'
    MTitle = "NCR Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                uid=ActiveSessions[SID]["UserId"]   

                # print(request.form.getlist("confirm-checkbox")[0])
                # print(request.form.get("confirm-checkbox"))
                # print(request.form.get("reasons-select")) 
                # print(request.form.get("subreasons-select")) 

                
                
                MainNCRData = pd.read_sql( """
                                            SELECT 
                                                NCRNumber, Status,Resposability  FROM HES.dbo.SAI_NCRs as NCR
                                                LEFT JOIN HES.dbo.SAI_BM_Reasons as RES on RES.id=NCR.NCRReasonID 
                                            WHERE 
                                                NCRNumber= '""" + ncrnum +"""'""" , conn)  
                MainNCRData=MainNCRData.astype(str)
                MainNCRData = json.loads(json.dumps(list(MainNCRData.T.to_dict().values())))
                print(Fore.GREEN +"Resp: "+MainNCRData[0]['Resposability']+Style.RESET_ALL)
                if MainNCRData[0]['Status'] == '3':

                
                    investComm= request.form.get("investegation-comment")
                    check ='' if  request.form.get("confirm-checkbox")== None else request.form.get("confirm-checkbox")
                    investComm = re.sub(r'[^a-zA-Z0-9 \. \, ]','',investComm)
                    # investComm = re.sub(r'[^a-zA-Z0-9 \.]','',investComm)
                    UpdateSql = """ 
                    UPDATE 
                    [HES].[dbo].[SAI_NCRs]
                    SET 
                    [Invest] = '"""+investComm+"""'
                   ,[ClosedBy] = '"""+uid+"""'
                   ,[CloseDate] = '"""+datetime.now().strftime("%Y-%m-%d %H:%M:%S")+"""'"""

                    if check != '':
                        ReasonId = request.form.get("subreasons-select")
                        if request.form.get("reasons-select") == None or request.form.get("subreasons-select")==None:
                            return render_template("GeneralMessage.html",msgcolor = "Red", MSGBody="You must select reason / subreason.", BackTo="/ncr" )
                        print("Checked"+str(os.path.exists("templates/NCRs/" + ncrnum +"/"+"SECApproval"+ncrnum+".pdf")))
                        print("SubReason:")
                        print(os.path.join(app.config['UPLOAD_PATH'] + ncrnum ,"SECApproval"+ncrnum+".pdf"))
                        print(int(request.form.get("subreasons-select")))
                        if  (int(request.form.get("subreasons-select"))< 7) and (os.path.exists("templates/NCRs/" + ncrnum +"/SECApproval"+ncrnum+".pdf") == False):
                            return render_template("GeneralMessage.html",msgcolor = "Red", MSGBody="You Must Upload SEC Approval", BackTo="/ncr" )
                        UpdateSql +=""", [NCRReasonID] = '"""+ReasonId+"""' , [Resposability] = (SELECT Resp from [HES].[dbo].[SAI_BM_Reasons] WHERE id= '"""+ReasonId+"""')"""
                    else:
                        print(Fore.GREEN +"Resp: "+MainNCRData[0]['Resposability']+Style.RESET_ALL)
                        if  (MainNCRData[0]['Resposability'] == 'SEC') and (os.path.exists("templates/NCRs/" + ncrnum +"/SECApproval"+ncrnum+".pdf") == False):
                            return render_template("GeneralMessage.html",msgcolor = "red", MSGBody="You Must Upload SEC Approval", BackTo="/ncr" )
                    UpdateSubSql = UpdateSql + """,[Status]= 7  WHERE MainNCRNumber = '"""+ncrnum+"""' and CreatedBy ='"""+uid+"""'"""
                    UpdateSql +=""",[Status]= 6 WHERE NCRNumber = '""" + ncrnum +"""' and CreatedBy ='"""+uid+"""'"""
                    
                    # print(UpdateSubSql)
                    # print(UpdateSql)
                    try:
                        cr = conn.cursor()
                        cr.execute(UpdateSubSql)
                        cr.execute(UpdateSql)
                        conn.commit()
                        print(Fore.GREEN +"Approved: "+ncrnum +Style.RESET_ALL)
                        logging.info(str(uid)+" Approved: "+ncrnum )
                    except:
                        logging.error("Issue approving: "+ncrnum )
                    try:
                        GenDoc.DocumentCreator(ncrnum)
                        logging.info("Printed DOC: "+ncrnum )
                        return render_template("GeneralMessage.html",msgcolor = "lime", MSGBody="NCR Officially Rectified", BackTo="/ncr" )
                    except Exception as e:
                        logging.error("Issue printing DOC: "+ncrnum )
                        print(e)

                        return render_template("GeneralMessage.html",msgcolor = "Red", MSGBody="Issue occurred while processing order "+ncrnum+" Kindly Contact Admin", BackTo="/ncr" )
                elif  MainNCRData[0]['Status'] < '3':
                    return render_template("GeneralMessage.html",msgcolor = "Red", MSGBody="Order still in progress", BackTo="/ncr" )
                elif  MainNCRData[0]['Status'] > '3':
                    return render_template("GeneralMessage.html",msgcolor = "Red", MSGBody="Order already Approved", BackTo="/ncr" )
                return render_template("GeneralMessage.html",msgcolor = "Red", MSGBody="You don't have authority to preform this action", BackTo="ncr" )
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp
 


@app.route('/ncr/insertComm/<ncrnum>',methods=["POST"])
def PostComment(ncrnum):
    appTxt = "/ncr"
    ThisAuth = 'NCRC'
    ThisRoute = '/ncr/insertComm'
    MTitle = "NCR Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                Comment=request.form.get("Comment")
              
                CommentBy=ActiveSessions[SID]["UserId"]

                Comm= {

                    'NCRNumber':ncrnum,
                    'Comment':Comment,
                    'CommentBy':CommentBy}
                    
                def InsertComment(Comm):  
                    InsertComm= """ Insert INTO HES.dbo.SAI_NCRComments
                                    (date,Comment,CommentBy,NCRNumber)

                            values   
                            """
                        
            
                    Comment = Comm["Comment"]
                    CommentBy = Comm["CommentBy"]
                    NCR_Number = Comm["NCRNumber"]
                    InsertCommData =  """
                                (
                                    GETDATE(),
                                '"""+  Comment  +"""','"""+ CommentBy +"""'
                                ,'"""+ NCR_Number +"""'
                                )
                            """
                
                
                
                   
                    global conn
                    cr = conn.cursor()
                    cr.execute(InsertComm + " " + InsertCommData )
                    conn.commit()    
                InsertComment(Comm)  
                return redirect('/ncr')

                
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route("/updatencr", methods=["POST"])
def UpdateNCR():
    Res = NCRM.updateNCRStatus(request.json)
    # logging.debug("Update Status is : "+str(Res) )

    if Res["Status"]:
        r ={"Response":"OK"}
        return make_response(json.dumps(r),200)
    else:
        if Res["Disc"]=="DBTimeOut":
            r ={"Response":"NOK-DB Issue"}
            print(Fore.RED+'---------------------- DBTimeOut ----------------------: '  +Style.RESET_ALL )
            logging.critical("--------- DBTimeOut --------- Failed update FIR")       
            return make_response(json.dumps(r),406)
        else:
            r ={"Response":"OK"}
            return make_response(json.dumps(r),200)


@app.route("/Multiupdatencr", methods=["POST"])
def MultiUpdateNCR():
    Res = NCRM.MultiupdateNCRStatus(request.json)
    if Res["Status"]:
        r ={"Response":"OK"}
        return make_response(json.dumps(r),200)
    else:
        if Res["Disc"]=="DBTimeOut":
            r ={"Response":"NOK-DB Issue"}
            return make_response(json.dumps(r),406)
        else:
            r ={"Response":"OK"}
            return make_response(json.dumps(r),200)


@app.route('/ncr/download/<path:filename>', methods=['GET', 'POST'])
def download(filename):
    appTxt = "/ncr"
    ThisAuth = 'PNCR'
    ThisRoute = '/ncr/download/'
    MTitle = "NCR Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                
                Folder = filename.split('_')
                path="templates/NCRs/" + Folder[0] 

                if os.path.exists(path +"/"+ filename +".docx") :
                    return send_from_directory(path , filename +".docx")
                else:
                     return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="Report Could Not be Downloaded", BackTo="/" )
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp




@app.route('/upload/<NCRNumber>', methods=['POST'])
def upload_files(NCRNumber):

    appTxt = "/ncr"
    ThisAuth = 'UNCA'
    ThisRoute = '/upload/'
    MTitle = "NCR Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):

                print(NCRNumber)
                SECApproval =request.form['flexRadioDefault']
                print(SECApproval)

                uploaded_file = request.files['file']
                filename = secure_filename(uploaded_file.filename)
                
                print(filename)
                if filename != '':
                    file_ext = os.path.splitext(filename)[1]

                    if file_ext not in app.config['UPLOAD_EXTENSIONS'] :
               
                        abort(400)
                    if os.path.exists("templates/NCRs/" + NCRNumber):
                        if SECApproval == 'SECApproval':
                            file_ext = os.path.splitext(filename)[1]
                            uploaded_file.save(os.path.join(app.config['UPLOAD_PATH'] + NCRNumber , filename))
                            now1 = datetime.now()
                            dt_string = now1.strftime("%d_%m_%Y_%H_%M_%S")
                            source=app.config['UPLOAD_PATH'] + NCRNumber+"/"+filename
                            destination=app.config['UPLOAD_PATH'] + NCRNumber+"/"+'SECApproval'+NCRNumber+file_ext
                            print (source+"$$"+destination)
                            os.rename(source,destination)

                            
                    else:
                        os.mkdir("templates/NCRs/" + NCRNumber)
                    if SECApproval == 'SECApproval':
                        file_ext = os.path.splitext(filename)[1]

                        uploaded_file.save(os.path.join(app.config['UPLOAD_PATH'] + NCRNumber , filename))
                        now1 = datetime.now()
                        dt_string = now1.strftime("%d_%m_%Y_%H_%M_%S")
                        source=app.config['UPLOAD_PATH'] + NCRNumber+"/"+filename
                        destination=app.config['UPLOAD_PATH'] + NCRNumber+"/"+'SECApproval'+"_"+dt_string+file_ext
                        print (source+"$$"+destination)
                        os.rename(source,destination)
        
                    return render_template("GeneralMessage.html",msgcolor = "lime",  MSGBody="File Uploaded Successfully", BackTo="/ncr" )
                else:
                     return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="File Could Not be Uploaded", BackTo="/" )
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp



########Download FIR Report ##############
@app.route('/DownloadReport/<ncr>/<path:filename>',methods=['GET'])
def upload(ncr,filename):
    # print(ncr,filename)
    # logging.debug(str(ncr)+str(filename))

    appTxt = "/ncr"
    ThisAuth = 'PNCR'
    ThisRoute = '/DownloadReport/'
    MTitle = "NCR Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                
                Folder = filename.split('_')
                path="templates/NCRs/" + Folder[0] 

                if os.path.exists(app.config['UPLOAD_PATH']+ncr) :
                    return send_from_directory(app.config['UPLOAD_PATH']+ncr, filename)
                else:
                     return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="Report Could Not be Downloaded", BackTo="/ncr" )
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/ncr" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/ncr" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/MultiDownload/Upload')
def MultiDownladUploader():
    appTxt = "/ncr"
    ThisAuth = 'PNCR'
    ThisRoute = '/MultiDownload/Upload'
    MTitle = "NCR Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                return render_template('MultiDownload.html')



            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route('/MultiDownload' , methods=['POST'])
def MultiDownlad():
    file = request.files["file"]
    appTxt = "/ncr"
    ThisAuth = 'PNCR'
    ThisRoute = '/bv MultiDownload'
    MTitle = "NCR Management"
    SID = request.cookies.get('SID')
    userid=ActiveSessions[SID]["UserId"]
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                allNCR = pd.read_sql( """
                        SELECT 
                            NCRNumber,Mail,Concat(CrUA.FirstName, ' ', CrUA.LastName) as Created_By
                        FROM 
                            HES.dbo.SAI_NCRs as NCR
                            inner join SAI_UserAccount as CrUA on CrUA.id = NCR.CreatedBy
                            LEFT JOIN HES.dbo.SAI_NCR_Statuses as ST ON ST.id = NCR.Status  
                        WHERE 
                            MainNCRNumber IS NULL and NCR.CreatedBy = '"""+userid+"""' and NCR.Status =6 """,  conn)
                if allNCR.empty:
                    return render_template("GeneralMessage.html",msgcolor = "red", MSGBody="No matching records for the requested data. Kindly check the status of the FIR orders before submitting.", BackTo="/" )
                else:
                    ListFIR= []
                    Emillist =[allNCR['Mail'][0]]
                    Uname=allNCR['Created_By'][0]
                    logging.info('Multiple download by '+Uname)
                    dateNOW = datetime.today().strftime('%Y_%m_%d_%H_%M_%S')
                    dst_dir = 'templates\\NCRs\\'+"MultiDwonloadFIR_"+userid+dateNOW 
                    if file:
                        df = pd.read_csv(file,dtype=str)
                        df.columns = ['NCRNumber']
                        AllData = allNCR[allNCR['NCRNumber'].isin(df['NCRNumber'])]
                        NAllData = df[~df['NCRNumber'].isin(allNCR['NCRNumber'])]
                        # print("Status Pending: "+str(AllData['NCRNumber']))
                        # print("Status Not Pending: "+str(NAllData['NCRNumber']))
                        if os.path.exists("templates/NCRs/"+"MultiDwonloadFIR_"+userid+dateNOW):
                            for i,r in AllData.iterrows():
                                # print("NCRs:"+str(r.NCRNumber))
                                ListFIR.append('templates\\NCRs\\'+str(r.NCRNumber)+"\\")
                            for s in ListFIR:

                                dirs = os.listdir(str(s))

                            for f in dirs:
                                # print("this is files to be copied "+str(f))
                                shutil.copy(str(s)+f, dst_dir)
                            shutil.make_archive(dst_dir,'zip',dst_dir)
                        else: 
                            try:
                        
                                os.mkdir( 'templates\\NCRs\\'+"MultiDwonloadFIR_"+userid+dateNOW)
                                for i,r in AllData.iterrows():
                                    ListFIR.append('templates\\NCRs\\'+str(r.NCRNumber)+"\\")
                                for s in ListFIR:
                                    dirs = os.listdir(str(s))                          
                                    for f in dirs:
                                        # print("this is files to be copied "+str(f))
                                        shutil.copy(str(s)+f, dst_dir)
                                shutil.make_archive(dst_dir,'zip',dst_dir)

                            except:

                                os.mkdir( 'templates\\NCRs\\'+"MultiDwonloadFIR_"+userid+dateNOW)
                                for i,r in AllData.iterrows():
                                    ListFIR.append('templates\\NCRs\\'+str(r.NCRNumber)+"\\")
                                for s in ListFIR:
                                    dirs = os.listdir(str(s))
                                for f in dirs:
                                    # print("this is files to be copied "+str(f))
                                    shutil.copy(str(s)+f, dst_dir)
                                shutil.make_archive(dst_dir,'zip',dst_dir)

                    msgbody = """<h3> Dear Eng """+Uname+"""</h3>
                                 <h3> Attached is the requested FIR Reports</h3>
                                 <h3>The following FIRs are not yet approved by responsible Engineer :\n</h3> """
                    msgbody+= """<table>
                                 <thead>
                                 <th>FIR Number</th>
                                 </thead>
                                 <tbody>
                                 """
                    if NAllData.empty:
                        msgbody= """<h3> Dear Eng. """+Uname+ """</h3><h3> Attached is the requested FIR Reports</h3><p><b><i>This is an automatically generated email – please do not reply to it. If you have any queries regarding your request please contact admin for support<br> Thank You. </i><b/></p> """
                        mailer.SendEmail(Emillist,[],['Maram.alkhatib@alfanar.com'],"Multiple FIR Reports. " + dateNOW, msgbody ,[r'D:\\SAI_System\\templates\NCRs\\MultiDwonloadFIR_'+userid+dateNOW+'.zip'])
                        logging.info('Multiple download non-approved ncrs')
                        dir_path = r'templates\\NCRs\\'+"MultiDwonloadFIR_"+userid+dateNOW
                        shutil.rmtree(dir_path, ignore_errors=True)
                        print("Deleted '%s' directory successfully" % dir_path)
                        print(msgbody)
                    else:
                        for k,v in NAllData.iterrows():
                            msgbody+="""<tr>

                        <td>"""+str(v['NCRNumber'])+"""</td>

                        </tr>"""
                        msgbody += """</tbody>
                        </table>
                        
                        <br> <p><b><i>This is an automatically generated email – please do not reply to it. If you have any queries regarding your request please contact admin for support<br> Thank You.</i><b/></p>"""

                        # print(msgbody)
                        mailer.SendEmail(Emillist,[],['Maram.alkhatib@alfanar.com'],"Multiple FIR Reports. " + dateNOW, msgbody ,[r'D:\\SAI_System\\templates\NCRs\\MultiDwonloadFIR_'+userid+dateNOW+'.zip'])
                        logging.info('Multiple download done')
                        dir_path = r'templates\\NCRs\\'+"MultiDwonloadFIR_"+userid+dateNOW
                        shutil.rmtree(dir_path, ignore_errors=True)
                        # logging.debug("Deleted '%s' directory successfully" % dir_path)
               
                return render_template("GeneralMessage.html",msgcolor = "lime", MSGBody="Your request has been recieved , you'll recieve e-mail with the result.", BackTo="/" )
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------

@app.route('/freesm', methods=["GET"])
def PrmiseTechData():
    return render_template('GSearchMeter.html')


@app.route('/freesm/showTechData', methods=["POST"])
def ShowOrderTechData():
    #SID = request.cookies.get('SID')
    
    SearchKey = request.form.get('searchmethod')
    SearchData = request.form.get('SCriteria')
    SearchSRC = request.form.get('searchsource')
    
    SData = GMD.GetMeterData(SearchKey, SearchData)
    if "data" in SData:
        TTT='http://maps.google.com/maps?daddr='+ SData['data']['Latitude']+','+ SData['data']['Longitude'] +'&amp;ll='
        #print(CheckUserAuth(SID,'SVCR'))
        return render_template("GInformationData.html",\
                                UserName = "Visitor User",\
                                PremiseNumber=SData['data']['Premise'],\
                                SubscriptionNumber = SData['data']['SubScriptionNum'],\
                                AccountNumber=SData['data']['AccountNumber'], \
                                MeterNumber = SData['data']['MeterSN'],\
                                OfficeNumber=SData['data']['Office'],\
                                Location=SData['data']['Latitude'] + ', ' + SData['data']['Longitude'] ,\
                                DriveTo = TTT,\
                                ALFMeter = "<span> </span><i class='bx bx-message-rounded-check bx-tada' style='color:#33ff00; float: right; font-size: x-large; font-weight: bold;'  ></i>" if IsAlFanarMeter(SData['data']['MeterSN']) else "<span> </span><i class='bx bxs-message-x bx-tada' style='color:red; float: right; font-size: x-large; font-weight: bold;'  ></i>"
                                )
    else:
        #return render_template("MessagePage.html",BColor = "Red", SystemMessage="This meter is out of your coverage areas.", ActionLink="sm", ActionMethod= "GET" )
        return render_template("GeneralMessage.html",msgcolor = "Red", MSGBody="Nothing found using your data......", MsgTitle="Site Locator", BackTo= "/freesm" )

#----------------------------------------------------------------------
#----------------------------------------------------------------------
#------------------------- Check AlfMeter -----------------------------
#----------------------------------------------------------------------

@app.route('/AlfMeter', methods=["GET"])
def AlfMeterReq():
    return render_template('AlfMeterSearch.html')

@app.route('/AlfMeter/Check', methods=["POST"])
def CheckAlfMeter():
    MeterNumber = request.form.get('SCriteria')
    tempconn = pyodbc.connect('DRIVER={SQL Server};SERVER=10.90.10.173,21532;DATABASE=HES;UID=Clevest;PWD=!C13ve$T')
    AlFanarMeters = pd.read_sql("select DeviceID, Owner from alf_meters WHERE DeviceID = '"+MeterNumber+"'",conn)
    tempconn.close()
    Owner = AlFanarMeters.iloc[0]['Owner']
    if Owner == "ALF":
        RespAlf= "AlFanar"
    elif Owner == "SEC" or Owner == "S-SEC":
        RespAlf= "SEC"
    else:
        RespAlf= ""

    if RespAlf != "":
        return render_template("AlfanarMeterCheck.html",\
                                UserName = "Guest User",\
                                MeterNumber = MeterNumber,\
                                Resp=RespAlf,\
                                ALFMeter = "<span> </span><i class='bx bx-message-rounded-check bx-tada' style='color:#33ff00; float: right; font-size: x-large; font-weight: bold;'  ></i>" if RespAlf == "AlFanar" else "<span> </span><i class='bx bxs-message-x bx-tada' style='color:red; float: right; font-size: x-large; font-weight: bold;'  ></i>"
                                )
    else:
        return render_template("GeneralMessage.html",msgcolor = "Red", MSGBody="Nothing found for Meter Number "+ str(MeterNumber), MsgTitle="Meter Check", BackTo= "/AlfMeter" )

    
#----------------------------------------------------------------------
#----------------------------------------------------------------------
#---------------------------- Order Management ------------------------
#----------------------------------------------------------------------

@app.route('/odm', methods=['GET'])
def GetOdf():
    appTxt = "/odm"
    ThisAuth = 'ROPH'
    ThisRoute = '/odm'
    MTitle = "Order Data Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                return render_template('OrderManagement.html')
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route("/oma", methods=['POST'])
def AcceptOrders():
    appTxt = "/odm"
    ThisAuth = 'ROPH'
    ThisRoute = '/oma'
    MTitle = "Order Data Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):

                myF = request.files['ophFile']
                if myF.filename.lower().endswith(".csv"):
                    OpNumber = str(uuid.uuid1()).replace("-","")
                    myF.save("templates/OImages/SRC/" + OpNumber + ".csv")
                    FileData = {"filename" : OpNumber + ".csv",
                                "userName" : ActiveSessions[SID]["UserFName"],
                                "Mail" : ActiveSessions[SID]["Mail"],
                                "UserId" : ActiveSessions[SID]["UserId"],
                                "RequestFile" : myF.filename
                                }
                    GOP.AppendToList(OpNumber, FileData)
                return render_template("GeneralMessage.html",msgcolor = "Lime", MsgTitle = MTitle, MSGBody="Your request has been submitted with number#" + OpNumber + " and it will be processed soon, you'll recieve mail with the result." , BackTo="/odm" )    
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route ('/odm/img/download/<oid>', methods=['GET','POST'])
def downloadorderimages(oid):
    
    appTxt = "/odm"
    ThisAuth = 'ROPH'
    ThisRoute = '/oma'
    MTitle = "Order Data Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                cUID = ActiveSessions[SID]["UserId"]
                NoExtend = ''
                if CheckUserAuth(SID, 'SAPH'):
                    NoExtend = ''
                else:
                    NoExtend =f" and requestor={cUID}"

                #print(f"Select * from SAI_OPDnld where id={oid} " + NoExtend)
                Simages = pd.read_sql(f"Select * from SAI_OPDnld where id={oid} " + ('' if CheckUserAuth(SID, 'SAPH') else f" and requestor={cUID}") , conn)
                if len(Simages) >0:
                    zfSize = os.path.getsize("templates/OImages/" + Simages.iloc[0]["requestnumber"] + '.zip')
                    zfSize = zfSize / ( 1024 * 1024 )
                    if zfSize > 7:
                        reqIP = str(request.remote_addr)
                        if reqIP.startswith("10.90."):
                            if reqIP.startswith("10.90.10."):
                                pass
                            else:
                                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You can't download this request photos throw HHU network..." , BackTo="/odm" )    
                    return send_from_directory(directory="templates/OImages", path=Simages.iloc[0]["requestnumber"] + '.zip')
                else:
                    return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You are following wrong/expired link or you may don't have access to this link...." , BackTo="/odm" )    
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp

@app.route("/odm/myrequests", methods=['GET'])
def myRequests():
    appTxt = "/odm"
    ThisAuth = 'ROPH'
    ThisRoute = '/odm/myrequests'
    MTitle = "Order Data Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth):
                    UID = ActiveSessions[SID]["UserId"]
                    UserName = ActiveSessions[SID]["UserFName"]
                    SQLData = pd.read_sql(f"Select id, UploadedFile , format(ExpirationDate,'dd-MMM-yyyy') as Expiration, requeststatus as Status from [HES].[dbo].[SAI_OPDnld] where [requestor]={UID}", conn).fillna('')
                    sRows = []
                    K = 1
                    for i, row in SQLData.iterrows():
                        nLine = {
                            "Ser" : str(K),
                            "File" : row.UploadedFile,
                            "id" : row.id,
                            "Expiration" : row.Expiration,
                            "Status" : row.Status
                        }
                        sRows.append(nLine)
                        K+=1
                    print(sRows)
                    #sRowsx = ["s","sp"]
                    return render_template("OrderManDownload.html", UName = UserName, sRowsx= sRows)
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp
    


#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------
#----------------------------- PLAN Management -------------------------------------
#-----------------------------------------------------------------------------------
#-----------------------------------------------------------------------------------

@app.route('/plan', methods=['GET'])
def cPlanHTML():
    appTxt = "/plan"
    ThisAuth = 'PMRE'
    ThisRoute = '/plan'
    ThisAuth2 = 'UAAS'
    MTitle = "Plan Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth) or CheckUserAuth(SID, ThisAuth2):
                    UID = ActiveSessions[SID]["UserId"]
                    UserName = ActiveSessions[SID]["UserFName"]
                    cuDate = (datetime.now() + timedelta(days=1)) if int(datetime.now().strftime('%H')) <= PlanEndTime else (datetime.now() + timedelta(days=2))
                    TPiC = "Last hour plan, tomorrow plan will be closed soon.!" if int(datetime.now().strftime('%H')) == PlanEndTime else ("" if int(datetime.now().strftime('%H')) < PlanEndTime else "Tomorrow Plan is closed already....!!!")
                    return render_template("PlanUploader.html", TPIC=TPiC , mnDate = cuDate.strftime('%Y-%m-%d'), mxDate = (cuDate + timedelta(days=7)).strftime('%Y-%m-%d') , cDate = cuDate.strftime('%Y-%m-%d') , data=ActiveSessions[SID]["Auths"])
            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp    

@app.route('/plan/upload', methods=['GET','POST'])
def cPlanCreate():
    if request.method == "GET":
        return redirect("/plan")
    appTxt = "/plan"
    ThisAuth = 'PMRE'
    ThisAuth2 = 'UAAS'
    ThisRoute = '/plan/upload'
    MTitle = "Plan Management"
    SID = request.cookies.get('SID')
    if TestAndExtendSession(SID):
        if CheckAppInSession(SID, appTxt):
            if CheckUserAuth(SID, ThisAuth) or CheckUserAuth(SID, ThisAuth2):
                    UID = ActiveSessions[SID]["UserId"]
                    UserName = ActiveSessions[SID]["UserFName"]
                    mMail = ActiveSessions[SID]["Mail"]
                    
                    if request.form.get("optradio") == "plan":
                        PDate = request.form.get("PlanDate")
                        fname =request.files['csvfile'].filename 
                        dFile =request.files['csvfile']
                        print(PlanEndTime)
                        print(int(datetime.now().strftime('%H')))
                        if (int(datetime.now().strftime('%H')) > PlanEndTime) and (PDate == (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d')):
                            MSGCLR = "OrangeRed"
                            TXTComments = "Your file ("+ fname +") has been rejected for ("+ PDate +"), you missed this plan window."
                            TPiC = "Last hour plan, tomorrow plan will be closed soon.!" if int(datetime.now().strftime('%H')) == PlanEndTime else ("" if int(datetime.now().strftime('%H')) < PlanEndTime else "Tomorrow Plan is closed already....!!!")
                            cuDate = (datetime.now() + timedelta(days=1)) if int(datetime.now().strftime('%H')) <= PlanEndTime else (datetime.now() + timedelta(days=2))
                            return render_template("PlanUploader.html", MSGCLR = MSGCLR ,TPIC =TPiC ,TXTComment=TXTComments , mnDate = cuDate.strftime('%Y-%m-%d'), mxDate = (cuDate + timedelta(days=7)).strftime('%Y-%m-%d') , cDate = cuDate.strftime('%Y-%m-%d') , data=ActiveSessions[SID]["Auths"], fData={})
                        df_thisFile = pd.read_csv(dFile, dtype=str, header=None)
                        tDict = { 
                                    "File" : df_thisFile , 
                                    "filename": fname, 
                                    "UserID" : UID ,
                                    "Date" : datetime.strptime(PDate,'%Y-%m-%d') , 
                                    "Mail" : mMail, 
                                    "userfname":UserName}
                        myPM.Plan_NFiles.append(tDict)
                        if myPM.CheckIfProcessIsLive():
                            #print("It is live")
                            pass
                        else:
                            myPM.StartProcess()
                        MSGCLR = "Lime"
                        TXTComments = "You file (" + fname + ") has been recieved, you'll recieve mail with the result..."
                        #print(datetime.now().strftime('%H'))
                        TPiC = "Last hour plan, tomorrow plan will be closed soon.!" if int(datetime.now().strftime('%H')) == PlanEndTime else ("" if int(datetime.now().strftime('%H')) < PlanEndTime else "Tomorrow Plan is closed already....!!!")
                        cuDate = (datetime.now() + timedelta(days=1)) if int(datetime.now().strftime('%H')) <= PlanEndTime else (datetime.now() + timedelta(days=2))
                        return render_template("PlanUploader.html", msgCLR=MSGCLR ,TPIC =TPiC ,TXTComment=TXTComments , mnDate = cuDate.strftime('%Y-%m-%d'), mxDate = (cuDate + timedelta(days=7)).strftime('%Y-%m-%d') , cDate = cuDate.strftime('%Y-%m-%d') , data=ActiveSessions[SID]["Auths"], fData={})
                    else:
                        fname = request.files['csvfileAssign'].filename
                        dFile = request.files['csvfileAssign']
                        df_thisFile = pd.read_csv(dFile, dtype=str, header=None)
                        df_thisFile = df_thisFile[[0,1]]
                        df_thisFile.columns = ["HostOrderNumber", "Worker"]
                        df_thisFile = df_thisFile.drop_duplicates(keep="first", subset=["HostOrderNumber"])
                        orderHosts = ""
                        ocnt = 0
                        for i, row in df_thisFile.iterrows():
                            ocnt += 1
                            if len(orderHosts) == 0 :
                                orderHosts = "'" +  row.HostOrderNumber + "'"
                            else:
                                orderHosts += ",'" +  row.HostOrderNumber + "'"
                        SSQL = """Select HostOrderNumber, format(OrderTypeId,'#') as OrderTypeId, format(OrderStatusId, '#') as OrderStatusId from Clevest.dbo.workordermapping where hostordernumber in (""" + orderHosts + """) """
                        cnx = pyodbc.connect(ClConnectionStr)
                        dta = pd.read_sql(SSQL, cnx)
                        print(SSQL)
                        print(dta)
                        cnx.close()
                        
                        df_thisFile = pd.merge(df_thisFile, dta, right_on='HostOrderNumber', left_on='HostOrderNumber', how='left')
                        df_thisFile["Status"]="Accepted"
                        df_thisFile = df_thisFile.fillna("NaN")
                        
                        df_thisFile.loc[~df_thisFile["OrderStatusId"].isin(['20','40','60','90']) , "Status"] = "Rejected - Order Status Not Accepted"
                        df_thisFile.loc[~df_thisFile["OrderTypeId"].isin(["1", '3', '5', '10', '12', '11', '8','13']) , "Status"] = "Rejected - Order Type not in assignable orders"
                        df_thisFile.loc[df_thisFile["OrderTypeId"]=='NaN' , "Status"] = "Order Not In Clevest"
                        df_accepted = df_thisFile[df_thisFile["Status"]=='Accepted']
                        
                        file_init = datetime.now().strftime('%Y%m%d%H%M%S') + '_' + str(UID) + '_'
                        for key, grp in df_accepted.groupby("OrderTypeId"):
                            grp[["HostOrderNumber", "Worker"]].to_csv(dict_HostExchange[key]["FilePath"] + "/" + dict_HostExchange[key]["FileNameTemplate"].replace('%',file_init) , header=False, index=False)
                        
                        #"1" : {
                        #        "Name" : "MEX"
                        #        ,"FilePath" : "//10.90.10.59/prd/AllHostExchange/SingleUpdateFolder"
                        #        ,"FileNameTemplate" : "%_Assign_MEX.csv"
                        #      }
                        ffData = {}
                        tblRows = []
                        kv = 0
                        for key, grp in df_thisFile.groupby("Status"):
                            kv+=1
                            #print(kv)
                            tblRows.append([kv, key, len(grp)])
                        
                        MSGCLR = "Lime"
                        ffData["tbl"] = tblRows
                        TXTComments = "You file (" + fname + ") has been recieved, Find result as bellow..."
                        #print(datetime.now().strftime('%H'))
                        TPiC = "Last hour plan, tomorrow plan will be closed soon.!" if int(datetime.now().strftime('%H')) == PlanEndTime else ("" if int(datetime.now().strftime('%H')) < PlanEndTime else "Tomorrow Plan is closed already....!!!")
                        cuDate = (datetime.now() + timedelta(days=1)) if int(datetime.now().strftime('%H')) <= PlanEndTime else (datetime.now() + timedelta(days=2))
                        #print(json.dumps(ffData, indent=4))
                        return render_template("PlanUploader.html", msgCLR=MSGCLR ,TPIC =TPiC ,TXTComment=TXTComments , mnDate = cuDate.strftime('%Y-%m-%d'), mxDate = (cuDate + timedelta(days=7)).strftime('%Y-%m-%d') , cDate = cuDate.strftime('%Y-%m-%d') , data=ActiveSessions[SID]["Auths"], fData=ffData)

                        

                        



            else:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to do this action.("+ ThisAuth +")", BackTo="/" )
        else:
            return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = MTitle, MSGBody="You don't have authority to open this application.", BackTo="/" )
            
    else:    
        resp = make_response(render_template("Login.html", NextPage = ThisRoute))
        resp.set_cookie("LoggedIn","False")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        return resp













@app.route('/gsm/test',methods=['GET','POST'])
def GSM_Resp():
    return "Key:0120223023024"

#import folium
#import webbrowser
#@app.route("/userlocation")
#def getuserlocation():
#    xconn = pyodbc.connect('DRIVER={SQL Server};SERVER=10.90.10.173,21532;DATABASE=HES;UID=Clevest;PWD=!C13ve$T')
#    fff = pd.read_sql("""/****** Script for SelectTopNRows command from SSMS  ******/
#            SELECT TOP (1000) [Id]
#                  ,[Timestamp]
#                  ,[WorkerId]
#                  ,[GPSFixDate]
#                  ,[Latitude]
#                  ,[Longitude]
#                  ,[MotionState]
#              FROM [Clevest].[dbo].[WorkerPoint] where WorkerId=979 and Timestamp > format(GETDATE(),'yyyy-MM-dd')""", xconn)
#    xconn.close()
#    m = folium.Map(location=[24.7136, 46.6753], zoom_start=11)
#    for i, row in fff.iterrows():
#        folium.Marker(location=[row.Latitude,row.Longitude], popup="worker").add_to(m)
#    return m.get_root().render()

#app.run(host='0.0.0.0',port=80,debug=False,threaded=True)
app.run(host='0.0.0.0',port=7080 if AppDebugMode else 80 ,debug=AppDebugMode,threaded=True)
#context = ('t-mwfm.alfanar.com.crt','t-mwfm.alfanar.com.key')
#app.run(host='0.0.0.0',port=443,debug=True,threaded=True, ssl_context=context)
