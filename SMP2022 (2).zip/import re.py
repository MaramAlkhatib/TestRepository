from csv import writer
import re
import csv

f = open(r"D:\Scripts\docs\logfile.log.7", "r")
print("pattern1[1]")
s = f.read()
f.close
pattern = r"""update \[HES\].\[dbo\].\[SAI_CMInst_Request_Stages\] set RespMSG='{
    "replyServiceRequest": {
        "header": {
            "verb": "reply",
            "noun": "ServiceRequest",
            "revision": "41",(?s:.*?)"context": "PRODUCTION",
            "source": "SE"
        },
        "reply": {
            "result": "FAILED",
            "error": \[
                {(?s:.*?)Execution Error"""
print(1)

lst = []
  
for i in re.finditer(pattern,s):
    j = i[0].split("Execution Error")
    print(j[0])
    print("~~~~~~~~~~~~~~~~~~~~")

print(lst)
print("done")










# paths = [r"D:\Scripts\docs\logfile.log.*"]
# list_of_files = []
# for path in paths:
#     list_of_files.extend(glob.glob(path))
# #Find the latest log file from all the servers:
# if list_of_files:
#     for latest_file in list_of_files:
#         print(latest_file)
#         f = open(os.path.join(latest_file), "r")
#         s = f.read()
#     #Search for the required pattern:
#         pattern1 = re.search(r"update.{14}SAI_CMInst_Request_Stages(.*\n.*){25} Execution Error", s)
#         print(pattern1)
#         break









# file= open(r"D:\Scripts\docs\FAILEDlogfile.csv","w")
# writer = csv.writer(file)
    # if i[1] == " Execution Error":
    #     print(i)

    
    # lst.append(j[0])
    # writer.writerow(j[0])
    # print(i)

# file.close