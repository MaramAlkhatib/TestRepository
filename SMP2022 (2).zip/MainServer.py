from flask import Flask, request, render_template, redirect, make_response
from cryptography.fernet import Fernet
import uuid
from datetime import datetime
from datetime import timedelta
import pandas as pd
import pyodbc
import json


#Intitiate Encryption
key = b'JNQcis_GHIF_-kQUkCbJV4VsShKpnPvf-4zSrSysT-Q='
fernet = Fernet(key)


#Intiate Active Sessions dataframe
D=[['X',datetime.today(),"-1"]]
ActiveSessions=pd.DataFrame(D, columns=['Session', 'ExpireDate', 'UID'])
SessionDuration = timedelta(hours=48)


#Initiate  DB connection
conn = pyodbc.connect('DRIVER={SQL Server};SERVER=10.90.10.173,21532;DATABASE=HES;UID=Readonly;PWD=PobUP3?A8lnIredRa_Lb')


#Check if Session is active
def CheckSession(SessionId):
    global ActiveSessions
    global SessionDuration
    RequiredSession = ActiveSessions[ActiveSessions['Session']==SessionId]
    if len(RequiredSession) > 0:
        # SECMD.loc[SECMD['Premise']==row.Premise,['Equip. No']]= ('0' * (18 - len(row.Equip))) + row.Equip
        if RequiredSession.iloc[0].ExpireDate > datetime.today():
            ActiveSessions.loc[ActiveSessions['Session']==SessionId,['ExpireDate']]= datetime.today() + SessionDuration
            EDate = datetime.today() + SessionDuration
            return True, EDate.strftime("%Y-%m-%d %H:%M:%S"), str(RequiredSession.iloc[0].UID)
        else:
            return False, datetime.today(), ""
    else:
        return False, datetime.today(), ""


#Deactivate all active user sessions  
def DeleteUserActiveSessions(UID):
    return True

def InsertLog(Llevel, MSG):
    dateTimeObj = datetime.now()
    print(str(dateTimeObj) + '    ' + Llevel +  '    ' + MSG)
    

#UserLogIn
def UserLoginStatus(UName, UPass):
    global key
    global SessionDuration
    global ActiveSessions
    global conn
    SQL="Select * from HES.dbo.SAI_UserAccount where UserName='" + UName + "'"
    UData = pd.read_sql(SQL, conn)
    if len(UData)>0:
        dbPass = UData.iloc[0].Password
        encPass = dbPass.encode()
        DBPure = fernet.decrypt(encPass).decode()
        if DBPure==UPass:
            #APPs = pd.read_sql("Select Apps.AppName, Apps.AppRout from HES.dbo.SAI_UserAppAssociation UAA inner join HES.dbo.SAI_Applications APPs on APPs.id = UAA.ApplicationId where UAA.Userid='" + str(UData.iloc[0].id) + "' and Apps.Auth=1 order by Apps.AppName",conn)
            #Areas = pd.read_sql("Select Area from HES.dbo.SAI_UserAreaAssociation where UserId='" + str(UData.iloc[0].id) + "' order by Area",conn)
            EDate = datetime.today() + SessionDuration
            CSID = str(uuid.uuid1())
            
            URData = {
                "LoggedIn":True,
                "Session":{
                            "id":CSID ,
                            "SessionExpiration" : EDate.strftime("%Y-%m-%d %H:%M:%S") 
                          },
                "Udata":  { "id":str(UData.iloc[0].id),
                            "username":str(UData.iloc[0].UserName),
                            "firstname":str(UData.iloc[0].FirstName),
                            "lastname":str(UData.iloc[0].LastName),
                            "fullname":str(UData.iloc[0].FirstName) + ' ' + str(UData.iloc[0].LastName),
                            "mobilenum":str(UData.iloc[0].MobileNum),
                            "mail":str(UData.iloc[0].Mail),
                            "forcechangepass":str(UData.iloc[0].ForcePassChange)
                            
                                
                          }
                
            }
           
            InsertLog("INFO", "New user login " + str(UData.iloc[0].id))
            ActiveSessions=ActiveSessions.append({'Session' : CSID, 'ExpireDate': EDate, 'UID':UData.iloc[0].id}, ignore_index=True)
           
            return URData

        else:
            return {"LoggedIn": False}
        
    else:
        return {"LoggedIn": False}
    














app = Flask(__name__, static_folder='templates')


#app.add_url_rule('/login', 'UserLogin', view_func=Userdata.UserLogIn, methods=['POST'])
@app.route('/', methods=["GET"])
def home():
    SS, SDate, UID = CheckSession(request.cookies.get('SID'))
    if SS: 
        return render_template('AllApplication.html')
    else:
        resp = make_response(render_template('AllApplication.html'))
        resp.set_cookie("LoggedIn","")
        resp.set_cookie("SID","")
        resp.set_cookie("ExpireDate", "")
        resp.set_cookie("UserName", "")
        return resp

@app.route('/Login', methods=["GET","POST"])
def login():
    
    if request.method=="GET":
        return render_template('Login.html', NextPage='/')
    else:
        uname=request.form.get('UserName')
        upass=request.form.get('Password')
        UNext= request.form.get('Next')
        LoginData=UserLoginStatus(uname, upass)
        InsertLog("INFO",str(LoginData))
        if LoginData["LoggedIn"]:
            resp = make_response(redirect(UNext))
            resp.set_cookie("LoggedIn","True")
            resp.set_cookie("SID",str(LoginData["Session"]["id"]))
            resp.set_cookie("ExpireDate", str(LoginData["Session"]["SessionExpiration"]))
            print(str(LoginData["Udata"]["fullname"]))
            resp.set_cookie("UserName", str(LoginData["Udata"]["fullname"]))
            return resp
        return render_template('Login.html', NextPage=UNext)

@app.route('/logout', methods=["GET","POST"])
def logout():
    UNext='/'
    resp = make_response(redirect(UNext))
    resp.set_cookie("LoggedIn",'')
    resp.set_cookie("SID",'')
    resp.set_cookie("ExpireDate", '')
    resp.set_cookie("UserName", '')
    return resp

def MakeTableJson(df):
    x=    df.to_json(orient="records")
    d = json.loads(x)
    print(d)
    return {"data":d}
    


         
@app.route('/getapps', methods=["GET"])
def getapps():
    print(str(ActiveSessions))
    print(request.cookies.get('SID'))
    SS, SDate, UID = CheckSession(request.cookies.get('SID')) 
    if SS:
        SQL = "SELECT [SAI_Applications].AppName ,[SAI_Applications].AppRout   FROM [SAI_UserAppAssociation] inner join [SAI_Applications]  on [SAI_Applications].id = [SAI_UserAppAssociation].ApplicationId   where userid=" + UID 
        print(MakeTableJson(pd.read_sql(SQL,conn)))
        return MakeTableJson(pd.read_sql(SQL,conn))
    else:
        pass
    
        
    return '{"data":[{"name":"Ehab","lname":"Maher"},{"name":"Mohamed","lname":"Maher"}]}'

#ALL Serveric APPLICATION .........
@app.route('/Server', methods=["GET"])
def ServerHome():
        AppName=request.form.get('AppName')
        return render_template('Serveric.html')

#BurntMeter Appliction .........
@app.route('/BM', methods=["GET"])
def BurntMeter():
        return render_template('BurntMeter.html')        


@app.route('/BM/Search', methods=["GET"])
def SearchMeter():
        return render_template('InformationData.html')   

app.run(host='0.0.0.0',port=8090,debug=True,threaded=True)



