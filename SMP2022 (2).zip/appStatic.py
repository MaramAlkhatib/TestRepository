from flask import Flask, request,  render_template, redirect, make_response, send_from_directory,abort, send_file,url_for,jsonify, g
import pandas as pd
import csv
import pyodbc
import numpy as np
from datetime import datetime
import os, random, math, smtplib, ssl, json, time, glob
import re
import jwt

CLconnstr = 'DRIVER={SQL Server};SERVER=HO-MWFMDB.alfanar.com,1433;DATABASE=Clevest;UID=clevest;PWD=!C13ve$T'
connstr = 'DRIVER={SQL Server};SERVER=HO-MWFMDB.alfanar.com,1433;DATABASE=HES;UID=clevest;PWD=!C13ve$T'
InDBstr = 'DRIVER={SQL Server};SERVER=HO-MWFMDB.alfanar.com,1433;DATABASE=Ticketing;UID=clevest;PWD=!C13ve$T'

app = Flask(__name__, static_folder='templates')

StatusKeys = {"New": "primary"
            , "Completed": "success"
            , "Rejected": "secondary"
            , "Re-opened": "info"
            , "Accepted": "warning"
            , "In-Progress": "warning"
            , "In-Progress with HES": "warning"
            , "Pending on material": "warning"
            , "Pending on weather": "warning"
            , "Pending on SEC": "warning"
            , "Pending on others": "warning"
            , "Clevest Order in-progress": "warning"
            , "Cancelled": "secondary"
            , "Reassign to SEC FFM": "dark"
             } 
 
@app.route("/ATS", methods=['GET','POST'])
def ATS_Dashboared():
    global StatusKeys
    ThisAuth = 'ATWS'
     
     
    dfT =pd.read_excel("templates/ATS_Templates/tickets.xlsx", dtype=str)
  

    MAFdf = dfT[["EntityId","Incident_Number","Premise","Status","OfficeID","DeviceId","LastAction","CurrentComment","MustCloseBefore","ControllerGroup","ReopenCounter"]]
    if ThisAuth in ("ATWE","ATWS"):
        MAFdf = MAFdf[MAFdf["ControllerGroup"] == "MAF-WFMS"]
    elif ThisAuth in ("ATHS","ATHE"):
        MAFdf = MAFdf[MAFdf["ControllerGroup"] == "HES"]
    
    return render_template('MyBoardServerSide.html',ticketTable = MAFdf,data = dfT, StatusKeys=StatusKeys, MyOffices = pd.read_csv("templates/ATS_Templates/mygroups.csv"))

users =pd.read_excel("templates/ATS_Templates/tickets.xlsx", dtype=str)


# ----------------------------------------------------------------------------- 

@app.route("/ATS/TicketInfo/<TicketNumber>", methods=['GET','POST'])
def ATS_getTicket(TicketNumber):
    global StatusKeys
 
    dfT =pd.read_excel("templates/ATS_Templates/tickets.xlsx")

    dfT = dfT[dfT["EntityId"].astype(str)==TicketNumber]
    ThisAuth = "ATWS"
    toolbar = "MAFTools" if ThisAuth in ("ATSA","ATWS") else "HESTools"
         

    dfT["Duein"] = ((pd.to_datetime(dfT["MustCloseBefore"]) -  datetime.datetime.now()).astype('timedelta64[h]')).astype(int)
    dfT["MustCloseBefore"] = dfT["MustCloseBefore"].dt.strftime('%d-%m-%y %H:%M:%S')
    dfT["CreationDateTime"] = dfT["CreationDateTime"].dt.strftime('%d-%m-%y %H:%M:%S')
    dfT["LastActionDate"] = dfT["LastActionDate"].dt.strftime('%d-%m-%y %H:%M:%S')
 
    # print(toolbar)
    return render_template('ATS_Templates/TicketDetails.html',ticket= dfT,toolbar=toolbar,  StatusKeys=StatusKeys, MyOffices = pd.read_csv("templates/ATS_Templates/mygroups.csv"))
 
# ----------------------------------------------------------------------------- 

@app.route("/ATS/BalaghForm", methods=['GET','POST'])
def get_BalaghForm():
    return render_template('ATS_Templates/BalaghForm.html')
      

@app.route("/ATS/newBalagh", methods=['POST','GET'])
def ATS_CreateBalagh():
    EntityId = 'uuid'
    UserId = 'ActiveSessions[SID]["UserId"]'
    BalaghDate = request.values.get('inputDate')
    MailTitle = request.values.get('inputSubject')
    ReplyTo = request.values.get('inputReplyTo')
    ReplyCC = request.values.get('inputReplyCC')
    RecFrom = request.values.get('inputReceivedName')
    RecEmail = request.values.get('inputReceivedEmail')
    EVERYBALAGH = 1 if request.values.get('Balagh_emails') in ('y','Y') else 0
    EVERYTICKET =  1 if request.values.get('Tickets_emails') in ('y','Y') else 0
    print(   EntityId ,    UserId ,    BalaghDate ,    MailTitle ,    ReplyTo ,    ReplyCC ,    RecFrom ,    RecEmail ,    EVERYBALAGH ,    EVERYTICKET )
    SQL="""INSERT INTO Ticketing.dbo.Balaghat 
                (EntityId,CreatedBy,BalaghDate,MailTitle,ReplyTo,ReplyCC,Status,RecFrom,RecFromMail,SendMailForEveryTicket,SendMailForClosing)
            VALUES
                ('_ENTITY_','_USESRID_','_BDATE_','_MAILTITLE_','_TO_','_CC_','1100','_FROM_','_FROMEMAIL_',_EVERYBALAGH_,_EVERYTICKET_)
            """
            
    to_replace = {"_ENTITY_": EntityId, "_USESRID_":UserId, "_BDATE_": BalaghDate, "_MAILTITLE_": MailTitle, "_TO_":ReplyTo, "_CC_":ReplyCC,"_FROM_":RecFrom,"_FROMEMAIL_":RecEmail,"_EVERYBALAGH_":EVERYBALAGH,"_EVERYTICKET_":EVERYTICKET}

    for char in to_replace.keys():
        SQL = SQL.replace(char, str(to_replace[char]))

    print("Altered string: " + SQL)
    # CLconn = pyodbc.connect(InDBstr)
    # NewBalaghSQL = pd.read_sql(SQL, CLconn)
    # CLconn.close()
    # return 200
    return render_template('ATS_Templates/TicketForm.html',E_ID = EntityId)

    
 

# StatusKeys = {
#                10000: "primary", New
    #          , 10100: "warning", Accepted
    #          , 10200: "secondary", Rejected
    #          , 10300: "dark", Reassign to SEC FFM
    #          , 10400: "warning", In-Progress
    #          , 10500: "warning", In-Progress with HES
    #          , 10510: "warning", Pending on SEC
    #          , 10520: "warning", Pending on material
    #          , 10530: "warning", Pending on weather
    #          , 10540: "warning", Pending on others
    #          , 10600: "warning", Clevest Order in-progress    
    #          , 10700: "success", Completed
    #          , 10800: "secondary", Cancelled
    #          , 10900: "info", Re-opened
    #      
    #           } 

actionsStatuses = {
    "Accepted": {"Prev_status": [10000, 10900], "New_status": 10100},
    "Rejected": {"Prev_status": [10000, 10900], "New_status": 10200},
    "Sent to HES": {"Prev_status": [10100, 10400], "New_status": 10500},
    "Re-sent to SEC": {"Prev_status": [10100, 10400], "New_status": 10300},
    "Pended on Meterial ": {"Prev_status": [10100, 10400], "New_status": 10520},
    "Pended on Weather ": {"Prev_status": [10100, 10400], "New_status": 10530},
    "Pended on SEC": {"Prev_status": [10100, 10400], "New_status": 10510},
    "Pended on Other": {"Prev_status": [10100, 10400], "New_status": 10510},
    "Ticket Closed": {"Prev_status": [10100, 10400], "New_status": 10700},
    "Cancelled": {"Prev_status": [10100, 10400], "New_status": 10800},
    "Order Created": {"Prev_status": [10100, 10400], "New_status": 10600},
    "Re-opened": {"Prev_status": [10800, 10700], "New_status": 10900},
    "Resolved": {"Prev_status": [10520, 10530, 10510, 10540], "New_status": 10400},
    "HES - Complete": {"Prev_status": [10520, 10530, 10510, 10540], "New_status": 10400},
}

  
@app.route("/ATS/TicketInfo/update", methods=['GET','POST'])
def ATS_TicketUpdate():
    dfT =pd.read_excel("templates/ATS_Templates/tickets.xlsx")

    actionType = request.form.get('actionType')
    TicketID = request.form.get("TicketID")
    actionComment = request.form.get("actionComment")
    dfT = dfT[dfT["id"].astype(str)==TicketID]
    ticketStatus = dfT.iloc[0]["OrderStatusId"]
    # uid = ActiveSessions[SID]["UserId"]
    uid = 21
    ExtraChanges = ""
    sqlstr = """UPDATE  
                    Tickets
                SET
                    Status = _STATUSCODE_
                    ,CurrentComment= '_CURRENTCOMMENT_'
                    ,LastActionDate=getDate()
                    ,LastActionBy= """+str(uid)+"""
                    ,LastActionTypeId=_ACTIONID_
                    _ExtraChanges_
                WHERE id="""+str(TicketID)+""" """
    
    if actionType == "Order Created":
        premise = dfT.iloc[0]["Premise"]
        prev_order  = "select HostOrderNumber from WorkOrderMapping where HostOrderNumber like '"+ premise +"%' and OrderStatusId not in (100, 80) and ordertypeid in (13)"
        if len(prev_order) > 0 :
            return render_template("GeneralMessage.html", MsgTitle="Existing Order", MSGBody="Order already open is system", msgcolor = "red", BackTo="/ATS")
    
    if ticketStatus == 10900 and actionType=="Accepted":
        ExtraChanges = ", ReopenCounter = " + str(dfT.iloc[0]["ReopenCounter"].astype(int)+ 1)   
    
    if actionType == "Sent to HES":
        ExtraChanges = " ,ControllerGroup='HES'"  
    
    if actionType == "HES - Complete":
        ExtraChanges = " ,ControllerGroup='MAF-WFMS'"  
    
    if ticketStatus  in actionsStatuses[actionType]["Prev_status"] :
        #   actionstable = """select * from Actions"
        actionstable =pd.read_excel("templates/ATS_Templates/Book1.xlsx",sheet_name="Sheet3")    
        actiondata = actionstable[actionstable["Action"]==actionType]
        actiondata = actiondata.iloc[0]["Id"]
        sqlstr = sqlstr.replace("_STATUSCODE_",str(actionsStatuses[actionType]["New_status"])).replace("_CURRENTCOMMENT_",actionComment).replace("_ACTIONID_",str(actiondata)).replace("_ExtraChanges_",ExtraChanges)
        print(sqlstr)
        print("Updated")
    else:
        return render_template("GeneralMessage.html", MsgTitle="Processing Issue", MSGBody="An issue has occured. kindly chekc again later", msgcolor = "red", BackTo="/ATS")

    return redirect("/ATS")
 
 
# TODO: When moving the code to the server then mustremove this in BE and FE and redirect to an already existing function in SMPServer or at least use the SECMD already present in SMP
@app.route("/ATS/getSAPDate", methods=['GET','POST'])
def ReloadSECData():
    print("Retrieving Data...")
    Pnum = request.form['Pnum']
    global SECMD 
    SECfiles = glob.glob(r"C:\Users\Maram.Alkhatib\OneDrive - alfanar\Documents\SMP2022\SECMasterData\*.txt")
    li=[]
    i=0
    for filename in SECfiles:
            dfx = pd.read_csv(filename,delimiter=';',header=None, dtype=str,encoding = "utf-8",quoting=csv.QUOTE_NONE)
            i+=1
            li.append(dfx)
            print ('\r |' + ('#' * i) + ('-' * (len(SECfiles) - i)) + '| File loaded -- > ' + filename , end='')
            break
    SECMD =  pd.concat(li, axis=0, ignore_index=True)
    cols=['Premise','MRU','Office','fg. Ser. No','Meter Type','Equip. No','Cycle','Last Bill Key','Route Read Seq','MR Note','Date of MR Note','Critical Need','Service Class','Premise Address','City','District','Subscription No','Account No','BPName','BP Type','Latitude','Longitude','Mult. Factor','No. of Dials','Breaker Cap.','Voltage','Phase','Tariff Type','Prev Read Date T','Prev. Read T','Prev Read Date T1','Prev. Read T1','Prev. Read Date T2','Prev. Read T2','Prev Read Date T3','Prev. Read T3','Prev. Read Date T4','Prev. Read T4','Prev. Read Date T5','Prev. Read  T5','Prev. Read Date T6','Prev. Read  T6','Prev. Read Date T7','Prev. Read  T7','Avg. Consp. per day (kWh)','Accl. Premise No','Main Premise No','Conn. Type', 'F1','F2']
    SECMD.columns=cols
    SECMD = SECMD.fillna('')
    SECMD['fg. Ser. No']= SECMD['fg. Ser. No'].str.upper()
    SECMD = SECMD[SECMD["Premise"] == Pnum]
    print("jsonify(SECMD)") 
    print(SECMD.to_dict()) 
    print("jsonify(SECMD)") 
    # print(SECMD.to_json()) 
    return {'output':SECMD.to_dict('records')}

 
        
 



app.run(debug=True)


 