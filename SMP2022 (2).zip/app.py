from flask import Flask, request,  session,render_template, redirect, make_response, send_from_directory,abort, send_file,url_for,jsonify, g
import pandas as pd
import csv
import pyodbc
import numpy as np
from datetime import datetime
import os, random, math, smtplib, ssl, json, time, glob
import re
import jwt
import inspect
 

app = Flask(__name__, static_folder='templates')



BM2BM_Reasons = {}

def RefreshSM2SMReasons():  
    global BM2BM_Reasons
    conn2 = pyodbc.connect('DRIVER={SQL Server};SERVER=10.90.10.173,21532;DATABASE=Clevest;UID=clevest;PWD=!C13ve$T')
    SQL = "SELECT [id],[Reason],[SubReason] FROM [HES].[dbo].[SAI_BM_Reasons] order by [Reason],[SubReason]"
    subReasons = pd.read_sql(SQL, conn2)
    conn2.close()
    bm2bm = {}
    for i, row in subReasons.iterrows():
        if row["Reason"] in bm2bm.keys():
            pass
        else:
            bm2bm[row["Reason"]] = []
        bm2bm[row["Reason"]].append([row["SubReason"],row["id"]])
    BM2BM_Reasons = bm2bm

# RefreshSM2SMReasons()

def ReloadSECData():
  

    # SEC Data
    global SECMD 
    SECfiles = glob.glob( "SECMasterData/*.txt")

    li=[]
    i=0
    for filename in SECfiles:
            dfx = pd.read_csv(filename,delimiter=';',header=None, dtype=str,encoding = "utf-8",quoting=csv.QUOTE_NONE)
            i+=1
            li.append(dfx)
            print ('\r |' + ('#' * i) + ('-' * (len(SECfiles) - i)) + '| File loaded -- > ' + filename , end='')
            break

    SECMD =  pd.concat(li, axis=0, ignore_index=True)
    cols=['Premise','MRU','Office','fg. Ser. No','Meter Type','Equip. No','Cycle','Last Bill Key','Route Read Seq','MR Note','Date of MR Note','Critical Need','Service Class','Premise Address','City','District','Subscription No','Account No','BPName','BP Type','Latitude','Longitude','Mult. Factor','No. of Dials','Breaker Cap.','Voltage','Phase','Tariff Type','Prev Read Date T','Prev. Read T','Prev Read Date T1','Prev. Read T1','Prev. Read Date T2','Prev. Read T2','Prev Read Date T3','Prev. Read T3','Prev. Read Date T4','Prev. Read T4','Prev. Read Date T5','Prev. Read  T5','Prev. Read Date T6','Prev. Read  T6','Prev. Read Date T7','Prev. Read  T7','Avg. Consp. per day (kWh)','Accl. Premise No','Main Premise No','Conn. Type', 'F1','F2']
    SECMD.columns=cols
    SECMD = SECMD.fillna('')
    SECMD['fg. Ser. No']= SECMD['fg. Ser. No'].str.upper()
SECMD = pd.DataFrame()




ActiveSessions = {}
def LoadActiveSession():
    AcSessions = pd.read_sql("Select SessionId,Token, UserID from [HES].[dbo].[SAI_UserSessions] where [Status]='A'", conn)
    global ActiveSessions
    print(str(len(AcSessions)) + " --> Session will be loaded.")
    for i, row in AcSessions.iterrows():
        #xxx = jwt.decode(row.Token,key,algorithms=['HS256'])
        #print(type(xxx))
        ActiveSessions[row.SessionId] = jwt.decode(row.Token,key,algorithms=['HS256'])
        print(row.SessionId + " ---> " + str(row.UserID) + " ---> LOADED")
def CheckUserAuth(SID, AuthCode):
    # UAuths = ActiveSessions[SID]["Auths"]
    #print(UAuths)
    return True 

 

actionsStatuses = {
    "Ticket Accepted": {"Prev_status": ["10000", "10900"], "New_status": "2"},
    "Ticket Rejected": {"Prev_status": ["10000", "10900"], "New_status": "3"},
    "Sent to HES": {"Prev_status": ["10100", "10400"], "New_status": "6"},
    "Reassign to SEC FFM": {"Prev_status": ["10100", "10400"], "New_status": "4"},
    "Pended on Meterial ": {"Prev_status": ["10100", "10400"], "New_status": "8"},
    "Pended on Weather ": {"Prev_status": ["10100", "10400"], "New_status": "9"},
    "Pended on SEC": {"Prev_status": ["10100", "10400"], "New_status": "7"},
    "Pended on Other": {"Prev_status": ["10100", "10400"], "New_status": "10"},
    "Completed": {"Prev_status": ["10100", "10400"], "New_status": "12"},
    "Cancelled": {"Prev_status": ["10100", "10400"], "New_status": "13"},
    "Order Created": {"Prev_status": ["10100", "10400"], "New_status": "11"},
    "Re-opened": {"Prev_status": ["10800", "10700"], "New_status": "14"},
    "Resolved": {"Prev_status": ["10520", "10530", "10510", "10540"], "New_status": "5"},
    "HES - Complete": {"Prev_status": ["10520", "10530", "10510", "10540"], "New_status": "5"},
}

StatusKeys = {"New": "primary"
            , "Completed": "success"
            , "Rejected": "secondary"
            , "Re-opened": "info"
            , "Accepted": "warning"
            , "In-Progress": "warning"
            , "In-Progress with HES": "warning"
            , "Pending on material": "warning"
            , "Pending on weather": "warning"
            , "Pending on SEC": "warning"
            , "Pending on others": "warning"
            , "Clevest Order in-progress": "warning"
            , "Cancelled": "secondary"
            , "Reassign to SEC FFM": "dark"
             } 



@app.route("/ATS/TicketInfoTEST/<TicketNumber>", methods=['GET','POST'])
def ATS_getTicketTEST(TicketNumber):
    global StatusKeys
    appTxt = "/ATS"
    ThisAuth = 'ATSV' 
    ThisRoute = '/ATS'
    MTitle = "Alfanar Ticketing System"
    SID = request.cookies.get('SID')
    
    ticketData = pd.read_csv(r"C:\Users\Maram.Alkhatib\OneDrive - alfanar\Documents\Scripts\SMPScripts\docs\ReferenceSheets\ticketData.csv")
    logdata=pd.read_csv(r"C:\Users\Maram.Alkhatib\OneDrive - alfanar\Documents\Scripts\SMPScripts\docs\ReferenceSheets\logdata.csv")
    MeterData=pd.read_csv(r"C:\Users\Maram.Alkhatib\OneDrive - alfanar\Documents\Scripts\SMPScripts\docs\ReferenceSheets\MeterData.csv")
    wfmsdata=pd.read_csv(r"C:\Users\Maram.Alkhatib\OneDrive - alfanar\Documents\Scripts\SMPScripts\docs\ReferenceSheets\wfmsdata.csv")
    df = pd.read_csv("templates/assets/docs/Alarms.csv")
    
    if CheckUserAuth(SID, "ATWE") | CheckUserAuth(SID, "ATWS") | CheckUserAuth(SID, "ATSA"):
        toolbar = "MAFTools"
    else :
        toolbar = "HESTools"

    try:
        alertplace= ""
        alertplace= request.args['alertplace']
    except:
        alertplace= ""

    TabTitle=str(ticketData["TicketNumber"].iloc[0]) + " Ticket ATS"
    return render_template('ATS_Templates/TicketDetails.html' ,TabTitle=TabTitle,alertplace=alertplace, subreason = BM2BM_Reasons, alarms = df, wfmsdata=wfmsdata, MeterData = MeterData, logdata=logdata, ticket= ticketData,toolbar=toolbar,  StatusKeys=StatusKeys,  MyOffices = pd.read_csv("templates/ATS_Templates/mygroups.csv"))

    # alertplace = {"alerttype": "Green", "alerticon": "fa-check-circle", "alertMSG": "BM Order Created" }
    # return redirect(url_for("ATS_getTicketTEST", alertplace=alertplace, TicketNumber = TicketNumber))   
            # return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = "MTitle", MSGBody=testing["MSGBody"], BackTo="/ATS" )


@app.route("/ATS/BalaghForm", methods=['GET','POST'])
def ATS_TESTForm():
     
    return render_template('ATS_Templates/TicketForm.html' )

    # alertplace = {"alerttype": "Green", "alerticon": "fa-check-circle", "alertMSG": "BM Order Created" }
    # return redirect(url_for("ATS_getTicketTEST", alertplace=alertplace, TicketNumber = TicketNumber))   
            # return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = "MTitle", MSGBody=testing["MSGBody"], BackTo="/ATS" )



@app.route("/ATS", methods=['GET','POST'])
def ATS_Dashboared():
  
    appTxt = "/ATS"
    ThisAuth = 'ATSV' 
    ThisRoute = '/ATS'
    MTitle = "Alfanar Ticketing System"
    SID = request.cookies.get('SID')

    
               
    ticketSQL = """select   TOP(10000)
            Tkts.Id, Tkts.EntityId, Incident_Number as 'Incident Number',  ST.Name as Status,Premise, Tkts.Severity,
            OfficeID as Office, DeviceId as 'Device Number', AT.Action as 'Last Action', Concat(CrUA.FirstName, ' ', CrUA.LastName) as LastActionBy 
            , LastActionDate, MustCloseBefore, ReopenCounter, TG.name AS ControllerGroup, RA.Name as Region, SO.Name as Source
            ,iif([OrderStatusId] in (3,4,12,13),CloseComment,CurrentComment) as Comment
        from
            Ticketing.dbo.Tickets Tkts
            left join [Ticketing].[dbo].[Sources] as SO on Tkts.SourceID = SO.id 
            inner join Ticketing.dbo.TeamsGroups as TGO on Tkts.OwnerGroup = TGO.id
            inner join Ticketing.dbo.TeamsGroups as TGC on Tkts.ControllerGroup = TGC.id
            inner join Ticketing.dbo.PackageTicketAssociation TPA on TPA.TicketId = Tkts.id
            inner join Ticketing.dbo.PackageGroupUserAssociation PGUA on PGUA.PackageGroupId = TPA.PackageGroupId
            left join [Ticketing].[dbo].[Statuses] as ST on Tkts.OrderStatusId = ST.id 
            left join [Ticketing].[dbo].[ActionTypes] as AT on Tkts.LastActionTypeId = AT.id 
            left join [Ticketing].[dbo].[TeamsGroups] as TG on Tkts.ControllerGroup = TG.id 
            left join [Ticketing].[dbo].[RegionAreaOffices] as RAO on RAO.Name = Tkts.OfficeID
            left join [Ticketing].[dbo].[RegionAreas] as RA on RA.Id = RAO.AreaId
            left join [HES].[dbo].[SAI_UserAccount] as CrUA on CrUA.id = Tkts.LastActionBy
        where 
            UserId = %USERID%
            and ([FinalCloseDate] is  null or ( [FinalCloseDate] < DATEADD(day,3,getdate()) and OrderStatusId in (3, 4, 12, 13) ))
            and (OwnerGroup in (select [TeamGroupId] from [Ticketing].[dbo].[TeamGroupsUserAssociation] where UserId=%USERID%) or ControllerGroup in (select [TeamGroupId] from [Ticketing].[dbo].[TeamGroupsUserAssociation] where UserId=%USERID%))
            """.replace("%USERID%","2")
            # """.replace("%USERID%",ActiveSessions[SID]["UserId"])
    Tempconn = pyodbc.connect('DRIVER={SQL Server};SERVER=HO-MWFMDB.alfanar.com,1433;DATABASE=Ticketing;UID=clevest;PWD=!C13ve$T')
    ticketData = pd.read_sql(ticketSQL, Tempconn)
    Tempconn.close()
    
    from pandas.api.types import is_datetime64_any_dtype as is_datetime

    print(ticketData[[column for column in ticketData.columns if is_datetime(ticketData[column])]])
    for column in ticketData.columns:
        if is_datetime(ticketData[column]):
            ticketData[column] = pd.to_datetime( ticketData[column]).strftime('%d-%m-%y %H:%M:%S')
            print(column)
    # ticketData["MustCloseBefore"] = pd.to_datetime(ticketData["MustCloseBefore"])
    # ticketData["LastActionDate"] = pd.to_datetime(ticketData["LastActionDate"])
    # ticketData["MustCloseBefore"] = ticketData["MustCloseBefore"].dt.strftime('%d-%m-%y %H:%M:%S')
    # ticketData["LastActionDate"] = ticketData["LastActionDate"].dt.strftime('%d-%m-%y %H:%M:%S')
    ticketTable = ticketData[["Id","Region","EntityId","Incident Number","Status","Source","Severity","Office","Premise","Device Number","Last Action","LastActionBy","LastActionDate","Comment","MustCloseBefore","ControllerGroup","ReopenCounter"]].sort_values(by=["MustCloseBefore"])
        

    return render_template('MyBoard.html',ticketTable = ticketTable , StatusKeys=StatusKeys)
            
        
@app.route("/ATS/TicketInfo/<EntityNumber>", methods=['GET','POST'])
def ATS_getTicket(EntityNumber):
    global StatusKeys
    appTxt = "/ATS"
    ThisAuth = 'ATSV' 
    ThisRoute = '/ATS'
    MTitle = "Alfanar Ticketing System"
    SID = request.cookies.get('SID')
    

    ticketSQL = """
                    SELECT
                        TS.Id as TicketNumber
                        , TS.EntityId as TEntity
                        , [AppOrderNumber]
                        , [Incident_Number]
                        , [OfficeID]  
                        , [Premise]
                        , [CreationDateTime]
                        , [DeviceId]
                        , [DevType]
                        , [ColAlarms]
                        , [ColAlarms2]
                        , [Severity]
                        , [ClientIncCreation]
                        , [Latitude]
                        , [Longitude]
                        , [Classification]
                        , [WorkType]
                        , [WorkSubType]
                        , [ReopenCounter]
                        , [BalaghId]
                        , [OrderStatusId]
                        , [OwnerGroup]
                        , [ControllerGroup]
                        , [LastActionDate]
                        , [LastActionBy] as LastActionById
                        , [CloseComment]
                        , [ExtendedData]
                        , [CurrentComment]
                        , [LastActionTypeId]
                        , [MustCloseBefore]
                        , [CreationMessage]
                        , ST.Name as Status
                        , ST.code as StatusCode
                        , SO.Name as Source
                        , AT.Action as 'LastAction'
                        , TG.name AS TeamsGroups
                        , Concat(CrUA.FirstName, ' ', CrUA.LastName) as LastActionBy
                        ,iif([OrderStatusId] in (3,4,12,13),CloseComment,CurrentComment) as Comme
                    FROM
                        [Ticketing].[dbo].[Tickets] as TS
                        left join [Ticketing].[dbo].[Statuses] as ST on TS.OrderStatusId = ST.id 
                        left join [Ticketing].[dbo].[ActionTypes] as AT on TS.LastActionTypeId = AT.id 
                                    left join [Ticketing].[dbo].[TeamsGroups] as TG on TS.ControllerGroup = TG.id 
                        left join [Ticketing].[dbo].[Sources] as SO on TS.SourceID = SO.id 
                        left join [HES].[dbo].[SAI_UserAccount] as CrUA on CrUA.id = TS.LastActionBy
                    WHERE
                        TS.EntityId = '_ENTITYNUM_'
                """             
    logdata = """
        SELECT
              Ticketid
            , Tkts.EntityId
            , ControllerGroup
            , LastActionDate
            , LastActionTypeId
            , MustCloseBefore
            , TS
            , [LastActionBy] as LastActionById
            , ST.Name as Status
            , ST.code as StatusCode
            , SO.Name as Source
            , AT.Action as 'LastAction'
            , TG.name AS TeamsGroups
            , Concat(CrUA.FirstName, ' ', CrUA.LastName) as LastActionBy
            , iif([OrderStatusId] in (3,4,12,13),CloseComment,CurrentComment) as Comment
            , DATEDIFF(minute,  LAG(TS)  OVER (ORDER BY TS ) ,TS ) AS DateMinDiff

        FROM
            [Ticketing].[dbo].[TicketsLog] as Tkts
            left join [Ticketing].[dbo].[Statuses] as ST on Tkts.OrderStatusId = ST.id 
            left join [Ticketing].[dbo].[ActionTypes] as AT on Tkts.LastActionTypeId = AT.id 
            left join [Ticketing].[dbo].[TeamsGroups] as TG on Tkts.ControllerGroup = TG.id 
            left join [Ticketing].[dbo].[Sources] as SO on Tkts.SourceID = SO.id 
            left join [HES].[dbo].[SAI_UserAccount] as CrUA on CrUA.id = Tkts.LastActionBy

        WHERE
             Tkts.EntityId = '_ENTITYNUM_'
        ORDER BY TS DESC
    """ 
    wfmsdata = """
        SELECT
            wo.HostOrderNumber, substring(wo.HostOrderNumber,0,11) as Premise
            ,FH_MeterNumber,MEX_FoundMeterNumber, MEX_NewMeterNumber
            ,os.Name as Status, ot.Name as OrderType
            ,format(wo.CreationDatetime, 'yyyy-MM-dd HH:mm:ss') as CreationDatetime
            ,format(wo.FinalCompletionDatetime, 'yyyy-MM-dd HH:mm:ss') as FinalCompletionDatetime
        FROM
            Ticketing.dbo.TicketsWFMOrders as TWO
            left join Clevest.dbo.WorkOrder as wo on wo.HostOrderNumber = TWO.HON collate SQL_Latin1_General_CP1_CI_AS
            left join Clevest.dbo.WorkOrderMapping as wom on wom.HostOrderNumber = wo.HostOrderNumber
            left join Clevest.dbo.OrderStatus as os on wo.OrderStatusId = os.Id
            left join Clevest.dbo.OrderType as ot on wo.OrderTypeId = ot.Id
        WHERE 
             TWO.TicketId   = '_ENTITYNUM_'   
        ORDER BY
             wo.CreationDateTime
    """ 
 


    Tempconn = pyodbc.connect('DRIVER={SQL Server};SERVER=HO-MWFMDB.alfanar.com,1433;DATABASE=Ticketing;UID=clevest;PWD=!C13ve$T')
    ticketData = pd.read_sql(ticketSQL.replace("_ENTITYNUM_",EntityNumber), Tempconn)
    logdata = pd.read_sql(logdata.replace("_ENTITYNUM_",EntityNumber), Tempconn)
    wfmsdata = pd.read_sql(wfmsdata.replace("_ENTITYNUM_",str(ticketData["TicketNumber"].iloc[0])), Tempconn)
    ReloadSECData()
    MeterData = SECMD[SECMD["Premise"]== '4009944074']
    # MeterData.to_csv(r"C:\Users\Maram.Alkhatib\OneDrive - alfanar\Documents\Scripts\SMPScripts\docs\ReferenceSheets\MeterData.csv")
    # ticketData.to_csv(r"C:\Users\Maram.Alkhatib\OneDrive - alfanar\Documents\Scripts\SMPScripts\docs\ReferenceSheets\ticketData.csv")
    # logdata.to_csv(r"C:\Users\Maram.Alkhatib\OneDrive - alfanar\Documents\Scripts\SMPScripts\docs\ReferenceSheets\logdata.csv")
    # wfmsdata.to_csv(r"C:\Users\Maram.Alkhatib\OneDrive - alfanar\Documents\Scripts\SMPScripts\docs\ReferenceSheets\wfmsdata.csv")
    print(wfmsdata)
    print(len(wfmsdata))
    Tempconn.close()
    if CheckUserAuth(SID, "ATWE") | CheckUserAuth(SID, "ATWS") | CheckUserAuth(SID, "ATSA"):
        toolbar = "MAFTools"
    else :
        toolbar = "HESTools"
    ticketData["Duein"] = ((pd.to_datetime(ticketData["MustCloseBefore"]) -  datetime.now()).astype('timedelta64[h]')).astype(int)
    ticketData["MustCloseBefore"] = ticketData["MustCloseBefore"].dt.strftime('%d-%m-%y %H:%M:%S')
    ticketData["CreationDateTime"] = ticketData["CreationDateTime"].dt.strftime('%d-%m-%y %H:%M:%S')
    ticketData["LastActionDate"] = ticketData["LastActionDate"].dt.strftime('%d-%m-%y %H:%M:%S')   
    if len(logdata) > 0 :
        logdata["TS"] = logdata["TS"].dt.strftime('%d-%m-%y %H:%M:%S')



    return render_template('ATS_Templates/TicketDetails.html',MeterData = MeterData.iloc[0] if len(MeterData) > 0 else "", subreason = BM2BM_Reasons,alarms=pd.read_csv("templates/assets/docs/Alarms.csv"),  logdata=logdata,wfmsdata=wfmsdata if len(wfmsdata) > 0 else "", ticket= ticketData,toolbar=toolbar,  StatusKeys=StatusKeys,  MyOffices = pd.read_csv("templates/ATS_Templates/mygroups.csv"))
            


@app.route("/ATS/TicketInfo/update", methods=['GET','POST'])
def ATS_TicketUpdate():
      
    #  GET DATA
                actionType = request.form.get('actionType')
                EntityId = request.form.get("EntityID")
                ticketStatus = request.form.get("StatusCode")
                TicketID = request.form.get("TicketNumber")
                actionComment = request.form.get("actionComment")
                uid = "ActiveSessions[SID][]"
                ExtraChanges = ""

                TSQL = """SELECT * FROM [Ticketing].[dbo].[Tickets] WHERE EntityId = '"""+EntityId+"""' """
                actionstable = """SELECT * FROM ActionTypes WHERE Action = '"""+actionType+"""'"""
                Tempconn = pyodbc.connect('DRIVER={SQL Server};SERVER=HO-MWFMDB.alfanar.com,1433;DATABASE=Ticketing;UID=clevest;PWD=!C13ve$T')
                ticketData = pd.read_sql(TSQL, Tempconn)
                actionData = pd.read_sql(actionstable, Tempconn)
                Tempconn.close()
                
                premise = ticketData["Premise"].iloc[0]
                ReopenCounter = ticketData["ReopenCounter"].iloc[0]
                actionID = actionData["Id"].iloc[0]
                # print(premise,ReopenCounter,actiondata)

                updatesql = """ UPDATE  
                                    [Ticketing].[dbo].[Tickets]
                                SET
                                    OrderStatusId = '_STATUSCODE_'
                                    ,CurrentComment= '_CURRENTCOMMENT_'
                                    ,LastActionDate=getDate()
                                    ,LastActionBy= '"""+str(uid)+"""'
                                    ,LastActionTypeId='_ACTIONID_'
                                    _ExtraChanges_
                                WHERE EntityId='"""+str(EntityId)+"""'"""
                
                # Case by Case Update
                if actionType == "Order Created": 

                    ordertype = request.form.get("formType")
                    if ordertype == 'BMForm':
                        print("BM")
                        BMCreateATS()
                        ordertypeId="5"
                    elif ordertype == 'SVForm':
                        print("SV")
                        CreateVisitOrderATS()
                        ordertypeId="7"

                    elif ordertype == 'SIMForm':
                        print("SIM")
                        CreateSIMInstallationOrder()
                        ordertypeId="9"

                    elif ordertype == 'TSForm':
                        print("TS")
                        SOMRequestCreationATS()
                        ordertypeId="13"

                    else:
                        retur_json = {
                            "status": 500,
                            "title": "Invalid Form",
                            "message": "Form Information Issue",
                            "details": "Issue has occured while submitting you request. Kindly recheck entered data and try again in minute",
                            "timed" : True,
                            "id": "xxxxxi",
                            "type": "warning"
                        }
                        return jsonify(retur_json)
                
                    TSQL = """insert into [Ticketing].[dbo].[TicketsWFMOrders] 
                                ([InsertDateTime],[TicketId],[ReqOrderType],[HON],[ResponseMSG]) 
                                values (getdate(),'"""+ TicketID +"""','"""+ordertypeId+"""','"""+ jData["HON"] +"""','Order Pre-created')"""
                

                if ticketStatus == 10900 and actionType=="Accepted":
                    ExtraChanges = ", ReopenCounter = " + str(ReopenCounter.astype(int)+ 1)   
                
                if actionType == "Sent to HES":
                    ExtraChanges = " ,ControllerGroup='2'"  
                
                if actionType == "HES - Complete":
                    ExtraChanges = " ,ControllerGroup='1'"  
                
                if actionType == "Completed" or actionType == "Ticket Rejected" or actionType == "Reassign to SEC FFM":
                    ExtraChanges = ", LastActionTypeId='_ACTIONID_', CloseDateTime=getDate(), CloseComment='"""+actionComment+"""' , CloseActionId  = '_ACTIONID_'"""
                

                if ticketStatus  in actionsStatuses[actionType]["Prev_status"] :
              
                    updatesql = updatesql.replace("_STATUSCODE_",str(actionsStatuses[actionType]["New_status"])).replace("_CURRENTCOMMENT_",actionComment).replace("_ACTIONID_",str(actionID)).replace("_ExtraChanges_",ExtraChanges)
                    print(updatesql)
                    Tempconn = pyodbc.connect('DRIVER={SQL Server};SERVER=HO-MWFMDB.alfanar.com,1433;DATABASE=Ticketing;UID=clevest;PWD=!C13ve$T')
                    newcr = Tempconn.cursor()
                    newcr.execute(updatesql)
                    Tempconn.commit()
                    newcr.close()
                    Tempconn.close()
                    print("Updated")
                    if actionType == "Order Created": 
                        retur_json = {
                            "status": 200,
                            "title": "Order Creation",
                            "message": "New Order Created",
                            "details": "A new order will be avilable in system in few minutes ",
                            "timed" : True,
                            "id": "xxxxxi",
                            "type": "success"
                        }
                        return jsonify(retur_json)
                else:
                    return render_template("GeneralMessage.html", MsgTitle="Processing Issue", MSGBody="An issue has occured. kindly check again later", msgcolor = "red", BackTo="/ATS/TicketInfo/"+TicketID)
                
                return redirect("/ATS/TicketInfo/"+TicketID)

     
 


     
@app.route("/openwfmsorder", methods=['GET','POST'])
def CheckOpenOrders():

    if request.method == "POST":
        req_pnum = request.form['requestedPremise']
        print(req_pnum)
        
        SQLstr = """SELECT 
                        wo.Hostordernumber
                        ,SUBSTRING(wo.Hostordernumber, 0, 11) as premise
                    FROM
                        WorkOrder as wo
                    WHERE
                        SUBSTRING(wo.Hostordernumber, 0, 11) = '"""+req_pnum+"""'
                        and OrderStatusId not in (100,80)"""
        Tempconn = pyodbc.connect('DRIVER={SQL Server};SERVER=HO-MWFMDB.alfanar.com,1433;DATABASE=Clevest;UID=clevest;PWD=!C13ve$T')
        wfmsorder = pd.read_sql(SQLstr, Tempconn)
        Tempconn.close
        if len(wfmsorder) > 0: 
        # if 1==0: 
            retur_json = {
                "status": "error",
                "title": "Open Order",
                "message": "An open order in system.",
                "details": "An open order was found for <small>"+ str(req_pnum) +"</small>.\n All open order must completed or closed befor creating any new orders",
                "timed" : False,
                "id": "xxxxxi",
                # "status": 500,
                "type": "warning"
            }
            return jsonify(retur_json)
        else:
            retur_json = {
                "status": 200,
                "title": "No Open Orders",
                "message": "No open order in system.",
                "details": "No open order was found for "+ str(req_pnum) +".",
                "timed" : True,
                "id": "xxxxxi",
                "type": "info"
                }
        
    return jsonify(retur_json)
            
   
    
  
@app.route("/getsapdata", methods=['GET','POST'])
def getsapdata():

    req_pnum = request.form['requestedPremise']
    print(req_pnum)
    try:
        Meterdata=SECMD[SECMD["Premise"]==req_pnum]
        if len(Meterdata) >0:    
            
            retur_json = {
                "status": 200,
                "title": "SAP Information",
                "message": "Premise Found in SAP",
                "details": "SAP data found for premise "+str(req_pnum),
                "timed" : True,
                "id": "xxxxxi",
                "type": "info"
            }

        else:
            retur_json = {
                "status": "error",
                "title": "SAP Information",
                "message": "No SAP data found",
                "details": "No records for premise"+ str(req_pnum) +"was found in SAP.",
                "timed" : True,
                "id": "xxxxxi",
                "type": "warning"
            }
    except:
        retur_json = {
                "status": "error",
                "title": "Validation Issue",
                "message": "Issue Retreving SAP Data",
                "details": "An issue occured while retreving premise SAP Information. Try again in few minutes",
                "timed" : True,
                "id": "xxxxxi",
                "type": "warning"
            }
    return jsonify(retur_json)
 





def BMCreateATS():

    if request.form.get("reasons") == None or request.form.get("subreason")==None or request.form.get("reasons") == "" or request.form.get("subreason")=="" :
        retur_json = {
                "status": 10404,
                "title": "Invalid Reason",
                "message": "Invalid Reason",
                "details": "Must select valid reason before creating order, re-try again.",
    			"timed" : True,
                "id": "BM10404i-0",
    			"type": "warning"
            }
        return jsonify(retur_json)
    if request.form.get("Meter") == None and request.form.get("DCU") == None and request.form.get("ECB")  == None and request.form.get("CM") == None :
        retur_json = {
                "status": 10404,
                "title": "Missing",
                "message": "Missing/Invalid Data",
                "details": "Must select valid device before creating order, re-try again with correct data.",
    			"timed" : True,
                "id": "BM10404i-1",
    			"type": "warning"
            }
        return jsonify(retur_json)
        
    Meter = '' if request.form.get("Meter") == None else request.form.get("Meter")
    DCU = '' if request.form.get("DCU")== None else request.form.get("DCU")
    ECB ='' if  request.form.get("ECB")== None else request.form.get("ECB")
    CM ='' if  request.form.get("CM")== None else request.form.get("CM")
    
    PNum = request.form.get("PNum")
    Reason = request.form.get("reasons")
    SubReason= request.form.get("subreason")
    MyMeter = SECMD[SECMD["Premise"]== PNum]
    
    MyRec = {
                    "PNum":PNum,
                    "Meter" : Meter,
                    "DCU" : DCU,
                    "ECB"  : ECB,
                    "CM" : CM,
                    "MeterData" : MyMeter,
                    "Reason" : Reason,
                    "SubReason" : SubReason,
                    "UName" : ActiveSessions[SID]["UserName"],
                    "UId" : ActiveSessions[SID]["UserId"],
                    "Mail" : ActiveSessions[SID]["Mail"],
                    "FName" : ActiveSessions[SID]["UserFName"]
                }
               
    ClevestTargetLink = 'http://mwfm.alfanar.com/MWFM/api/MethodInvocations/SMR_Create?api-version=1'
    Auths = {"UserName" : "sap_api", "Password":"123456"}
    headers = {'Content-Type': 'application/json'}
    auth = HTTPBasicAuth(Auths["UserName"], Auths["Password"])
        
    SQLStr = "select HostOrderNumber from WorkOrderMapping where HostOrderNumber like '"+ PNum +"%' and OrderStatusId not in (100, 80) and ordertypeid in (1,5)"
    Tempconn = pyodbc.connect('DRIVER={SQL Server};SERVER=HO-MWFMDB.alfanar.com,1433;DATABASE=Clevest;UID=clevest;PWD=!C13ve$T')
    runningOrders = pd.read_sql(SQLStr, Tempconn)
    Tempconn.close()
    if len(runningOrders) > 0 :
                retur_json = {
                                "status": 10403,
                                "title": "Previous Order",
                                "message": "Existing Order in System",
                                "details": "There is already a present order in system "+ runningOrders["HostOrderNumber"].iloc[0] +".",
                                "timed" : True,
                                "id": "BM10403i-0",
                                "type": "warning"
                            }
                return jsonify(retur_json)
    else:
                if MyMeter.iloc[0]["Meter Type"] == "DCU":
                    print("MeterType DCU")
                    if len(MyRec["PNum"]) == 20:
                        try:
                            SQL_NewSer = """select max(convert(int,substring(hostordernumber,23,10))) + 1 as NewSer
                                        from WorkOrderMapping
                                        where HostOrderNumber like '"""+ MyRec["PNum"] +"""-R%'"""
                        except Exception as e:
                            # print("Issue with DCU Premise number " + inProcess["PNum"] + " CODE D1" )
                            logging.error("Issue with DCU Premise number " + MyRec["PNum"] + " CODE D1")
                    elif len(MyRec["PNum"]) == 15:
                        try:
                            SQL_NewSer = """select max(convert(int,substring(hostordernumber,18,10))) + 1 as NewSer
                                    from WorkOrderMapping
                                    where HostOrderNumber like '"""+ MyRec["PNum"] +"""-R%'"""
                        except Exception as e:
                            # print("Issue with DCU Premise number " + inProcess["PNum"] + " CODE D2" )
                            logging.error("Issue with DCU Premise number" + MyRec["PNum"] + " CODE D2")
                    else:
                        # print("Issue with DCU Premise number" + inProcess["PNum"] + " CODE D3")
                        logging.error("Issue with DCU Premise number" + MyRec["PNum"] + " CODE D3")
                else:
                    
                    try:
                        SQL_NewSer = """select max(convert(int,substring(hostordernumber,13,10))) + 1 as NewSer
                                    from WorkOrderMapping
                                    where HostOrderNumber like '"""+ MyRec["PNum"] +"""-R%'"""
                    except Exception as e:
                        # print("Issue with Premise number " + inProcess["PNum"] + " CODE P1" )
                        logging.error("Issue with Premise number " + MyRec["PNum"]+ " CODE P1")
                NewHON =(MyRec["PNum"] + '-R{0:07d}').format(pd.read_sql(SQL_NewSer, clConn).fillna(1).iloc[0].NewSer)
               
                logging.info("Opening Clevest Order HON: "+NewHON)
                BG = omBGs[MyMeter.iloc[0]["Office"][:2]]
                clMsg = {
                        'BG':BG,
                        'HON':NewHON,
                        'RouteNumber':MyMeter.iloc[0]["MRU"],
                        'Office':MyMeter.iloc[0]["Office"],
                        'MeterNumber':MyMeter.iloc[0]["fg. Ser. No"],
                        'MeterType':MyMeter.iloc[0]["Meter Type"],
                        'EquipmentNumber':MyMeter.iloc[0]["Equip. No"],
                        'LastReadMonth':MyMeter.iloc[0]["Last Bill Key"],
                        'RouteReadSeq':MyMeter.iloc[0]["Route Read Seq"],
                        'ServiceClass':MyMeter.iloc[0]["Service Class"],
                        'Subscription':MyMeter.iloc[0]["Subscription No"],
                        'District':MyMeter.iloc[0]["District"],
                        'AccountNumber':MyMeter.iloc[0]["Account No"],
                        'CustomerName':MyMeter.iloc[0]["BPName"],
                        'Latt':MyMeter.iloc[0]["Latitude"],
                        'Long':MyMeter.iloc[0]["Longitude"],
                        'Multiplier':MyMeter.iloc[0]["Mult. Factor"],
                        'Dials':MyMeter.iloc[0]["No. of Dials"],
                        'Breaker':MyMeter.iloc[0]["Breaker Cap."],
                        'TarifType':MyMeter.iloc[0]["Tariff Type"],
                        'PreRDGDate':MyMeter.iloc[0]["Prev Read Date T"],
                        'PreRDG':MyMeter.iloc[0]["Prev. Read T"],
                        'AvgConsumption':MyMeter.iloc[0]["Avg. Consp. per day (kWh)"],
                        'PremiseAcc':MyMeter.iloc[0]["Accl. Premise No"],
                        'PremiseMain':MyMeter.iloc[0]["Main Premise No"],
                        'CustomerState':MyMeter.iloc[0]["Conn. Type"],
                        'TransformerID':'',
                        'WorkSubType':'RW',
                        'NCR':NewHON,
                        'Premise':MyRec["PNum"],
                        'RepMeter':MyRec["Meter"],
                        'RepComm':MyRec["CM"],
                        'RepECB':MyRec["ECB"],
                        'RepDCU':MyRec["DCU"],
                        'RaisedBy':MyRec["UName"],
                        'Reason' : MyRec["Reason"],
                        'SubReason' : MyRec["SubReason"],
                        'UId' : MyRec["UId"]
                        ,'DCUSerialNumber' : MyMeter.iloc[0]["DCUSerialNumber"] if MyRec["DCU"] == 'Y' else ""
                        ,'TransformerID' : MyMeter.iloc[0]["TransformerID"] if MyRec["DCU"] == 'Y' else ""
                        ,'TransformerRating' : MyMeter.iloc[0]["TransformerRating"] if MyRec["DCU"] == 'Y' else ""
                        ,'PowerConnected' : MyMeter.iloc[0]["PowerConnected"] if MyRec["DCU"] == 'Y' else ""
                        ,'PowerConnectionDate' : MyMeter.iloc[0]["PowerConnectionDate"] if MyRec["DCU"] == 'Y' else ""
                        ,'PowerStatusUpdatedBy' : MyMeter.iloc[0]["PowerStatusUpdatedBy"] if MyRec["DCU"] == 'Y' else ""
                        ,'CTavailable' : MyMeter.iloc[0]["CTavailable"] if MyRec["DCU"] == 'Y' else ""
                        ,'CTConnected' : MyMeter.iloc[0]["CTConnected"] if MyRec["DCU"] == 'Y' else ""
                        ,'CTRatio' : MyMeter.iloc[0]["CTRatio"] if MyRec["DCU"] == 'Y' else ""
                        # ,'SignalStrength' : MyMeter.iloc[0]["SignalStrength"],
                        # 'MeterList' : MyMeter.iloc[0]["MeterList"]
                        }

                print(Fore.BLUE + "Order Information: " +Style.RESET_ALL)
                print(clMsg)
                logging.debug(clMsg)

                resp = requests.post(ClevestTargetLink, data=json.dumps(clMsg),headers=headers,auth=auth)
                if resp.status_code == 200:
                    print(Fore.GREEN + "Clevest Order" +NewHON+" Created" +Style.RESET_ALL)
                    logging.info("Clevest Order "+NewHON+" Created")
                    
                    try:
                        NCRM.CreateMainNCR(clMsg)
                        print(Fore.GREEN + "NCR Order "+NewHON+" Created" +Style.RESET_ALL)
                    except:
                        print(Fore.RED + "Issue in NCR "+NewHON+" Creation" +Style.RESET_ALL)
                        logging.error("Issue in NCR "+NewHON+" Creation")


                    print(clMsg)
                    # logging.debug(clMsg)
                    logging.info("NCR Order "+NewHON+" Created")

                    # print("AFTER NCR Creation DONE")

                    try:
                        retur_json = {
                                "status": 10200,
                                "title": "Order Created",
                                "message": "New BM Order "+ NewHON,
                                "details": "New Smart-to-Smart order created in system ("+ NewHON +")",
                                "timed" : True,
                                "id": "BM10200i-0",
                                "type": "info"
                            }
                        return jsonify(retur_json)
                    except:
                        print(Fore.RED + "Mail NOK" +Style.RESET_ALL)
                        logging.error("Mail NOK" + str(MyRec["Mail"]))
                else:
                    
                    retur_json = {
                            "status": 10500,
                            "title": "Smart-to-Smart Order Creation",
                            "message": "New BM Order "+ PNum,
                            "details": "Error happened in Clevest, Try again in few minutes. If issue continue, contact admin for more information.",
                            "timed" : False,
                            "id": "BM10500i-0",
                            "type": "danger"
                        }
                    return jsonify(retur_json)
                   
 
    






    print(MyRec)
    retur_json = {
                "status": 10200,
                "title": "Order Creation",
                "message": "New BM Order Created",
                "details": "New Order Smart-2-Smart order for "+PNum+" created. Check in system in few minute",
    			"timed" : True,
                "id": "BM10200i-0",
    			"type": "info"
            }
    return jsonify(retur_json)
    

      
 
      

@app.route('/sitevisit/create', methods=['POST'])
def CreateVisitOrderATS():

    print(request.form)
    Office = request.form.get("Office")
    PremiseNumber = request.form.get("PNum")
    print(PremiseNumber)
    SubscriptionNumber = request.form.get("SubNum")
    AccountNumber = request.form.get("AccNum")
    MeterNumber = request.form.get("MNum")
    Longitude = request.form.get("long")
    Lattitude= request.form.get("latt")
    complainEn = request.form.get("reasonEn")
    complainAr = request.form.get("reasonAr")
    requestedBy = request.form.get("requester")
    payload = {
	            "Premise" : PremiseNumber + '_' + datetime.today().strftime("%Y%m%d"),
	            "Complaint" : complainEn,
	            "Office" : Office,
	            "ComplaintAR" : complainAr,
	            "Subscription" : SubscriptionNumber,
	            "accountnumber" : AccountNumber,
	            "Long" : Longitude,
	            "Latt" : Lattitude,
	            "MeterNumber" : MeterNumber,
                "ReportedBy" : requestedBy,
                "IssueDate" : datetime.today().strftime("%Y-%m-%d %H:%M") 
              }
 
    print(payload)
    
    retur_json = {
                "status": 10200,
                "title": "Order Creation",
                "message": "New Site Visit Order",
                "details": "New site visit with premise <small>"+ payload["Premise"] +"</small> should be avilable in system in few minutes",
    			"timed" : True,
                "id": "xxxxxi",
    			"type": "info"
            }
      
    return jsonify(retur_json)
                

       

@app.route('/SIMReplacement/new', methods=['POST'])
def CreateSIMInstallationOrder():
    

    BGs = {  "11":{ "BGId":"2"},
             "12":{ "BGId":"3"},
             "13":{ "BGId":"4"},
             "14":{ "BGId":"5"},
             "15":{ "BGId":"6"},
             "16":{ "BGId":"7"},
             "31":{ "BGId":"8"},
             "32":{ "BGId":"9"},
             "33":{ "BGId":"10"},
             "34":{ "BGId":"11"},
             "35":{ "BGId":"12"}
           }
    Premise = request.form.get("PNum")
    office = request.form.get("Office")[:2]
    longi = request.form.get("Long")
    latt = request.form.get("Latt")

    SQL_NewSer = """select max(convert(int,substring(hostordernumber,14,10))) + 1 as NewSer
                    from WorkOrderMapping
                    where HostOrderNumber like '"""+ Premise +"""_SR%'"""
    # NewHON =(Premise + '_SR{0:07d}').format(pd.read_sql(SQL_NewSer, CLconnstr).fillna(1).iloc[0].NewSer)
    while (longi[-1] == '0'):
        longi = longi[:-1]
    while (latt[-1] == '0'):
        latt = latt[:-1]
    payload = {
                "HostOrderNumber" : ["400000000_SR000001"],
                # "HostOrderNumber" : [NewHON],
                "Premise" : [Premise],
                "Subscription" : [request.form.get("SSNum")],
                "AccountNumber" : [request.form.get("AccNum")],
                "Office": [request.form.get("Office")],
                "Long" :[longi],
                "Latt":[latt],
                "ExpectedMeter" : [request.form.get("MNum")],
                "BGId": [BGs[office]["BGId"]]
                }
 
    print(payload)
    return redirect("/ATS/TicketInfoTEST/<TicketNumber>")
          


def SOMRequestCreationATS():
    fileName = "MeterList.csv"
    MultiMeterNo = pd.DataFrame()
    alarmSelected = request.form.get('singleAlarm')
    MultiMeterNo["Meters"]=[request.form.get('MNum')]
     
    if alarmSelected == None:
        retur_json = {
                "status": 10404,
                "title": "Missing",
                "message": "Missing/Invalid Data",
                "details": "Must select valid device before creating order, re-try again with correct data.",
    			"timed" : True,
                "id": "TS10404i-0",
    			"type": "warning"
            }
        return jsonify(retur_json)
    
    if alarmSelected == "4" or alarmSelected == "5":
        MultiMeterNo["CMNum"]=[request.form.get('CMNum')]


     
    df = pd.read_csv("templates/assets/docs/Alarms.csv")
    df["id"] =df["id"].astype('str')
    
    reqAlarm = df[df["id"] == alarmSelected]
    Al, ALAgg , DevType = reqAlarm.iloc[0]["Alarm"], reqAlarm.iloc[0]["Key"], reqAlarm.iloc[0]["DevType"]
    
    if DevType == "Meter":
        global SECMD
        df_Main=pd.DataFrame()
        df_Main = SECMD[SECMD["fg. Ser. No"].isin(MultiMeterNo["Meters"])]
        df_Main = pd.merge(df_Main,MultiMeterNo, how='inner', left_on='fg. Ser. No', right_on='Meters' )
        df_Main = df_Main[['Premise','fg. Ser. No','Office','MRU','Equip. No','Cycle','Subscription No','Account No','Latitude','Longitude','Breaker Cap.','Avg. Consp. per day (kWh)','CMNum']]
        df_Main["Latitude"] = df_Main["Latitude"].str[:10]
        df_Main["Longitude"] = df_Main["Longitude"].str[:10]
        df_Main['MeterReadDateTime']=""
        df_Main = df_Main[:]
        df_Main = df_Main.reset_index()
        print("Orders ---> " + str(len(df_Main)))
        LastTicketNumber = pd.read_csv("templates/assets/docs/LastTicketNum.csv").iloc[0]["Num"]
        df_Main["HostOrderNumber"] = df_Main["Premise"] + "_" + ALAgg
        df_Main["severity"] = 1
        df_Main["Work_type"] = "Meter"
        df_Main["Work_sub_type"] = "Not Connected"
        df_Main["Incident_description"] = Al
        df_Main["Classification"] = "NC"
        df_Main["Device_type"] = "Meter"
        df_Main["SM_count"] = Al
        df_Main["Issue_type"] = "Meter"
        df_Main["MessageID"] = ""
        df_Main['IncCreationTime'] = datetime.now().strftime('%Y-%m-%dT%H:%M:%S')
        df_Main["SRC"] = "ALF"
        df_Main["MeterType"]=df_Main["fg. Ser. No"].str[:3]
        df_Main = df_Main.reset_index()
        temp_conn = pyodbc.connect("DRIVER={ODBC Driver 17 for SQL Server};SERVER=HO-MWFMDB.alfanar.com,1433;DATABASE=clevest;UID=DataAnalysisReadOnly;PWD=D2#@J5u2Y3;")
        ClevestData = pd.read_sql("""select SUBSTRING(HostOrderNumber,1,10) as HON, format(count(hostordernumber)+1,'0') as cnt
        from Clevest.dbo.WorkOrderMapping
        where OrderTypeId=13 
        group by SUBSTRING(HostOrderNumber,1,10) """,conn)
        temp_conn.close()
        df_Main=pd.merge(df_Main, ClevestData, left_on='Premise', right_on='HON', how='left')
        df_Main = df_Main.fillna(0)
        df_Main["HostOrderNumber"] = df_Main["HostOrderNumber"] + "_" + df_Main["cnt"].astype(str)
        df_Main["NewTicketNumber"] = ""
      
        MultiMeterNo[~MultiMeterNo["Meters"].isin(df_Main["fg. Ser. No"])].to_csv("templates/assets/docs/"+fileName.replace(".csv","_Missing.csv"))
        BGs = pd.read_csv(r"templates/assets/docs/BGs.csv", dtype=str)
        df_Main["Areakey"] = df_Main["Office"].str[:2]
        df_Main = pd.merge(df_Main, BGs, left_on='Areakey' , right_on="ACode", how='left')

        for i, row in df_Main.iterrows():
            if (alarmSelected == "4") and not row["CMNum"]:
                return render_template("GeneralMessage.html",msgcolor = "Red", MsgTitle = "No Meters in File", MSGBody="NCCM alarms must contain the cross-ponding communication module number for each meter.", BackTo="/som" )  
            xcc = "ALF{:05d}".format(row["TicketNumber"])
            df_Main.loc[df_Main["HostOrderNumber"]==row["HostOrderNumber"],"NewTicketNumber"] = xcc
            ExpFileName = ALAgg + "_" + datetime.now().strftime('%Y%m%dT%H%M%S') + "_SOMNO.csv"
            df_Main[['HostOrderNumber','severity', 'fg. Ser. No', 'Latitude', 'Longitude','Avg. Consp. per day (kWh)','Cycle','Work_type', 'Work_sub_type', 'Incident_description', 'Breaker Cap.' , 'Account No' ,  'Equip. No', 'MRU', 'Premise', 'Office', "MeterType", 'Classification', 'Device_type', 'BGiD',  'SM_count', 'Issue_type', 'IncCreationTime', 'MeterReadDateTime', 'MessageID', 'NewTicketNumber' , 'Subscription No','SRC','CMNum' ]].to_csv("//10.90.10.59/prd/AllHostExchange/SingleUpdateFolder/"+ExpFileName, index=False)
            with open("templates/assets/docs/LastTicketNum.csv", 'w') as f:
                f.write("Num\n")
                f.write(str(LastTicketNumber))
            print("Process finished. ----> " + ExpFileName)
        SID = request.cookies.get('SID')
        MessingMetersList=MultiMeterNo[~MultiMeterNo["Meters"].isin(df_Main["fg. Ser. No"])]
        if len(MessingMetersList) > 0:
            SID = request.cookies.get('SID')
            FName = ActiveSessions[SID]["UserFName"]
            UEmail = ActiveSessions[SID]["Mail"]
            msgbody = """
                        <h3> Dear """+FName+"""</h3>
                        <h4> Attached is list of meters not present in SAP</h4>
                        <h4>Kindly recheck the data  :\n</h4>  
                        <br>
                        """+MessingMetersList.to_html()+"""
                        <br>
                        <p><b><i>This is an automatically generated email – please do not reply to it. If you have any queries regarding your request please contact admin for support<br> Thank You.</i><b/></p>"""
       
    else:
        print("DCU")
 
 
 


# __________________ Server Side DataTable _______________________
      
@app.route("/ATSS", methods=['GET','POST'])
def ATS_Dashboared2():
  
    appTxt = "/ATS"
    ThisAuth = 'ATSV' 
    ThisRoute = '/ATS'
    MTitle = "Alfanar Ticketing System"
    SID = request.cookies.get('SID')


    return render_template('MyBoardServerSide.html'  , StatusKeys=StatusKeys, MyOffices = pd.read_csv("templates/ATS_Templates/mygroups.csv"))
            

        

@app.route('/api/data')
def data():
    start = request.args.get('start', type=int)
    length = request.args.get('length', type=int)
    search = request.args.get('search[value]')
    col_index = request.args.get('order[0][column]')
    col_name = request.args.get(f'columns[{col_index}][data]')
    descending = request.args.get(f'order[0][dir]') == 'desc'

    mod = False
    print(search)
    ticketSQL = """
                    SELECT
                        TS.Id, TS.EntityId, Incident_Number as 'Incident Number',  ST.Name as Status,Premise, TS.Severity,
                        OfficeID as Office, DeviceId as 'Device Number', AT.Action as 'Last Action', Concat(CrUA.FirstName, ' ', CrUA.LastName)   as LastActionBy , LastActionDate,
                        MustCloseBefore, ReopenCounter, TG.name AS ControllerGroup, CurrentComment
                    FROM
                        [Ticketing].[dbo].[Tickets] as TS
                        left join [Ticketing].[dbo].[Statuses] as ST on TS.OrderStatusId = ST.id 
                        left join [Ticketing].[dbo].[ActionTypes] as AT on TS.LastActionTypeId = AT.id 
                        left join [Ticketing].[dbo].[TeamsGroups] as TG on TS.ControllerGroup = TG.id 
                        left join [HES].[dbo].[SAI_UserAccount] as CrUA on CrUA.id = TS.LastActionBy

                    WHERE
                        OrderStatusId not in (10700,10800)
                    ORDER BY MustCloseBefore
 
                    """ 
    Tempconn = pyodbc.connect('DRIVER={SQL Server};SERVER=HO-MWFMDB.alfanar.com,1433;DATABASE=Ticketing;UID=clevest;PWD=!C13ve$T')
    ticketData = pd.read_sql(ticketSQL + """OFFSET """+str(start)+""" ROWS FETCH NEXT """+str(length)+""" ROWS ONLY """, Tempconn)
    ticketDataLen = pd.read_sql(ticketSQL, Tempconn)
    Tempconn.close()
    tablecols = ["Id","EntityId","Incident Number","Premise","Status","Severity","Office","Device Number","Last Action","LastActionBy","LastActionDate","CurrentComment","MustCloseBefore","ControllerGroup","ReopenCounter"]
    # TODO: Search not case Sensative 
    ticketDataLen = ticketDataLen[tablecols]

    if search:
        mod = True
        ticketDataLen = ticketDataLen[ticketDataLen.apply(lambda row: row.astype(str).str.contains(r""+search+"", na=False).any(), axis=1)][start:start+length]
    

    if col_name not in ticketDataLen.columns:
        col_name = 'MustCloseBefore'
    ticketDataLen = ticketDataLen.sort_values(col_name)
    if descending:
        ticketDataLen = ticketDataLen.sort_values(col_name, ascending=False)
    
    if mod or col_name != 'MustCloseBefore' or descending:
        ticketTable = ticketDataLen[start:start+length]
    else:
        ticketTable=ticketData[tablecols]


    ticketTable["MustCloseBefore"] = pd.to_datetime(ticketTable["MustCloseBefore"])
    ticketTable["LastActionDate"] = pd.to_datetime(ticketTable["LastActionDate"])
    ticketTable["MustCloseBefore"] = ticketTable["MustCloseBefore"].dt.strftime('%d-%m-%y %H:%M:%S')
    ticketTable["LastActionDate"] = ticketTable["LastActionDate"].dt.strftime('%d-%m-%y %H:%M:%S')
    filteredusers = ticketTable.to_dict('records')
    return {
        'data': filteredusers,
        'recordsFiltered': len(ticketDataLen),
        'recordsTotal': len(ticketDataLen),
        'draw': request.args.get('draw', type=int)
    }



# __________________ AJAX Functions _______________________


# # StatusKeys = {
# #                10000: "primary", New
#     #          , 10100: "warning", Accepted
#     #          , 10200: "secondary", Rejected
#     #          , 10300: "dark", Reassign to SEC FFM
#     #          , 10400: "warning", In-Progress
#     #          , 10500: "warning", In-Progress with HES
#     #          , 10510: "warning", Pending on SEC
#     #          , 10520: "warning", Pending on material
#     #          , 10530: "warning", Pending on weather
#     #          , 10540: "warning", Pending on others
#     #          , 10600: "warning", Clevest Order in-progress    
#     #          , 10700: "success", Completed
#     #          , 10800: "secondary", Cancelled
#     #          , 10900: "info", Re-opened
#     #      
#     #           } 
  


# @app.route('/SAPData', methods=['GET','POST'])
# def index():

#     if len(SECMD) > 0:
#         pass
#     else:
#         ReloadSECData()
#     TPremise = request.form['TPremise']
#     MeterData = SECMD[SECMD["Premise"] == TPremise]
#     sappremise = MeterData["Premise"].iloc[0]
#     payload = {
#         sappremise : MeterData["Premise"].iloc[0]
#     }
#     return jsonify({'data':payload})
     

        
@app.route("/ATS/Ticketlog", methods=['GET','POST'])
def ATS_getTicketLog():
    
    logdata = """
                    SELECT
                        Ticketid
                        ,OrderStatusId
                        ,  ControllerGroup
                        ,LastActionDate
                        ,  LastActionTypeId
                        , MustCloseBefore
                        , [LastActionBy] as LastActionById
                        , ST.Name as Status
                        , ST.code as StatusCode
                        , SO.Name as Source
                        , AT.Action as 'LastAction'
                        , TG.name AS TeamsGroups
                        , Concat(CrUA.FirstName, ' ', CrUA.LastName) as LastActionBy
                        , iif([OrderStatusId] in (3,4,12,13),CloseComment,CurrentComment) as Comment
                    FROM
                        [Ticketing].[dbo].[TicketsLog] as TS
                        left join [Ticketing].[dbo].[Statuses] as ST on TS.OrderStatusId = ST.id 
                        left join [Ticketing].[dbo].[ActionTypes] as AT on TS.LastActionTypeId = AT.id 
                        left join [Ticketing].[dbo].[TeamsGroups] as TG on TS.ControllerGroup = TG.id 
                        left join [Ticketing].[dbo].[Sources] as SO on TS.SourceID = SO.id 
                        left join [HES].[dbo].[SAI_UserAccount] as CrUA on CrUA.id = TS.LastActionBy
                    WHERE
                        Ticketid = '"""+request.form['TicketNumber']+"""'
                """ 
    Tempconn = pyodbc.connect('DRIVER={SQL Server};SERVER=HO-MWFMDB.alfanar.com,1433;DATABASE=Ticketing;UID=clevest;PWD=!C13ve$T')
    logdata = pd.read_sql(logdata, Tempconn)
    Tempconn.close()
    filteredusers = logdata.to_dict('records')

    return {"output" : filteredusers}


app.run(debug=True)


 